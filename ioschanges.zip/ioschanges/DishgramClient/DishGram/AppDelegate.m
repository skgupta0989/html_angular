//
//  AppDelegate.m
//  DishGram
//
//  Created by Rags on 08/04/13.
//
//

#import "AppDelegate.h"
#import "LandingScreen.h"

#import "FollowingViewController.h"
#import "ActivityFeedViewController.h"
#import "ProfileController.h"
#import "Utilities.h"

#import "PromoteVC.h"
#import "Header.h"
#import "DishgramHomeControllerViewController.h"

#import "PostDishViewController.h"
#import "DGRestuarentViewController.h"
#import "DishDetailAddViewController.h"
#import "AddNewRestuarentVC.h"
#import "Utilities.h"
#import "UserProfile.h"
#import "SettingController.h"
#import "FourSquareHandler.h"
#import "TwitterHandler.h"
#import "FacebookSocialNetwork.h"
#import "TumblrHandler.h"
#import "InviteFriendsVC.h"
#import "DGLocationManager.h"
#import "EditProfileVC.h"
#import "PageUtil.h"
#import "DataSourceInterface.h"
#import <Crashlytics/Crashlytics.h>
#import "ViewPostController.h"

@interface AppDelegate()
- (void)handleRemoteNotification:(UIApplication *)application userInfo:(NSDictionary *)userInfo;
@end

@implementation AppDelegate

@synthesize isFirstTimeLoaded;
@synthesize keyPadHeight;
@synthesize winWidth;
@synthesize winHeight;
@synthesize window;
@synthesize checkRechability;
@synthesize isNetWorkAvailable;
@synthesize followingCount;
@synthesize restaurantFollowingCount;
@synthesize fsHandler;
@synthesize twitterHandler;
@synthesize facebookHandler;
@synthesize tumblrHandler;
@synthesize currentUrlToOpen;
@synthesize blockOperation;

@synthesize locations;
@synthesize locationAddress;
@synthesize locationManager;
@synthesize apnsPayloadDict;

-(void)loadNew {
    self.locationAddress = @"Unknown";
    self.locationManager =[[DGLocationManager alloc] init];
    NSString *accesssToken=[Utilities getToken];
    if (accesssToken==nil) {
        [self loadLandingPage];
    }else{
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setObject:[Utilities getFromUserDefault:USERID] forKey:USERID];
        
        [[DataSourceFactory getDataSourceInstance] requestDataWithURLString:GET_PROFILE_URL params:dict modelClass:[UserProfile class] callBack:^(bool success, NSObject *response) {
            if (success) {
                [PageUtil setLoggedin:YES];
                [self loadDishGramHomeTab];
            }
            else{
                [PageUtil setLoggedin:NO];
                landingScreenVC = [[LandingScreen alloc] initWithNibName:@"LandingScreen" bundle:nil];
                self.window.rootViewController = landingScreenVC;
            }
            
        }];
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Let the device know we want to receive push notifications
	[[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    NSDictionary *remoteNotificationObj = [launchOptions valueForKey:@"UIApplicationLaunchOptionsRemoteNotificationKey"];
    //Accept push notification when app is not open
	if (remoteNotificationObj) {
		[self handleRemoteNotification:application userInfo:remoteNotificationObj];
	}
    
    CGRect mainScreenBounds  = [[UIScreen mainScreen] bounds];
    self.window = [[UIWindow alloc] initWithFrame:mainScreenBounds];
    [self.window makeKeyAndVisible];
    
    keyPadHeight = 216;
    winWidth =  mainScreenBounds.size.width;
    winHeight = mainScreenBounds.size.height-20; // Subtracting Status bar height
    
    checkRechability = [Reachability reachabilityForInternetConnection];
    [checkRechability startNotifier];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkNetworkStatus:) name:kReachabilityChangedNotification object:nil];
    [self checkWhetherInternetIsAvailable];
    
    if([[FBSession activeSession] state] == FBSessionStateCreatedTokenLoaded){
        DLog(@"'Already Opened");
    }else{
        DLog(@"not opened");
    }
    
    locations=[[CLLocation alloc] init];
    
    [self loadNew];
    
    [Crashlytics startWithAPIKey:@"eddc21c26fb33b36665da16d1a9967b9d892ed01"];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application
{
    
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [self.locationManager stopLocationFinder];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [self.locationManager startLocationFinder];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    DLog(@"app become active");
    [FBSession.activeSession handleDidBecomeActive];
    
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    DLog(@"app terminate");
    [FBSession.activeSession close];
}


/**
 @amit: ##change for functionality if mail login is there..if user loged in he will get in actual page,
 else let to the landing screen.
 
 
 if user have token id and user id set it into the user default
 ****/
-(BOOL) makeApplicationLoginFromEmailHit: (NSString *)url{
    NSArray *listItems = [url componentsSeparatedByString:@"/"];
    NSString *token=[listItems objectAtIndex:2];
    NSString *userId=[listItems objectAtIndex:3];
    
    if ((token==nil && userId==nil)||([token isEqualToString:@""] &&[ userId isEqualToString:@""])) {
        if (![PageUtil isLoggedin]) {
            [self loadLandingPage];
            return YES;
        }
    }else{
        [Utilities setInUserDefault:token key:TOKEN];
        [Utilities setInUserDefault:userId key:USERID];
        
        if (![PageUtil isLoggedin]) {

            [self loadDishGramHomeTab];
            
        }
        return YES;
    }
    return NO;
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    DLog(@"URL=%@",url);
    
//    DLog(@"RelativeString : %@",url.relativeString);
//    DLog(@"RelativePath : %@",url.relativePath);
//    DLog(@"BaseURL : %@",url.baseURL);
//    DLog(@"SourceApplication : %@", sourceApplication);

    
    
    
    
    
    
    if (currentUrlToOpen == FACEBOOK_URL) {
        return [FBSession.activeSession handleOpenURL:url];
        
        
//        return [FBAppCall handleOpenURL:url
//                      sourceApplication:sourceApplication
//                        fallbackHandler:^(FBAppCall *call) {
//                            // If there is an active session
//                            if (FBSession.activeSession.isOpen) {
//                                // Check the incoming link
//                                [self handleAppLinkData:call.appLinkData];
//                            } else if (call.accessTokenData) {
//                                // If token data is passed in and there's
//                                // no active session.
//                                if ([self handleAppLinkToken:call.accessTokenData]) {
//                                    // Attempt to open the session using the
//                                    // cached token and if successful then
//                                    // check the incoming link
//                                    [self handleAppLinkData:call.appLinkData];
//                                }
//                            }
//                        }];

        
    }else if([[url absoluteString] rangeOfString:@"dishgram:" options:NSCaseInsensitiveSearch].location!=NSNotFound){//if url received from dishgram mail
        /**
         @amit: ##change UIModificatin with veg and non Veg
         ****/
       return [self makeApplicationLoginFromEmailHit:[url absoluteString]];
    }
    else{ // TUMBLR_URL
        return [[TMAPIClient sharedInstance] handleOpenURL:url];
    }
}

- (BOOL)checkWhetherInternetIsAvailable{
    NetworkStatus status = [checkRechability currentReachabilityStatus];
    if(status == NotReachable){
        [Utilities showAlertMessage:NETWORKREACHABILITYALERT andDelegate:nil];
        self.isNetWorkAvailable=false;
    }else if(status == ReachableViaWiFi || status == ReachableViaWWAN ){
        
        self.isNetWorkAvailable=true;
    }

    return self.isNetWorkAvailable;
}

-(void)checkNetworkStatus:(NSNotification *)notice{
    NetworkStatus status = [checkRechability currentReachabilityStatus];
    if(status == NotReachable){
        [Utilities showAlertMessage:NETWORKREACHABILITYALERT andDelegate:nil];
        self.isNetWorkAvailable=false;
    }else if(status == ReachableViaWiFi || status == ReachableViaWWAN ){
        self.isNetWorkAvailable=true;
    }
}

- (void)setSelectedTab:(NSInteger)selection{
    if (selection>=0 && selection<5) {
        [_dgHomeController.dgTabsController setSelectedIndex:selection];
    }
}

- (void)loadDishGramHomeTab{
    _dgHomeController =[[DishgramHomeControllerViewController alloc] init];
    self.window.rootViewController=[_dgHomeController getDisplayController];
}

- (void)loadDishGramExploreTab {
    _dgHomeController =[[DishgramHomeControllerViewController alloc] init];
    DisgramTabBarControllerViewController *controller = ((DisgramTabBarControllerViewController *)[_dgHomeController getDisplayController]);
    controller.selectedIndex = 1;
    self.window.rootViewController=controller;
}

-(void)loadLandingPage {
    [PageUtil setLoggedin:NO];
    landingScreenVC = [[LandingScreen alloc] initWithNibName:@"LandingScreen" bundle:nil];
    self.window.rootViewController = landingScreenVC;
}

// push notification method for geting device token
- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    DLog(@"Register Notification in AppDelegate");
    
    NSString *deviceTokenString = [[[[NSString stringWithFormat:@"%@",deviceToken] stringByReplacingOccurrencesOfString:@" " withString:@""] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""];
    
    DLog(@"Device Token String:%@",deviceTokenString);
    [[NSUserDefaults standardUserDefaults] setObject:deviceTokenString forKey:k_DEVICE_TOKEN];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    //Update device token on server for logged in user
    if ([[NSUserDefaults standardUserDefaults] objectForKey:TOKEN]) {
        DataSourceInterface *dataSourceObj = [DataSourceFactory getDataSourceInstance];
        NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
        [param setObject:[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN] forKey:@"token"];
        [param setObject:deviceTokenString forKey:@"gcmKey"];
        
        [dataSourceObj requestDataWithURLString:SEND_TOKEN_URL params:param  modelClass:nil callBack:^(bool success, NSObject *response) {
        }];
    }
}

//Called When Application failed to register
- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error {
	DLog(@"Failed to get token, error: %@", error);
}

//Called When Application receive remote notification
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    DLog(@"Received Notification in AppDelegate");
    [self handleRemoteNotification:application userInfo:userInfo ];
    
}

//Method to handel the pushnotification when application is not active.
- (void)handleRemoteNotification:(UIApplication *)application userInfo:(NSDictionary *)userInfo {
    DLog(@"Handle Remote Notification in AppDelegate");

    apnsPayloadDict = userInfo;

    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:[[[userInfo objectForKey:@"aps"] objectForKey:@"alert"] objectForKey:@"loc-key"] delegate:self cancelButtonTitle:@"View" otherButtonTitles:@"Cancel", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
        {
            if([[apnsPayloadDict objectForKey:@"type"] isEqualToString:@"DISH_COMMENT"]||[[apnsPayloadDict objectForKey:@"type"] isEqualToString:@"DISH_LOVE"]){
                ViewPostController *viewPostController = [[ViewPostController alloc] initWithNibName:@"ViewPostController" bundle:nil uid:[[[[apnsPayloadDict objectForKey:@"aps"] objectForKey:@"alert"] objectForKey:@"loc-args"] objectAtIndex:1] focusOnAddComment:NO];
                [PageUtil push:viewPostController];
            } else if([[apnsPayloadDict objectForKey:@"type"] isEqualToString:@"FOLLOW_USER"]){
                ProfileController *profileControler = [[ProfileController alloc] initWithNibName:@"ProfileController" bundle:nil uid:[[[[apnsPayloadDict objectForKey:@"aps"] objectForKey:@"alert"] objectForKey:@"loc-args"] objectAtIndex:1]];
                [PageUtil push:profileControler];
            }
            break;
        }
        case 1:{
            apnsPayloadDict = nil;
            break;
        }
        default:
            break;
    }
}




//Invite related Deep linking 




//
//#pragma mark - Helper methods
//
///**
// * Helper method for parsing URL parameters.
// */
//- (NSDictionary*)parseURLParams:(NSString *)query {
//    NSArray *pairs = [query componentsSeparatedByString:@"&"];
//    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
//    for (NSString *pair in pairs) {
//        NSArray *kv = [pair componentsSeparatedByString:@"="];
//        NSString *val =
//        [kv[1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//        params[kv[0]] = val;
//    }
//    return params;
//}
//
///*
// * Helper method to handle incoming request app link
// */
//- (void) handleAppLinkData:(FBAppLinkData *)appLinkData {
//    NSString *targetURLString = appLinkData.originalQueryParameters[@"target_url"];
//    if (targetURLString) {
//        NSURL *targetURL = [NSURL URLWithString:targetURLString];
//        NSDictionary *targetParams = [self parseURLParams:[targetURL query]];
//        NSString *ref = [targetParams valueForKey:@"ref"];
//        // Check for the ref parameter to check if this is one of
//        // our incoming news feed link, otherwise it can be an
//        // an attribution link
//        if ([ref isEqualToString:@"notif"]) {
//            // Get the request id
//            NSString *requestIDParam = targetParams[@"request_ids"];
//            NSArray *requestIDs = [requestIDParam
//                                   componentsSeparatedByString:@","];
//            
//            // Get the request data from a Graph API call to the
//            // request id endpoint
//            [self notificationGet:requestIDs[0]];
//        }
//    }
//}
//
///*
// * Helper method to check incoming token data
// */
//- (BOOL)handleAppLinkToken:(FBAccessTokenData *)appLinkToken {
//    // Initialize a new blank session instance...
//    FBSession *appLinkSession = [[FBSession alloc] initWithAppID:nil
//                                                     permissions:nil
//                                                 defaultAudience:FBSessionDefaultAudienceNone
//                                                 urlSchemeSuffix:nil
//                                              tokenCacheStrategy:[FBSessionTokenCachingStrategy nullCacheInstance] ];
//    [FBSession setActiveSession:appLinkSession];
//    // ... and open it from the App Link's Token.
//    return [appLinkSession openFromAccessTokenData:appLinkToken
//                                 completionHandler:^(FBSession *session,
//                                                     FBSessionState status,
//                                                     NSError *error) {
//                                     // Log any errors
//                                     if (error) {
//                                         NSLog(@"Error using cached token to open a session: %@",
//                                               error.localizedDescription);
//                                     }
//                                 }];
//}
//
//
///*
// * Helper function to get the request data
// */
//- (void) notificationGet:(NSString *)requestid {
//    [FBRequestConnection startWithGraphPath:requestid
//                          completionHandler:^(FBRequestConnection *connection,
//                                              id result,
//                                              NSError *error) {
//                              if (!error) {
//                                  NSString *title;
//                                  NSString *message;
//                                  if (result[@"data"]) {
//                                      title = [NSString
//                                               stringWithFormat:@"%@ sent you a gift",
//                                               result[@"from"][@"name"]];
//                                      NSString *jsonString = result[@"data"];
//                                      NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
//                                      if (!jsonData) {
//                                          NSLog(@"JSON decode error: %@", error);
//                                          return;
//                                      }
//                                      NSError *jsonError = nil;
//                                      NSDictionary *requestData =
//                                      [NSJSONSerialization JSONObjectWithData:jsonData
//                                                                      options:0
//                                                                        error:&jsonError];
//                                      if (jsonError) {
//                                          NSLog(@"JSON decode error: %@", error);
//                                          return;
//                                      }
//                                      message =
//                                      [NSString stringWithFormat:@"Badge: %@, Karma: %@",
//                                       requestData[@"badge_of_awesomeness"],
//                                       requestData[@"social_karma"]];
//                                  } else {
//                                      title = [NSString
//                                               stringWithFormat:@"%@ sent you a request",
//                                               result[@"from"][@"name"]];
//                                      message = result[@"message"];
//                                  }
//                                  UIAlertView *alert = [[UIAlertView alloc]
//                                                        initWithTitle:title
//                                                        message:message
//                                                        delegate:nil
//                                                        cancelButtonTitle:@"OK"
//                                                        otherButtonTitles:nil,
//                                                        nil];
//                                  [alert show];
//                                  
//                                  // Delete the request notification
//                                  [self notificationClear:result[@"id"]];
//                              }
//                          }];
//}
//
///*
// * Helper function to delete the request notification
// */
//- (void) notificationClear:(NSString *)requestid {
//    // Delete the request notification
//    [FBRequestConnection startWithGraphPath:requestid
//                                 parameters:nil
//                                 HTTPMethod:@"DELETE"
//                          completionHandler:^(FBRequestConnection *connection,
//                                              id result,
//                                              NSError *error) {
//                              if (!error) {
//                                  NSLog(@"Request deleted");
//                              }
//                          }];
//}



@end
