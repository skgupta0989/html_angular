//
//  CommentsViewTemplateProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import "NVTemplateProvider.h"
#import "MutableRowDataProvider.h"
#import "DefaultTemplateProvider.h"


@interface CommentsViewTemplateProvider : DefaultTemplateProvider

-(id)init:(NSString *)uid;

@end