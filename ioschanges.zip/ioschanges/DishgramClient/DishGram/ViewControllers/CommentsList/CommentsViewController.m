//
//  CommentsViewController.m
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import "CommentsViewController.h"
#import "NVPagedDataView.h"
#import "CommentsViewTemplateProvider.h"
#import "PageUtil.h"

@interface CommentsViewController ()

@end

@implementation CommentsViewController

- (id)init:(NSString *)dishId
{
    self = [super init];
    if (self) {
        // Custom initialization
        
        dishId_ = dishId;
        invalidated = NO;
        [self addObserverForDelete];
        
        NVPagedDataView *pagedDataView = [[NVPagedDataView alloc] initWithFrame:CGRectMake(0, 0, 300, 600)];
        
        //[pagedDataView setBackgroundColor:[UIColor colorWithRed:.95 green:.95 blue:.95 alpha:1]];
        [pagedDataView setBackgroundColor:[UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1]];
        pagedDataView.templateProvider = [[CommentsViewTemplateProvider alloc] init:dishId];
        pagedDataView.templateProvider.owner = pagedDataView;
        
        // trigger
        [pagedDataView.templateProvider trigger];

        self.view = pagedDataView;
        //self.navigationItem.title=@"Comments";
        CGRect frame = CGRectMake(0, 0, 180, 44);
        UILabel *nav_label = [[UILabel alloc] initWithFrame:frame];
        nav_label.backgroundColor = [UIColor clearColor];
        //nav_label.font = [UIFont boldSystemFontOfSize:15.0];
        [nav_label setFont:[UIFont fontWithName:@"Roboto-Bold" size:18]];
        nav_label.shadowColor = [UIColor whiteColor];
        nav_label.shadowOffset  = CGSizeMake(0.5,0.5);
        nav_label.textAlignment = UITextAlignmentCenter;
        nav_label.textColor = [UIColor blackColor];
        nav_label.text = @"Comments";
        [nav_label sizeToFit];
        self.navigationItem.titleView = nav_label;
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - listeners for data changes

-(void)addObserverForDelete {
    NSString *eventName = [PageUtil removePostEventName:dishId_];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(invalidateThisController:) name:eventName object:nil];
}

-(void)removeObservers {
    NSString *eventName = [PageUtil removePostEventName:dishId_];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:eventName object:nil];
}

-(void)invalidateThisController:(NSNotification *)notification {
    invalidated = YES;
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (invalidated) {
        [PageUtil popVC];
    }
}

@end
