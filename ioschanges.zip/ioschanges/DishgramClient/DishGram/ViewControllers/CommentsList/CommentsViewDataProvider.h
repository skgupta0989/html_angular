//
//  CommentsViewDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import "MutableDefaultDataProvider.h"

@interface CommentsViewDataProvider : MutableDefaultDataProvider {
    NSString *_uid;
}

-(id)init:(NSString *)uid;

@end
