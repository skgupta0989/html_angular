//
//  CommentsViewDataProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import "CommentsViewDataProvider.h"
#import "DishComment.h"

@implementation CommentsViewDataProvider

-(id)init:(NSString *)uid {
    self = [super init:GET_ALL_DISH_COMMENTS respType:[DishComment class]];
    if (self) {
        //
        _uid = uid;
    }
    return self;
}


// overrid the super class method if custom parameters need to be added to the webservice request.
-(NSMutableDictionary *)getRequest {
    NSMutableDictionary *request = [super getRequest];
    
    // START Add custom reqeust parameters here
    [request setObject:_uid forKey:@"dishPlacesId"];
    // END Add custom reqeust parameters here
    
    return request;
}

-(void)onError:(NSString *)message {
    [[[iToast makeText:message]
      setGravity:iToastGravityCenter] show];
}



@end
