//
//  CommentsViewTemplateProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import "CommentsViewTemplateProvider.h"
#import "PageUtil.h"
#import "User.h"
#import "CommentsViewDataProvider.h"
#import "CommentsView.h"

@implementation CommentsViewTemplateProvider

int _cv_tileWidth = 310;
int _cv_tileHeight = 62;

NSString *cvtpStrLock = @"cvtpLock";

-(id)init:(NSString *)uid {
    self = [super init];
    if(self) {
        self.numRows = 0;
        [self reloadDataProvider:uid];
    }
    return self;
}



-(void)reloadDataProvider:(NSString *)uid {
    _rowDataProvider = [[MutableRowDataProvider alloc] initWithPageSize:50 numberOfPagesToCache:10 pagedDataProvider:[[CommentsViewDataProvider alloc] init:uid] nextPageTrigger:50];
    [self setSizeChangedCallBack];
}

-(UIView *)getTemplate:(int)index {
    @synchronized(cvtpStrLock) {
        CommentsView *view = [[CommentsView alloc] initWithFrame:CGRectMake(5,0, _cv_tileWidth, _cv_tileHeight)];
        
        void (^callBack)(NSObject *data) = [self getCallBackMethod:view];
        [_rowDataProvider getRow:index withCallBack:callBack];

        return view;
    }
}

-(void (^)(NSObject *data)) getCallBackMethod:(CommentsView *)masterView {
    
    void (^callBack)(NSObject *data) = ^(NSObject *data){
        if (data) {
            [self performSelectorOnMainThread:@selector(update:)
                                   withObject:^{[masterView populateData:(DishComment *)data];}
                                waitUntilDone:true];
        }
    };
    
    return callBack;
}


-(float)getCellHeight {
    return _cv_tileHeight;
}

@end
