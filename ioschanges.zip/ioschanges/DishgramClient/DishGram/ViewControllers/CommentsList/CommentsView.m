//
//  CommentsView.m
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import "CommentsView.h"
#import "PageUtil.h"
#import "DishComment.h"
#import "User.h"
#import "ProfileController.h"

@implementation CommentsView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIView *subview = [PageUtil loadDecoratedView:self nibName:@"CommentsView"];
        //[subview setBackgroundColor:[UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1]];
         [subview setBackgroundColor:[UIColor whiteColor]];
        [PageUtil decorate:subview decorationName:DecorationTypeList];
    }
    return self;
}

-(void)populateData:(DishComment *)data {
    _data = data;
    self.name.text = data.user.username;
   
    [self.name setFont:[UIFont fontWithName:@"Roboto-Condensed" size:15]];
    [self.comment setFont:[UIFont fontWithName:@"Roboto-Regular" size:12]];
    
    UIGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(nameTapped:)];
    [self.name addGestureRecognizer:gestureRecognizer];
    self.name.userInteractionEnabled = YES;
    
    [PageUtil centerLabel:self.name];
    
    self.comment.text = data.comment;
    
    [PageUtil centerLabel:self.comment];

    // [PageUtil reposition:self.comment below:self.name withMargin:-5];
    
//    NSLog(@"%f", self.comment.frame.size.height);
    NSString *profileUrl = data.user.userProfileImage;

    // profile image
//    [PageUtil fetchPofileImage:self.primaryProfileImage url:profileUrl notify:nil];
    [PageUtil profileImageViewWithDefaultProfile:self.primaryProfileImage url:profileUrl addProfileHandler:self];
}

-(void)nameTapped:(UIGestureRecognizer *)recognizer {
    [self profileViewTapped];
}

-(void)profileViewTapped {
    ProfileController *profileController = [[ProfileController alloc] initWithNibName:@"ProfileController" bundle:nil uid:_data.user.uid];
    
    [PageUtil push:profileController];
}

@end
