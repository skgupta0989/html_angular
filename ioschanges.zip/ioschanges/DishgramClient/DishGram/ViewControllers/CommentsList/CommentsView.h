//
//  CommentsView.h
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import <UIKit/UIKit.h>
#import "DishComment.h"
#import "NVLabel.h"

@interface CommentsView : UIView {

    DishComment *_data;
}
@property (weak, nonatomic) IBOutlet UIImageView *primaryProfileImage;
@property (weak, nonatomic) IBOutlet NVLabel *name;
@property (weak, nonatomic) IBOutlet NVLabel *comment;

-(void)populateData:(DishComment *)data;

@end
