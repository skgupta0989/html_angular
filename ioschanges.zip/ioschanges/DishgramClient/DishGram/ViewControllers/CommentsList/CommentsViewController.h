//
//  CommentsViewController.h
//  DishGram
//
//  Created by Ramesh Varma on 03/06/13.
//
//

#import <UIKit/UIKit.h>

@interface CommentsViewController : UIViewController {
    NSString *dishId_;
    BOOL invalidated;
}

- (id)init:(NSString *)dishId;

@end
