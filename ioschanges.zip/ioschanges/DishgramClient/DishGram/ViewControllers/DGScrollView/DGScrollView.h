//
//  DGScrollView.h
//  DishGram
//
//  Created by SumanAmit on 30/07/13.
//
//

#import <UIKit/UIKit.h>

@interface DGScrollView : UIScrollView<UIScrollViewDelegate>

@end
