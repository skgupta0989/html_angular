//
//  DGScrollView.m
//  DishGram
//
//  Created by SumanAmit on 30/07/13.
//
//

#import "DGScrollView.h"
#import "PageUtil.h"
@implementation DGScrollView
-(void)awakeFromNib{
        self.delegate=self;
}
-(void)dismiss{
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder)
                                               to:nil
                                             from:nil
                                         forEvent:nil];

    [PageUtil removeDropDown];
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self dismiss];
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder)
                                               to:nil
                                             from:nil
                                         forEvent:nil];

    }
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self dismiss];
}

@end
