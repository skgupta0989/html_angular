//
//  BorderedTextField.h
//  DishGram
//
//  Created by SumanAmit on 05/07/13.
//
//

#import "CustomTextField.h"

@interface BorderedTextField : CustomTextField

@end
