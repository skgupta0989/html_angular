//
//  DishgramThumb.h
//  DishGram
//
//  Created by SumanAmit on 24/05/13.
//
//

#import <UIKit/UIKit.h>

@protocol DishgramThumbProtocol;
@class ImageData;
@interface DishgramThumb : UIView{


}
@property (nonatomic,assign) BOOL inSelectedMode;
@property (nonatomic,weak)     id <DishgramThumbProtocol>delegate;
@property (nonatomic,strong) UIImageView *thumbImageView;
@property (nonatomic,strong) UILabel *thumbLabel;
@property (nonatomic,strong)     ImageData *imageData;

- (void) setFrameImageView:(UIImageView *)image;
- (void) setContentImageView:(UIImage *)image frame:(CGRect)frame;
- (void) setColorForImage;
- (void) setBaseImage:(UIImage*)baseImage;
- (void) setThumbLabelFrame:(CGRect)frame;

- (id) initDisgramThumWithFram:(CGRect)frame type:(DishGramThumbType)thumbType;
- (void) setThumbSelected;

- (void)applyFilter:(UIViewController *)controller andImageFilterCompletion:(void(^)(UIImage * processedImage))complteionCallBack;
-(UIImage *)getProcessedImage:(UIImage *)sourceImage :(GPUImageFilter *)filter;
@end



@protocol DishgramThumbProtocol <NSObject>
-(void) thumbSelected:(DishgramThumb *)view;
@end

