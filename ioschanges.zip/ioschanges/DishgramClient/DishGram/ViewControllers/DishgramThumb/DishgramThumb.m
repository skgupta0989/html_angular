//
//  DishgramThumb.m
//  DishGram
//
//  Created by SumanAmit on 24/05/13.
//
//

#import "DishgramThumb.h"
#import "PageUtil.h"
#import "QuartzCore/QuartzCore.h"
#import "Utilities.h"
@implementation DishgramThumb

@synthesize thumbImageView,thumbLabel;

@synthesize delegate;

@synthesize inSelectedMode,imageData;


-(id)initDisgramThumWithFram:(CGRect)frame type:(DishGramThumbType)thumbType{
    self=[self initWithFrame:frame];
    if (thumbType==DishGramThumbTypeSelectable) {
//        UITapGestureRecognizer *gesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(thumbSelectionAction:)];
//        gesture.numberOfTapsRequired=1;
//        [self addGestureRecognizer:gesture];
    }else if(thumbType==DishgramThumbTypeUnSelectable){
        
    }
    self.inSelectedMode=NO;
    return self;
}
- (id)initWithFrame:(CGRect)frame 
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
//for adding frame image view on thumb
- (void) setFrameImageView:(UIImageView *)image{
    [self addSubview:image];
}

//for adding color for image if required
- (void) setBaseImage:(UIImage*)baseImage{
     self.thumbImageView.image=baseImage;
}
- (void) setThumbLabelFrame:(CGRect)frame{
    self.thumbLabel=[[UILabel alloc] initWithFrame:frame];
    [self addSubview:self.thumbLabel];
}
- (void) setContentImageView:(UIImage *)image frame:(CGRect)frame{
    self.thumbImageView=[[UIImageView alloc] initWithFrame:frame];
    self.thumbImageView.image=image;
    [self addSubview:self.thumbImageView];
    [self bringSubviewToFront:self.thumbImageView];
    
}

#pragma mark- thumb selection Action
-(void)thumbSelectionAction:(UIGestureRecognizer *)gesture{
    [self setThumbSelected];
}
- (void) setThumbSelected{
        [delegate thumbSelected:self];
}


- (void)applyFilter:(UIViewController *)controller andImageFilterCompletion:(void(^)(UIImage * processedImage))complteionCallBack{
    
}
-(void)processImagefor:(NSDictionary *)thread{
    @autoreleasepool {
        UIImage *image=[thread valueForKey:@"image"];
        GPUImageFilter *filter=[thread valueForKey:@"filter"];
        CGRect imageViewRect=CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
        GPUImageView *primaryView1 = [[GPUImageView alloc] initWithFrame:imageViewRect];
        GPUImagePicture  *sourcePicture1 = [[GPUImagePicture alloc] initWithImage:image smoothlyScaleOutput:YES];
        
        [filter forceProcessingAtSize:primaryView1.sizeInPixels];
        [sourcePicture1 addTarget:filter];
        [filter addTarget:primaryView1];
        
        [sourcePicture1 processImage];
        
        UIImage *timage=[filter imageFromCurrentlyProcessedOutputWithOrientation:image.imageOrientation];
        [sourcePicture1 removeAllTargets];
        [self.thumbImageView performSelectorOnMainThread:@selector(setImage:) withObject:timage waitUntilDone:NO];
        
    }
}

-(UIImage *)getProcessedImage:(UIImage *)sourceImage :(GPUImageFilter *)filter{
    NSMutableDictionary *diction=[[NSMutableDictionary alloc] init];
    [diction setObject:sourceImage forKey:@"image"];
    [diction setObject:filter forKey:@"filter"];
    [NSThread detachNewThreadSelector:@selector(processImagefor:) toTarget:self withObject:diction];
    return sourceImage;
}
-(void)dealloc{
    self.delegate=nil;
    self.thumbLabel=nil;
    self.thumbImageView=nil;
    self.imageData=nil;
    DLog();
}

@end
