//
//  DGLocationManager.m
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import "DGLocationManager.h"
#import "AppDelegate.h"
#import "PageUtil.h"

#define DISTANCE_FILTER 100.0
#define DEFAULT_LOCATION_UPDATE_DELAY 120


@implementation DGLocationManager

NSDate *locationManagerStartDate;

-(id)init{
    self=[super init];
    if (self) {
        [self startLocMan];
    }
    return self;
}

-(void)startLocMan {
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    locationManager.distanceFilter = DISTANCE_FILTER;
    locationManagerStartDate = [NSDate date];
    [self startLocationFinder];
}


- (void)startLocationFinder {
    [locationManager startUpdatingLocation];
}

- (void) stopLocationFinder
{
    [locationManager stopUpdatingLocation];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    [locationManager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if (![self isValidLocation:newLocation withOldLocation:oldLocation]) {
        return;
    }
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // check if the distance change is atleast DISTANCE_FILTER
    if (appDelegate.locations != nil && [DGLocationManager getDistanceInMeterFrom:newLocation to:appDelegate.locations].doubleValue < DISTANCE_FILTER) {
        NSLog(@"not much difference in location. So returning");
                
        return;
    }
    
    [locationManager stopUpdatingLocation];

    appDelegate.locations = newLocation;
    appDelegate.locationAddress = [PageUtil locationAddress:newLocation.coordinate.latitude lng:newLocation.coordinate.longitude];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"DG_LOC_UPDATED" object:self];
    [self performSelector:@selector(startLocationFinder) withObject:nil afterDelay:DEFAULT_LOCATION_UPDATE_DELAY];
    // [locationManager startUpdatingLocation];
}


- (BOOL)isValidLocation:(CLLocation *)newLocation
        withOldLocation:(CLLocation *)oldLocation
{
    // Filter out nil locations
    if (!newLocation)
    {
        return NO;
    }
    
    // Filter out points by invalid accuracy
    if (newLocation.horizontalAccuracy < 0)
    {
        return NO;
    }
    
    // Filter out points that are out of order
    NSTimeInterval secondsSinceLastPoint =
    [newLocation.timestamp timeIntervalSinceDate:oldLocation.timestamp];
    
    if (secondsSinceLastPoint < 0)
    {
        return NO;
    }
    
    // Filter out points created before the manager was initialized
    NSTimeInterval secondsSinceManagerStarted =
    [newLocation.timestamp timeIntervalSinceDate:locationManagerStartDate];
    
    if (secondsSinceManagerStarted < 0)
    {
        return NO;
    }
    
    // The newLocation is good to use
    return YES;
}


#pragma mark -
+ (CLLocation *) getCLLocationOf:(CGFloat)latitude longitude:(CGFloat)longitude{
    CLLocation *restaurnatLoc = [[CLLocation alloc] initWithLatitude:latitude longitude:longitude];
    return restaurnatLoc;
}

+ (NSNumber *) getDistanceInMeterFrom:(CLLocation *)userLocation to:(CLLocation *)desiredLocation{
    CLLocationDistance distance=[userLocation distanceFromLocation:desiredLocation ];
    return [NSNumber numberWithFloat:distance];
}

+ (NSNumber *) getDistanceInKMFrom:(CLLocation *)userLocation to:(CLLocation *)desiredLocation{
    CLLocationDistance distance=[userLocation distanceFromLocation:desiredLocation ];
    return [NSNumber numberWithDouble:(double)(distance/(double)1000)];
}

+ (NSNumber *) getDistanceInMileFrom:(CLLocation *)userLocation to:(CLLocation *)desiredLocation{
    CLLocationDistance distance=[userLocation distanceFromLocation:desiredLocation ];
    return [NSNumber numberWithDouble:((double)distance/(double)1609.344)];
}

@end
