//
//  DGLocationManager.h
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

#define DG_LOC_UPDATED @"DG_LOC_UPDATED"

@interface DGLocationManager : NSObject<CLLocationManagerDelegate>
{
    CLLocationManager  *locationManager;
}

// - (void) getDeviceCurrentLocation:(void (^)(CLLocation* response)) callBack;
- (void)startLocationFinder;
- (void)stopLocationFinder;
- (BOOL)isValidLocation:(CLLocation *)newLocation
        withOldLocation:(CLLocation *)oldLocation;

+ (NSNumber *) getDistanceInMeterFrom:(CLLocation *)userLocation to:(CLLocation *)desiredLocation;
+ (NSNumber *) getDistanceInKMFrom:(CLLocation *)userLocation to:(CLLocation *)desiredLocation;
+ (NSNumber *) getDistanceInMileFrom:(CLLocation *)userLocation to:(CLLocation *)desiredLocation;
+ (CLLocation *) getCLLocationOf:(CGFloat)latitude longitude:(CGFloat)longitude;

@end
