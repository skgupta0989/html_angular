//
//  DishgramHomeControllerViewController.h
//  DishGram
//
//  Created by SumanAmit on 23/05/13.
//
//

#import <UIKit/UIKit.h>
#import "DisgramTabBarControllerViewController.h"

#import "DishDraft.h"
#import "ImageCropView.h"

@class PostDishViewController,ProfileController,DGRestuarentViewController;

@interface DishgramHomeControllerViewController : UIViewController<UITabBarControllerDelegate,ButtonSelectionDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate, CropDelegate>{
    PostDishViewController *simpleVCMid;
    UIViewController *lastSelectedController;
    ProfileController *profileController;

}
@property (nonatomic,strong)    DisgramTabBarControllerViewController *dgTabsController;
-(DisgramTabBarControllerViewController *)getDisplayController;

// tab to be selected.
// subSelection indicates which subtab to be selected. -1 indicates that no need to change existing selection
-(void)changeTabSelected:(int)tabNumber subSectionInTab:(int)subSection;
-(UINavigationController *)navigationControllerOf:(int)index;
@end
