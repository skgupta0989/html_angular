//
//  DishgramHomeControllerViewController.m
//  DishGram
//
//  Created by SumanAmit on 23/05/13.
//
//

#import "DishgramHomeControllerViewController.h"
#import "DisgramTabBarControllerViewController.h"
#import "LandingScreen.h"
#import "AppDelegate.h"
#import "PostDishViewController.h"
#import "ActivityFeedViewController.h"
#import "ProfileController.h"
#import "ExploreViewController.h"
#import "RecentUpdatesViewController.h"
#import "DGRestuarentViewController.h"
#import "PageUtil.h"



@interface DishgramHomeControllerViewController ()

@end

@implementation DishgramHomeControllerViewController
@synthesize dgTabsController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

}
-(DisgramTabBarControllerViewController *)getDisplayController{
    self.dgTabsController=nil;
    self.dgTabsController=[[DisgramTabBarControllerViewController alloc] init];
    self.dgTabsController.delegate=self;
    self.dgTabsController.buttonSelectionDelegate=self;
    
    [self.dgTabsController addCenterButtonWithImage:[UIImage imageNamed:@"post_sml_normal.png"] highlightImage:[UIImage imageNamed:@"post_sml_active.png"]];
    
    ActivityFeedViewController *homeViewRootController=[[ActivityFeedViewController alloc] init];
    [homeViewRootController.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"home_sml_active"] withFinishedUnselectedImage:[UIImage imageNamed:@"home_sml_normal"]];
    UINavigationController *_homeNavigationController=[[UINavigationController alloc] initWithRootViewController:homeViewRootController];
    _homeNavigationController.delegate=self;
     _homeNavigationController.navigationBar.tintColor = [UIColor colorWithRed:110/255.0f green:110/255.0f blue:110/255.0f alpha:1];
    _homeNavigationController.navigationBarHidden = NO;
    
    ExploreViewController *simpleVC1=[[ExploreViewController alloc] initWithNibName:@"ExploreViewController" bundle:nil];
    [simpleVC1.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"explore_sml_active"] withFinishedUnselectedImage:[UIImage imageNamed:@"explore_sml_normal"]];
    UINavigationController *_exploreNavigationController=[[UINavigationController alloc] initWithRootViewController:simpleVC1];
    _exploreNavigationController.delegate=self;
    _exploreNavigationController.navigationBar.tintColor = [UIColor colorWithRed:110/255.0f green:110/255.0f blue:110/255.0f alpha:1];
    
    UIViewController *fakeViewController=[[UIViewController alloc] init];
    fakeViewController.view.backgroundColor=[UIColor whiteColor];
    UINavigationController * _postNavigationController=[[UINavigationController alloc] initWithRootViewController:fakeViewController];
    _postNavigationController.navigationBar.tintColor = [UIColor colorWithRed:110/255.0f green:110/255.0f blue:110/255.0f alpha:1];
    _postNavigationController.delegate=self;
    
    RecentUpdatesViewController *simpleVC2 = [[RecentUpdatesViewController alloc] initWithNibName:@"RecentUpdatesViewController" bundle:nil];
    [simpleVC2.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"feed_sml_active"] withFinishedUnselectedImage:[UIImage imageNamed:@"feed_sml_normal"]];
    
   UINavigationController * _feedNavigationController=[[UINavigationController alloc] initWithRootViewController:simpleVC2];
    _feedNavigationController.delegate=self;
    _feedNavigationController.navigationBar.tintColor = [UIColor colorWithRed:110/255.0f green:110/255.0f blue:110/255.0f alpha:1];
    [_feedNavigationController.navigationBar setOpaque:YES];
    
    profileController=nil;
    profileController=[[ProfileController alloc] initWithNibName:@"ProfileController" bundle:nil uid:nil];

    
    [profileController.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"profile_sml_active"] withFinishedUnselectedImage:[UIImage imageNamed:@"profile_sml_normal"]];
    UINavigationController * _profileNavigationController=[[UINavigationController alloc] initWithRootViewController:profileController];
    _profileNavigationController.delegate=self;
    _profileNavigationController.navigationBar.tintColor = [UIColor colorWithRed:110/255.0f green:110/255.0f blue:110/255.0f alpha:1];
    [_profileNavigationController.navigationBar setOpaque:YES];


    self.dgTabsController.viewControllers=[NSArray arrayWithObjects:_homeNavigationController,_exploreNavigationController,_postNavigationController,_feedNavigationController,_profileNavigationController, nil];
    

    return self.dgTabsController;
}

-(void)buttonSelectedAction:(id)sender{
    if (self.dgTabsController.selectedIndex==2) {
       
    }else{
        [self.dgTabsController hideDisgramButton];
        UIImagePickerController *image=[[UIImagePickerController alloc] init];
        image.delegate=self;
        UIButton *btn=(UIButton *)sender;
        if (btn.tag==10001) {
            [image setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            [self.dgTabsController presentViewController:image animated:YES completion:nil];
            
        }else if(btn.tag==10002){
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                [image setSourceType:UIImagePickerControllerSourceTypeCamera];
                [self.dgTabsController presentViewController:image animated:YES completion:nil];
                
            }else{
                [[[iToast makeText:NSLocalizedString( @"Camera not supported", @"")]
                  setGravity:iToastGravityBottom] show];
            }
            
        }else if(btn.tag==10003){
            
            //@Ashish
//            dishDraft=nil;
//            @autoreleasepool {
                [self cleanPost];
            
            
                DishDraft *dishDraft = [PageUtil newDishDraft];
                Draft *d = [[Draft alloc] init];
                d.uid = [NSNumber numberWithInteger:-1];
                dishDraft.draft = d;
                dishDraft.dishMode = dishModeDraft;
                
                DGRestuarentViewController  *draftRestuarentVC = [[DGRestuarentViewController alloc] initWithNibName:@"DGRestuarentViewController" bundle:nil];
                draftRestuarentVC.dishDraft = dishDraft;
//                dishDraft=nil;
                
            [self.dgTabsController.button setBackgroundImage:BUTTON_SELECTED_IMAGE forState:UIControlStateNormal];
            self.dgTabsController.isCenterButtonSelected=YES;
            

                int selectedIndex=2;
                [self.dgTabsController setSelectedIndex:selectedIndex];
            [self.dgTabsController.button setBackgroundImage:BUTTON_SELECTED_IMAGE forState:UIControlStateNormal];
            self.dgTabsController.isCenterButtonSelected=YES;

                [PageUtil push:draftRestuarentVC];
                
               // draftRestuarentVC=nil;
                
            }

            
        }
 //   }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
#pragma mark- tabbardelegate method

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    [self.dgTabsController.button setBackgroundImage:BUTTON_UN_SELECTED_IMAGE forState:UIControlStateNormal];
    
    NSLog(@"%d",    tabBarController.selectedIndex);

}
-(BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    
    // check if user is logged in before proceeding further.
    if (![PageUtil isLoggedin]) {
        [PageUtil requiresLogin];
        return NO;
    }

    if (self.dgTabsController.isCenterButtonSelected==YES) {
        [[[iToast makeText:NSLocalizedString( @"Please Save/Discard Draft", @"")]
          setGravity:iToastGravityCenter] show];
        return NO;
    }else
    {
        return YES;
    }
    
}
- (UIImage*) scaleImage:(UIImage*)image toSize:(CGSize)newSize {
    CGSize scaledSize = newSize;
    float scaleFactor = 1.0;
    if( image.size.width > image.size.height ) {
        scaleFactor = image.size.width / image.size.height;
        scaledSize.width = newSize.width;
        scaledSize.height = newSize.height / scaleFactor;
    }
    else {
        scaleFactor = image.size.height / image.size.width;
        scaledSize.height = newSize.height;
        scaledSize.width = newSize.width / scaleFactor;
    }
    
    UIGraphicsBeginImageContextWithOptions( scaledSize, NO, 0.0 );
    CGRect scaledImageRect = CGRectMake( 0.0, 0.0, scaledSize.width, scaledSize.height );
    [image drawInRect:scaledImageRect];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
}

#pragma mark- UIImagePicker Delegate
//select a picture and 

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    [self.dgTabsController dismissModalViewControllerAnimated:YES];
    
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [PageUtil showImageCropView:image heightRatio:1.0 minHeight:500 maxHeight:1024 delegate:self];
}

-(void)cancelled {
    // TODO.. do some thing..
    [self.dgTabsController.button setBackgroundImage:BUTTON_UN_SELECTED_IMAGE forState:UIControlStateNormal];
    self.dgTabsController.isCenterButtonSelected=NO;

}

-(void)croppedImage:(UIImage *)image {

    DishDraft *dishdraft=[PageUtil newDishDraft];
    [PageUtil setImageForDishDraft:dishdraft image:image];
    [PageUtil uploadDishImageForPost:dishdraft];
    
    DGRestuarentViewController *restuarenVC=[[DGRestuarentViewController alloc] initWithNibName:@"DGRestuarentViewController" bundle:nil];
    restuarenVC.dishDraft=dishdraft;
    
    [PageUtil push:restuarenVC];
    
    
    
    
    
    /**
     @amit: ##change UIModificatin removing image filter view controller
     Action:Comment of code, added new logic
     ****/

/************
    PostDishViewController *simpleVCMid1=[[PostDishViewController alloc] initWithDishDraft:nil];
    [simpleVCMid1 setImageForFilter:image basicInfo:nil];



    
    [self changeTabSelected:2 subSectionInTab:0];
    

    [self.dgTabsController.button setBackgroundImage:BUTTON_SELECTED_IMAGE forState:UIControlStateNormal];
    self.dgTabsController.isCenterButtonSelected=YES;
    

    [PageUtil push:simpleVCMid1];
****************/

}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate.window.rootViewController dismissModalViewControllerAnimated:YES];    
    self.dgTabsController.isCenterButtonSelected=NO;    
}
-(void)cleanPost{
         UINavigationController *nav=   [self navigationControllerOf:2];
    NSArray *controllers = [nav viewControllers];
    for (int i = 0; i < controllers.count; ++i) {
        UIViewController *controller = [controllers objectAtIndex:i];
        NSLog(@">>>%@",controller);
    }

    //simpleVCMid=nil;
        
}
-(void)changeTabSelected:(int)tabNumber subSectionInTab:(int)subSection {
    if (tabNumber!=2) {
    [self cleanPost];
    }
    [self.dgTabsController.button setBackgroundImage:BUTTON_UN_SELECTED_IMAGE forState:UIControlStateNormal];
    self.dgTabsController.isCenterButtonSelected=NO;
    
    [self.dgTabsController setSelectedIndex:tabNumber];
    
    if (subSection != -1) {
        UINavigationController *nav=[self navigationControllerOf:tabNumber];
        if (tabNumber==4) {
            if (subSection==4) {
                profileController.currentSelectedTab=DRAFTS_TAG;
                [nav viewWillAppear:YES];
            }else{
                profileController.currentSelectedTab=POSTS_TAG;
                [nav viewWillAppear:YES];
            }
            
        }
    }

}
-(UINavigationController *)navigationControllerOf:(int)index{
//    if (index>self.daily.viewControllers.count) {
//        return nil;
//    }
    UIViewController *viewController=[self.dgTabsController.viewControllers objectAtIndex:index];
    UINavigationController *cont=(UINavigationController *)viewController;
    [cont popToRootViewControllerAnimated:NO];
   NSLog(@"number of controllers%d",cont.viewControllers.count);
    return cont;
    

}
-(void)dealloc_constant_VC{
   // draftRestuarentVC=nil;
    simpleVCMid=nil;
    
    UINavigationController *_postNavigationController=[self navigationControllerOf:2];
    _postNavigationController.viewControllers=nil;

}
-(void)dealloc{
    //[self dealloc_constant_VC];
    profileController=nil;
    self.dgTabsController.delegate = nil;
    
    self.dgTabsController=nil;
    DLog();
}

@end
