//
//  AddNewRestuarentVC.m
//  DishGram
//
//  Created by SumanAmit on 05/06/13.
//
//
#import "QuartzCore/QuartzCore.h"
#import "AddNewRestuarentVC.h"
#import "PageUtil.h"
#import "ImageData.h"
#import "DishDetailAddViewController.h"
#import "Place.h"
#import "ZipCode.h"
#import "City.h"
#import "DishDraft.h"
#import "DGImageUploadSingeloton.h"
#import "AppDelegate.h"
#import "DGDropDown.h"
#import "ComboboxView.h"
#import "DGScrollView.h"
#import "FontUtil.h"
#define  DRAFTID @"draftId"

@interface AddNewRestuarentVC ()

@end

@implementation AddNewRestuarentVC
@synthesize dishDraft;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
#pragma mark- WebComboDeleate
-(Class)getTargetClass:(WebComboBoxView *)view{
    if (view.tag==88100) {
    return     [City class];
    }else if(view.tag==88101){
        return [Place class];
    }
    return nil;
}
-(NSString *)getDesiredUrl:(ComboboxView *)view{
    return GET_AUTOFILL;
}
-(NSString *)getTargetMeamber:(ComboboxView *)view{
    if (view.tag==88100) {
    return @"cityName_";
    }else if(view.tag==88101){
        return @"name_";
    }
    return nil;
}
-(NSMutableDictionary *)getParamDictionary:(ComboboxView *)view{
    NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
    [param setObject:[NSNumber numberWithInt:100] forKey:@"max"];
    [param setObject:[NSNumber numberWithInt:0] forKey:@"offset"];
    [param setObject:@"" forKey:@"dishType"];

    if (view.tag==88100) {
        [param setObject:@"CITY" forKey:@"type"];
        return param;

    }else if(view.tag==88101){
        [param setObject:@"PLACE" forKey:@"type"];
        return param;
    }
    return nil;

}
-(void)selectedOption:(NSObject *)object ofView:(ComboboxView *)view{
    if (view.tag==88100) {
        self.dishDraft.city=(City*)object;
        self.selectedCity=(City *)object;

    }else if(view.tag==88101){
        self.dishDraft.place=(Place*)object;
        self.selectedPlace=(Place *)object;
        self.selectedCity=self.selectedPlace.zipCode.city;
        self.dishDraft.city=self.selectedPlace.zipCode.city;
        cityDrop.textField_.text=self.dishDraft.place.zipCode.city.cityName;
        self.addressTextField.text=self.dishDraft.place.address1;
        self.phoneNumberTextField.text=self.dishDraft.place.phone;
    }
}
-(void)initCuisineField{
    cityDrop = [[WebComboBoxView alloc] initWithFrame:CGRectMake(12, 80, 277, 30) data:nil ddSize:120 placeHolder:@"City" ddType:0];
            cityDrop.delegate=self;
            cityDrop.tag=88100;
            cityDrop.backgroundColor = [UIColor whiteColor];
            cityDrop.textField_.returnKeyType=UIReturnKeyNext;
            [self.backgroundView addSubview:cityDrop];
    
}

-(void)initRestuarentNameView{
    restuarentNameDrop = [[WebComboBoxView alloc]initWithFrame:CGRectMake(12, 5 , 277, 30) data:nil ddSize:120 placeHolder:@"Restuarant name" ddType:0];
    restuarentNameDrop.delegate=self;
    restuarentNameDrop.tag=88101;
    restuarentNameDrop.textField_.returnKeyType=UIReturnKeyNext;
    [self.backgroundView addSubview:restuarentNameDrop];
}
#pragma mark-
-(void)fetchDraftDetail{
    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    NSMutableDictionary *params=[[NSMutableDictionary alloc] init];
    [params setObject:self.dishDraft.draft.uid forKey:DRAFTID];
    AddNewRestuarentVC * __weak blocksafeSelf = self;


    [dataSource requestDataWithURLString:GET_DRAFT_DETAIL params:params modelClass:[Draft class] callBack:^(bool success, NSObject *response){
            AddNewRestuarentVC *strongSelf = blocksafeSelf;
        if (success) {
            Draft *draftDetail = (Draft *)response;
            strongSelf.dishDraft.draft=draftDetail;
            strongSelf.dishDraft.userDishDescription=draftDetail.dishPlaceDescription;
            strongSelf.dishDraft.place=draftDetail.place;
            strongSelf.dishDraft.dish=draftDetail.dish;
            strongSelf.dishDraft.dishType=[draftDetail.dish.dishType.uid stringValue];
            strongSelf.dishDraft.ratingForDish=[draftDetail.rating integerValue];
            strongSelf.dishDraft.cuisine=draftDetail.dish.cuisine;
            
            if (draftDetail.city!=nil && draftDetail.city.cityName!=nil) {
            strongSelf.selectedCity=draftDetail.city!=nil?draftDetail.city:draftDetail.place.zipCode.city;
            }else{
            strongSelf.selectedCity=draftDetail.place.zipCode.city!=nil?draftDetail.place.zipCode.city:draftDetail.city;
            }
            

            strongSelf.dishDraft.city=strongSelf.selectedCity;
            strongSelf.dishDraft.draft.city=strongSelf.selectedCity;
            NSLog(@"%@",strongSelf.selectedCity.cityName);
           // strongSelf.dishDraft.dishType=[NSString stringWithFormat:@"%d",[draftDetail.dishType.uid integerValue]];
            strongSelf.selectedPlace=draftDetail.place;
            //strongSelf.dishDraft.draft.place=draftDetail.place;
            
            [strongSelf showRestaurantDetails];
        }else{
            NSLog(@"asf");
        }
    }];

}

#pragma mark -
- (void)viewDidLoad
{
    [super viewDidLoad];
        
    self.titleLabel.font=[FontUtil robotoCondensedWithSize:16];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_pattern.png"]];
    CGRect frame=self.backgroundView.frame;
    UIImageView *imageBackGrounView=[PageUtil scalablePageTile:frame.size.width+10 height:frame.size.height+30 forName:@"bg"];
    imageBackGrounView.frame=CGRectMake(frame.origin.x-1,frame.origin.y-5, frame.size.width, frame.size.height);
    [self.view bringSubviewToFront:self.backgroundView];
    
    UIImageView *dashImage=[PageUtil addDashedHLine:32 start:15 end:290 color:[UIColor grayColor] ofView:self.backgroundView];
    
    [self.backView addSubview:dashImage];

    
    [self.backgroundView setShowsVerticalScrollIndicator:NO];
    self.backgroundView.contentSize=CGSizeMake(self.backgroundView.frame.size.width, self.backgroundView.frame.size.height+100);
    [self configureNavigationControllerFor];
    if ([_isVisible isEqualToString:@"POSTDETAIL"]) {
        self.uploadButton.hidden=YES;
    }
    
    //@Ashish
    self.uploadButton.hidden=YES;

    
    [self initCuisineField];
   // self.nameOfRestuarentTextField.text=_searchedText;
    if (self.dishDraft.dishMode==dishModeDraft) {
        if (_searchedText.length==0) {
            self.nameOfRestuarentTextField.delegate=nil;
            [self.nameOfRestuarentTextField removeFromSuperview];
            [self initRestuarentNameView];
            [self fetchDraftDetail];
            
        }
    }
    
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.nameOfRestuarentTextField setText:_searchedText];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)uploadPictureAction:(id)sender {
}
- (void) configureNavigationControllerFor{
    ImageData *leftButtonData=[[ImageData alloc] init];
    
    NSMutableDictionary *leftDictionary=[[NSMutableDictionary alloc] init];
    [leftDictionary setObject:@"Cancel" forKey:@"title"];
    [leftDictionary setObject:[NSValue valueWithPointer:@selector(barButtonAction:)] forKey:@"selector"];
    [leftDictionary setObject:self forKey:@"target"];
    
    
    leftButtonData.imageInfo=leftDictionary;
    leftButtonData.image=[UIImage imageNamed:@"Post_cancel.png"];
    
    ImageData *rightButtonData=[[ImageData alloc] init];
    
    NSMutableDictionary *rightDictionary=[[NSMutableDictionary alloc] init];
    [rightDictionary setObject:@"   Next   " forKey:@"title"];
    [rightDictionary setObject:[NSValue valueWithPointer:@selector(barButtonAction:)] forKey:@"selector"];
    [rightDictionary setObject:self forKey:@"target"];
    
    
    rightButtonData.imageInfo=rightDictionary;
    rightButtonData.image=[UIImage imageNamed:@"Post_Next.png"];
    
    
    if(self.dishDraft.dishMode==dishModePost)
        [Utilities  setNavigation:@"Post" leftButtonInfo:leftButtonData rightButtonInfo:rightButtonData on:self.navigationItem];
    else
        [Utilities  setNavigation:@"Draft" leftButtonInfo:leftButtonData rightButtonInfo:rightButtonData on:self.navigationItem];

}
-(BOOL)isTextFieldIsEmpty:(UITextField *)textField{
    if (textField.text==nil||[textField.text isEqualToString:@""]) {
        return NO;
    }else{
        NSString *rawString = [textField text];
        NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
        if ([trimmed length] == 0) {
            return NO;
        }
        textField.text=trimmed;

    }
    return YES;
}
- (BOOL)isPhoneNumberValid:(NSString *)phoneNumber{
    if(phoneNumber != nil){
    NSCharacterSet *alphaNums = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *inStringSet = [NSCharacterSet characterSetWithCharactersInString:phoneNumber];
    return  [alphaNums isSupersetOfSet:inStringSet];
    }
    return YES;
}


-(NSString *)checkMandetoryField{
    
    if (self.dishDraft.dishMode==dishModePost&&![self isTextFieldIsEmpty:_nameOfRestuarentTextField]) {
        return @"Please fill Restuarent Name";
    }else if(![self isTextFieldIsEmpty:_addressTextField]){
        return @"Please fill Address";
    }else if(![self isTextFieldIsEmpty:cityDrop.textField_]){
        return @"Please select City";
    }
//    else if(![self isTextFieldIsEmpty:_phoneNumberTextField]){
//        return @"Please Enter Phone number";
//    }
//   else if(![self isPhoneNumberValid:_phoneNumberTextField.text]){
//        return @"Please enter valid Phone number";
//    }
    else if(![cityDrop.textField_.text isEqualToString:self.selectedCity.cityName]){
        return @"Please select city from City list";
    }
    return nil;
}

- (void)fillDishDraftModel{

    AppDelegate *delegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    if (self.dishDraft.place==nil) {
        Place *place=[[Place alloc] init];
        place.uid=[NSNumber numberWithInt:-1];
//        place.name=self.nameOfRestuarentTextField.text;
        if (self.nameOfRestuarentTextField.text.length==0) {
            if (restuarentNameDrop.textField_.text!=nil) {
                place.name=restuarentNameDrop.textField_.text;
            }
        }else{
            place.name=self.nameOfRestuarentTextField.text;
        }

        place.address1=self.addressTextField.text;
        place.phone=self.phoneNumberTextField.text;
        ZipCode *zipCode=[[ZipCode alloc] init];
        zipCode.city=self.selectedCity;
        place.zipCode=zipCode;
        place.latitude=[NSNumber numberWithFloat:delegate.locations.coordinate.latitude];
        place.longitude=[NSNumber numberWithFloat:delegate.locations.coordinate.longitude];
        self.dishDraft.place=place;
        self.dishDraft.city=self.selectedCity;
    }else{
        if (![dishDraft.place.phone isEqualToString:self.phoneNumberTextField.text]) {
            dishDraft.place.uid=[NSNumber numberWithInt:-1];
        }
        if (self.nameOfRestuarentTextField.text.length==0) {
            if (restuarentNameDrop.textField_.text!=nil) {
                self.dishDraft.place.name=restuarentNameDrop.textField_.text;
            }
        }else{
                self.dishDraft.place.name=self.nameOfRestuarentTextField.text;
        }

        self.dishDraft.place.phone=self.phoneNumberTextField.text;
        self.dishDraft.place.address1=self.addressTextField.text;
        self.dishDraft.place.zipCode.city=self.selectedCity;
        self.dishDraft.city=self.selectedCity;
    }
    
}


#pragma mark-
-(void)showDishDetail{
    NSString *response=[self checkMandetoryField];
    if (response==nil) {
        if (self.dishDraft.dishMode == dishModePost) {
            [self fillDishDraftModel];
            [self showDishDetailAddVC];
        }
        else if (self.dishDraft.dishMode == dishModeDraft) {

            [self fillDishDraftModel];
            if (![self.dishDraft.place.phone isEqualToString:_phoneNumberTextField.text] ) {
                self.dishDraft.place.uid=[NSNumber numberWithInt:-1];
            }

            self.dishDraft.place.phone=_phoneNumberTextField.text;
            AddNewRestuarentVC * __weak blocksafeSelf = self;
           
            [[DGImageUploadSingeloton singelton] uploadNewDraft:self.dishDraft callback:^(id response) {
                AddNewRestuarentVC *strongSelf = blocksafeSelf;
                NSLog(@"POSTED DRAFT ID:%@",strongSelf.dishDraft.draft.uid);
                if (strongSelf.dishDraft.draft.uid) {
                    //[strongSelf showDishDetailAddVC];

                    DishDetailAddViewController *dishDetail=[[DishDetailAddViewController alloc] initWithNibName:@"DishDetailAddViewController" bundle:nil];
                    dishDetail.dishDraft=blocksafeSelf.dishDraft;
                    [PageUtil push:dishDetail];
                }
                else {
                    NSLog(@"Unable to post draft on server !!!");
                }
            }];
        }

    }
    else{
        [[[iToast makeText:response]setGravity:iToastGravityCenter]show];
    }


}

- (void)showDishDetailAddVC {
    DishDetailAddViewController *dishDetail=[[DishDetailAddViewController alloc] initWithNibName:@"DishDetailAddViewController" bundle:nil];
   dishDetail.dishDraft=self.dishDraft;
    [PageUtil push:dishDetail];
}

-(void)barButtonAction:(id)sender{
  //  [cityDrop removeDropDownView];
    UIButton *barItem=(UIButton *)sender;
    if (barItem.tag==2001) {
         [[DGImageUploadSingeloton singelton] discardDraft:self.dishDraft target:self];
    }else if(barItem.tag==2002){
        [self showDishDetail];
    }
}

#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [Utilities makeTextFieldVisibleForRect:textField];
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField==_nameOfRestuarentTextField) {        
        [self.addressTextField becomeFirstResponder];
    }else if(textField==self.addressTextField){
        [cityDrop.textField_ becomeFirstResponder];
    }else if (textField==cityDrop.textField_) {        
        [self.phoneNumberTextField becomeFirstResponder];
    }else if(textField==self.phoneNumberTextField){
        [self showDishDetail];
    }
    [Utilities makeTextFieldVisibleForRect:cityDrop.textField_];
    return YES;
}
- (void)textFieldReturn:(ComboboxView *)view{
    [self textFieldShouldReturn:view.textField_];
    [cityDrop removeDropDownView];
}
#pragma mark -UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex==0) {
        [self.dishDraft discardDraft];
        AppDelegate *delgate=(AppDelegate *)[UIApplication sharedApplication].delegate;
        [delgate.dgHomeController changeTabSelected:4 subSectionInTab:4];

    }else if(buttonIndex==1){
        
        [self performSelector:@selector(fillDishDraftModel)];
        
        [self.dishDraft uploadDraftJsonWithCallback:^(id response) {
            AppDelegate *delgate=(AppDelegate *)[UIApplication sharedApplication].delegate;
            [delgate.dgHomeController changeTabSelected:4 subSectionInTab:4];

            if (response)
                NSLog(@"%@",response);
            else
                DLog(@"Unable to save draft to server");
            
        }];
        
    }
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [cityDrop removeDropDownView];
    [self.view endEditing:YES];
}
- (void)viewDidUnload {
    [self setNameOfRestuarentTextField:nil];
    [self setAddressTextField:nil];
    [self setPhoneNumberTextField:nil];
    [self setBackgroundView:nil];
    [self setUploadButton:nil];
    [self setBackView:nil];
    [self setTitleLabel:nil];
    [super viewDidUnload];
}

#pragma mark- Show Restaurant Detail- 
- (void)showRestaurantDetails {    
    [restuarentNameDrop.textField_ setText:self.dishDraft.draft.place.name];
    [self.addressTextField setText:self.dishDraft.draft.place.address1];
    [self.phoneNumberTextField setText:self.dishDraft.draft.place.phone];
    [cityDrop.textField_ setText:self.dishDraft.draft.city.cityName];
}

-(void)dealloc{
    [restuarentNameDrop.textField_ resignFirstResponder];
    [self.addressTextField resignFirstResponder];
    [self.phoneNumberTextField resignFirstResponder];
    [cityDrop.textField_ resignFirstResponder];
    [self.nameOfRestuarentTextField resignFirstResponder];

    DLog(@"AddNewRestuarant Dealloc" );
}
@end
