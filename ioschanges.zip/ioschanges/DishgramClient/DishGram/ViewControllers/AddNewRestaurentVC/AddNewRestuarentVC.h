//
//  AddNewRestuarentVC.h
//  DishGram
//
//  Created by SumanAmit on 05/06/13.
//
//

#import <UIKit/UIKit.h>
#import "CustomTextField.h"
#import "WebComboBoxView.h"
@class DishDraft;
@class City;
@class DGDropDown;
@class Place;
@interface AddNewRestuarentVC : UIViewController<UITextFieldDelegate,ComboBoxViewDelegate>{
  


    WebComboBoxView *cityDrop;
    WebComboBoxView *restuarentNameDrop;
    
}

- (IBAction)uploadPictureAction:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UIView *backView;
@property (strong, nonatomic) IBOutlet UIButton *uploadButton;
@property (strong, nonatomic) IBOutlet UITextField *nameOfRestuarentTextField;
@property (strong, nonatomic) IBOutlet UITextField *addressTextField;
@property (strong, nonatomic) IBOutlet UITextField *phoneNumberTextField;
@property (strong, nonatomic) IBOutlet UIScrollView *backgroundView;
@property (strong, nonatomic) NSString *searchedText,*isVisible;
@property (strong,nonatomic)  DishDraft *dishDraft;
@property (strong,nonatomic)    City *selectedCity;
@property (strong, nonatomic)    Place *selectedPlace;
@end
