//
//  CustomTableCellForFollowFriendsCell.m
//  DishGram
//
//  Created by Rags on 02/05/13.
//
//

#import "CustomTableCellForFollowFriendsCell.h"
#import <QuartzCore/QuartzCore.h>
#import "FriendsUserInformation.h"
#import "Utilities.h"
#import "PageUtil.h"



@implementation CustomTableCellForFollowFriendsCell
@synthesize friendProfileImage;
@synthesize friendName;
@synthesize friendsPost;
@synthesize friendsFollowers;
@synthesize followbtn;
@synthesize lineLabel;
@synthesize cellDelegate;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        // image  for the  friends profile image
        
        cellHeight = 47;
        
//        self.friendProfileImage = [PageUtil profileImageView];
        self.friendProfileImage = [[UIImageView alloc] initWithFrame:CGRectMake(14, 0, 44, 44)];
        [self.contentView addSubview:self.friendProfileImage];
        
        // add the labels for the friends name , post and followers
        
        self.friendName = [self prepareLabelWithFontSize:14.0 andFrame:CGRectMake(62, 8, 180, 16)];
        self.friendName.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        
        
        self.friendsPost = [self prepareLabelWithFontSize:12.0 andFrame:CGRectMake(62, 26, 58, 14)];
        self.friendsPost.text=@"post";
        self.friendsPost.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        self.lineLabel = [self prepareLabelWithFontSize:12.0 andFrame:CGRectMake(106, 26, 4,14)];
        
        self.lineLabel.text=@"|";
        self.lineLabel.textAlignment= UITextAlignmentCenter;
        
        self.friendsFollowers = [self prepareLabelWithFontSize:12.0 andFrame:CGRectMake(112, 26, 80, 14)];
        self.friendsFollowers.text=@"Followers";
        self.friendsFollowers.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        self.followbtn = [[UIButton alloc] initWithFrame:CGRectMake(230, 9, 90, 29)];
        [self.followbtn setImage:[UIImage imageNamed:@"follow.png"] forState:UIControlStateNormal];
        [self.followbtn addTarget:self action:@selector(followbtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.followbtn];
        [self createSeparator];
        appDelegate = [[UIApplication sharedApplication] delegate];
        
    }
    return self;
}

-(void)loadCellData:(FriendsUserInformation*)frndsUserInfo{
    
    @autoreleasepool {
        
        cellFrndsUserInfo = nil;
        cellFrndsUserInfo = frndsUserInfo;
        self.friendName.text= frndsUserInfo.user.username;
        self.friendsPost.text =[NSString stringWithFormat:@"%d Posts",[frndsUserInfo.postsCount intValue]];
        self.friendsFollowers.text= [NSString stringWithFormat:@"%d Followers",[frndsUserInfo.followersCount intValue]];
        localFollowersCount = [frndsUserInfo.followersCount intValue];

        //        [PageUtil fetchPofileImage:self.friendProfileImage url:cellFrndsUserInfo.profileImageURL notify:nil];
        
        [self.followbtn setTag:frndsUserInfo.rowNumber];
        
        followBtnState = frndsUserInfo.isFollowed;
        if (frndsUserInfo.isFollowed == true) {
            [self.followbtn setImage:[UIImage imageNamed:@"unfollow.png"] forState:UIControlStateNormal];
        }
        else{
            [self.followbtn setImage:[UIImage imageNamed:@"follow.png"] forState:UIControlStateNormal];
        }

    }
       
}

//customized the label font and text color and frame
- (UILabel *)prepareLabelWithFontSize:(CGFloat)fontSize andFrame:(CGRect)frame;{
    
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.textColor =[UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0];
    label.font =[UIFont fontWithName:@"Roboto-Condensed" size:fontSize];
    [self.contentView addSubview:label];
    return label;
    
}



-(void)createSeparator{
    
    UIView *separatorView = [[UIView alloc] initWithFrame:CGRectMake(10, 46, 300, 1)];
    separatorView.backgroundColor = [UIColor colorWithRed:218.0/255 green:218.0/255 blue:218.0/255 alpha:1.0];
    [self addSubview:separatorView];
    
}

//// button Action
-(void)followbtnClick:(id)sender{
    if ([appDelegate checkWhetherInternetIsAvailable]) {
      
        if (followBtnState == SHOWING_FOLLOW) {
            
            followBtnState = SHOWING_UNFOLLOW;
            [(UIButton*)sender setImage:[UIImage imageNamed:@"unfollow.png"] forState:UIControlStateNormal];
            localFollowersCount = (localFollowersCount+1);
        }
        else{
            followBtnState = SHOWING_FOLLOW;
            [(UIButton*)sender setImage:[UIImage imageNamed:@"follow.png"] forState:UIControlStateNormal];
            localFollowersCount = localFollowersCount-1;
        }
        self.friendsFollowers.text= [NSString stringWithFormat:@"%d Followers",localFollowersCount];
        [self.cellDelegate addRemoveUserInFollowArray:cellFrndsUserInfo];

    }
    
        
}


@end
