//
//  DishPostViewController.m
//  DishGram
//
//  Created by Ramesh Varma on 13/06/13.
//
//

#import "DishPostViewController.h"
#import "NVPagedDataView.h"
#import "DishPostTemplateProvider.h"
#import "DishPostDataProvider.h"
#import "RestaurantInfoHeaderView.h"
#import "PageUtil.h"
#import "PlaceInfoRD.h"
#import "NVSession.h"


@implementation DishPostViewController
- (id)init:(NSString *)placeId dishId:(NSString *)dishId 
{
    self = [super init];
    if (self) {
        
        // masterview
        UIView *masterView = [[UIView alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
        masterView.backgroundColor = [UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1];
        self.view = masterView;
        
        templateProvider = nil;
        //self.navigationItem.title=@"Restaurant Info";
        
        // dishes
        {
            NVPagedDataView *pagedDataView = [[NVPagedDataView alloc] initWithFrame:CGRectMake(0, 145, 320, masterView.frame.size.height - 247)];
            templateProvider = [[DishPostTemplateProvider alloc] init:placeId dishId:dishId];
            
            pagedDataView.backgroundColor = [UIColor clearColor];
            
            pagedDataView.templateProvider = templateProvider;
            
            templateProvider.owner = pagedDataView;
            
            if ([pagedDataView.templateProvider isKindOfClass:[DefaultTemplateProvider class]]) {
                DefaultTemplateProvider *tp = ((DefaultTemplateProvider *)pagedDataView.templateProvider);
                ((MutableDefaultDataProvider *)tp.rowDataProvider.pagedDataProviderInst).pagedDataView = pagedDataView;
            }
            // trigger
            [templateProvider trigger];
            
            [masterView addSubview:pagedDataView];
        }
        
        // restaurant info
        {
            
            restaurantInfoHeaderView = [[RestaurantInfoHeaderView alloc] initWithFrame:CGRectMake(0, 0, 320, 158) forDishPosts:true];
            restaurantInfoHeaderView.controller = self;
            
            UIView *tile = [PageUtil restHeaderScalableTile:restaurantInfoHeaderView.frame.size.width height:restaurantInfoHeaderView.frame.size.height];
            
            [restaurantInfoHeaderView addSubview:tile];
            [restaurantInfoHeaderView sendSubviewToBack:tile];
            
            PlaceInfoRD *placeInfoRD = (PlaceInfoRD *)[NVSession getFromSession:SESSION_PLACE_INFO_RD];
            
            if (placeInfoRD != nil) {
                [restaurantInfoHeaderView populateData:placeInfoRD];
            } else {
                [templateProvider.dataProvider addObserver:restaurantInfoHeaderView forKeyPath:@"placeInfoRD" options:NSKeyValueObservingOptionInitial context:nil];
            }
            
            [masterView addSubview:restaurantInfoHeaderView];
        }
        
    }
    return self;
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    
    
    @try {
        [templateProvider.dataProvider removeObserver:restaurantInfoHeaderView forKeyPath:@"placeInfoRD"];
    }
    @catch (NSException *exception) {
        //
    }
    @finally {
        //
    }

    restaurantInfoHeaderView = nil;
    templateProvider = nil;
}

@end
