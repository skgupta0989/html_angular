//
//  RecommendTemplateProvider.h
//  DishGram
//
//  Created by Rags on 17/06/13.
//
//

#import <Foundation/Foundation.h>
#import "NVTemplateProvider.h"
#import "MutableRowDataProvider.h"
#import "RecommendDataView.h"
#import "UserFollowers.h"
#import "RecommendDataProvider.h"
#import "DefaultTemplateProvider.h"


@protocol DelegateFromTemplateProvider <NSObject>

-(void)profielPicActionFormTemplateProivider:(UserFollowers *)userData;
-(void)disabledoneButtonfromTemplateprovider;

@end


@interface RecommendTemplateProvider : DefaultTemplateProvider<TotalSelectedUsersDelegate,DisablingDoneButtonDelegate>{
    //MutableRowDataProvider *_rowDataProvider;
    
}
@property (nonatomic, strong) NSMutableArray *userIDsList;
@property (nonatomic, weak) id<DelegateFromTemplateProvider> delegate;
@property (nonatomic, strong) NSNumber *postedUserID;

-(void)reloadDataprovider:(NSNumber *)postedUserID;
-(id)initWithPostedUserID:(NSNumber *)postedUserID;

-(void)makeSelectAll;
-(void)makeUnselectAll;
@end
