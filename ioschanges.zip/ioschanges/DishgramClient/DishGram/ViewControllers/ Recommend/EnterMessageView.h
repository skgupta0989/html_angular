//
//  EnterMessageView.h
//  DishGram
//
//  Created by Rags on 21/06/13.
//
//

#import <UIKit/UIKit.h>


@protocol  ButtonClickeventDelegateFromEnterMessage <NSObject>

- (void)clickEvent:(id)sender andMessage:(NSString*)text;

@end
@interface EnterMessageView : UIView<UITextFieldDelegate>{
    UIView *msgView;
    
}

@property (strong, nonatomic) IBOutlet UITextField *enterMsgTextfield;
@property (strong, nonatomic) IBOutlet UIButton *skipBtn;
@property (strong, nonatomic) IBOutlet UIButton *sendBtn;
@property (weak, nonatomic) id<ButtonClickeventDelegateFromEnterMessage> delegate;
-(IBAction)skipAndSendBtnsClicked:(id)sender;

@end
