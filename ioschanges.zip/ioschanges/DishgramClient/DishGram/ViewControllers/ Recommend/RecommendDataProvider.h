//
//  RecommendDataProvider.h
//  DishGram
//
//  Created by Rags on 17/06/13.
//
//

#import <Foundation/Foundation.h>
#import "MutableDefaultDataProvider.h"
#import "PagedDataProvider.h"
#import "Header.h"
#import "FollowingUser.h"

@protocol DisablingDoneButtonDelegate <NSObject>

-(void)disableDoneButtonFromDataProvider;

@end


@interface RecommendDataProvider : MutableDefaultDataProvider

@property (nonatomic, weak) id<DisablingDoneButtonDelegate> delegate;
@property (nonatomic, strong) NSNumber *postedUserID;
-(id)initWithPostedUserID:(NSNumber*)userID;
@end
