//
//  EnterMessageView.m
//  DishGram
//
//  Created by Rags on 21/06/13.
//
//

#import "EnterMessageView.h"
#import <QuartzCore/QuartzCore.h>
#import "Utilities.h"

@implementation EnterMessageView
@synthesize delegate;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *arr = [[NSBundle mainBundle] loadNibNamed:@"EnterMessageView" owner:self options:nil];
        msgView = [arr objectAtIndex:0];
        [self addSubview:msgView];
        self.enterMsgTextfield.textColor=[UIColor blackColor];
        
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
//- (void)drawRect:(CGRect)rect
//{
//    // Drawing code
//}
-(IBAction)skipAndSendBtnsClicked:(id)sender{
    UIButton *button = (UIButton *)sender;
    
    if(button.tag == 1){
        
        [self.delegate clickEvent:sender andMessage:self.enterMsgTextfield.text];
        
    }else if(button.tag==2){
        if(self.enterMsgTextfield.text == NULL){
            [Utilities showAlertMessage:@"Please enter a message" andDelegate:nil];
            
        }else{
          [self.delegate clickEvent:sender andMessage:self.enterMsgTextfield.text];
        }
    }
  
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.delegate clickEvent:textField andMessage:self.enterMsgTextfield.text];
    [self.enterMsgTextfield resignFirstResponder];
    return NO;
    
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    // condition to not enter more than 255 characters
    int stringLength = [textField.text length]+[string length]-range.length;
    return  (stringLength<=50)?YES:NO;
    
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
   
     
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
     [Utilities movingView:msgView toFrame:CGRectMake(msgView.frame.origin.x, -40, msgView.frame.size.width, msgView.frame.size.height) duration:0.1 callback:nil selectore:nil];
    return YES;
}

@end
