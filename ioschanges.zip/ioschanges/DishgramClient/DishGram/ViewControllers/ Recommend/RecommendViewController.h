//
//  RecommendViewController.h
//  DishGram
//
//  Created by Rags on 17/06/13.
//
//

#import <UIKit/UIKit.h>
#import "DGToggel.h"
#import "AppDelegate.h"
#import "NVPagedDataView.h"
#import "EnterMessageView.h"
#import "DataSourceFactory.h"
#import "DataSourceInterface.h"
#import "EmailView.h"
#import "RecommendTemplateProvider.h"


@interface RecommendViewController : UIViewController<ButtonClickeventDelegateFromEnterMessage,EmailViewDelegate,UITextFieldDelegate,DelegateFromTemplateProvider>{
    AppDelegate *appDelegate;
    NVPagedDataView *pagedDataView;
    EnterMessageView *msgView ;
    EmailView *emailView;
    UIView *shadedView;
    UIView *shadedViewInFollowers;
    
}

@property (strong, nonatomic) IBOutlet UIView *recommendBtnsView;
@property (strong, nonatomic) IBOutlet UIButton *cancelButtton;
@property (strong, nonatomic) IBOutlet UIButton *selectAllBtn;
@property (strong, nonatomic) IBOutlet UIButton *doneBtn;
@property (assign, nonatomic) BOOL isselectAllclicked;
@property (strong, nonatomic) IBOutlet UIButton *cancelBtnClickInEmail;
@property (strong, nonatomic) IBOutlet UIButton *sendBtnClickInEmail;
@property (strong, nonatomic) NSMutableArray *validUserEmailIDs;
@property (strong, nonatomic) NSNumber *dishPlaceID;
@property (strong, nonatomic) NSMutableArray *unValidEmailIDs;
@property (strong, nonatomic) NSNumber *postedUserID;



-(IBAction)ButtonsClicked:(id)sender;
- (IBAction)cancelBtnInEmailClicked:(id)sender;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil wihPostedUserID:(NSNumber*)userID;


@end
