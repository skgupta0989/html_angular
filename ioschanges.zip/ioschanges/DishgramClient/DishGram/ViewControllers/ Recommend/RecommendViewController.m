//
//  RecommendViewController.m
//  DishGram
//
//  Created by Rags on 17/06/13.
//
//

#import "RecommendViewController.h"
#import "NVPagedDataView.h"
#import "RecommendTemplateProvider.h"
#import "EnterMessageView.h"
#import "Utilities.h"
#import "Header.h"
#import "EmailView.h"
#import "PageUtil.h"
#import "ProfileController.h"
#import <QuartzCore/QuartzCore.h>


@interface RecommendViewController ()

@end

@implementation RecommendViewController
@synthesize isselectAllclicked,validUserEmailIDs,dishPlaceID,unValidEmailIDs,postedUserID;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil wihPostedUserID:(NSNumber*)userID
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.postedUserID=userID;
               // Custom initialization
        appDelegate = [UIApplication sharedApplication].delegate;
        //self.title =@"Recommend";
        /*CGRect frame = CGRectMake(0, 0, 180, 44);
        UILabel *nav_label = [[UILabel alloc] initWithFrame:frame];
        nav_label.backgroundColor = [UIColor clearColor];
        [nav_label setFont:[UIFont fontWithName:@"Roboto-Bold" size:18]];
        nav_label.shadowColor = [UIColor whiteColor];
        nav_label.shadowOffset  = CGSizeMake(0.5,0.5);
        nav_label.textAlignment = UITextAlignmentCenter;
        nav_label.textColor = [UIColor blackColor];
        nav_label.text = @"Recommend";
        [nav_label sizeToFit];
        self.navigationItem.titleView = nav_label;*/
        
        self.navigationItem.titleView = [PageUtil navBarTitleWith:@"Recommend"];
        pagedDataView = [[NVPagedDataView alloc] initWithFrame:CGRectMake(0, 0, 320,appDelegate.winHeight-210) disableTabHiding:YES];
        pagedDataView.backgroundColor = [UIColor clearColor];
        NSLog(@"self.PostedUserID=========%@",self.postedUserID);
        pagedDataView.templateProvider = [[RecommendTemplateProvider alloc] initWithPostedUserID:self.postedUserID];
        pagedDataView.templateProvider.owner = pagedDataView;
        if ([pagedDataView.templateProvider isKindOfClass:[DefaultTemplateProvider class]]) {
            DefaultTemplateProvider *tp = ((DefaultTemplateProvider *)pagedDataView.templateProvider);
            ((MutableDefaultDataProvider *)tp.rowDataProvider.pagedDataProviderInst).pagedDataView = pagedDataView;
        }

        [pagedDataView.templateProvider trigger];
         ((RecommendTemplateProvider *)pagedDataView.templateProvider).delegate=self;
        isselectAllclicked=NO;
        unValidEmailIDs= [[NSMutableArray alloc] init];

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    

    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_pattern.png"]];
     
    DGToggel *toggle = [[DGToggel alloc] initWithItems: [NSArray arrayWithObjects:@"Followers",@"Send email", nil]];
    toggle.frame =CGRectMake(0, 0, 320, 33);
    [toggle addTarget:self action:@selector(toggleButtonsClikced:)];
    [toggle.leftButton.titleLabel setFont:[UIFont fontWithName:@"Roboto-Condensed" size:14]];
    [toggle.rightButton.titleLabel setFont:[UIFont fontWithName:@"Roboto-Condensed" size:14]];
    [toggle setSelectedIndex:1];
    [toggle setSelectedToggel:1];
    [self.view addSubview:toggle];
    
    shadedViewInFollowers = [[UIView alloc] initWithFrame:CGRectMake(0, 35, 320, appDelegate.winHeight-180)];
    shadedViewInFollowers.backgroundColor = [UIColor clearColor];
    [shadedViewInFollowers addSubview:[PageUtil scalablePageTile:320 height:appDelegate.winHeight-180 forName:@"bg"]];
    [self.view addSubview:shadedViewInFollowers];
    
    self.view.autoresizingMask=UIViewAutoresizingNone;
    self.view.autoresizesSubviews=NO;
   
    pagedDataView.autoresizesSubviews=NO;
    shadedViewInFollowers.autoresizingMask= UIViewAutoresizingNone;
    pagedDataView.autoresizingMask =UIViewAutoresizingNone;
    shadedViewInFollowers.autoresizesSubviews=NO;
    [shadedViewInFollowers addSubview:pagedDataView];
    
    self.recommendBtnsView.frame =CGRectMake(0, appDelegate.winHeight-145, 320, 40);
    self.cancelBtnClickInEmail.hidden=YES;
    self.sendBtnClickInEmail.hidden=YES;
    [self.view bringSubviewToFront:self.recommendBtnsView];

    
}
#pragma  mark
#pragma  mark Toggle Buttons Clicked actions

- (void)toggleButtonsClikced:(id)sender{
    NSArray *array = [self.view subviews];
    for(UIView *view in array){
        if(view.tag==100){
            
             [view removeFromSuperview];
        }
    }
    
    
    DGToggel *tag = (DGToggel*)sender;
    if(tag.selectedToggel==1){
        pagedDataView.hidden=NO;
        self.cancelButtton.hidden=NO; 
        self.selectAllBtn.hidden=NO;
        self.doneBtn.hidden=NO;
        self.cancelBtnClickInEmail.hidden=YES;
        self.sendBtnClickInEmail.hidden=YES;
               [emailView removeFromSuperview];
        [shadedView removeFromSuperview];
        shadedViewInFollowers.hidden=NO;

        
    }else if(tag.selectedToggel==2){
        pagedDataView.hidden=YES;
        self.cancelButtton.hidden=YES;
        self.selectAllBtn.hidden=YES;
        self.doneBtn.hidden=YES;
        self.cancelBtnClickInEmail.hidden=NO;
        self.sendBtnClickInEmail.hidden=NO;

        shadedViewInFollowers.hidden=YES;
    
        shadedView = [[UIView alloc] initWithFrame:CGRectMake(0, 32, 320, 110)];
        shadedView.tag=100;
        shadedView.backgroundColor = [UIColor clearColor];
        [shadedView addSubview:[PageUtil scalablePageTile:320 height:110 forName:@"bg"]];
        [self.view addSubview:shadedView];
        emailView = [[EmailView alloc] initWithFrame:CGRectMake(5, 10, 312, 62)];
        
        emailView.dottedView.frame =CGRectMake(20, 2, 280, 30);
        [emailView.dottedView sizeToFit];
        emailView.dottedView.text=@"Enter email address to send recommendation";
        emailView.dottedView.font= [UIFont fontWithName:@"Roboto-Condensed" size:15];
        emailView.dottedView.textColor = [UIColor colorWithRed:75.0/255.0 green:75.0/255.0 blue:75.0/255.0 alpha:1.0];
        emailView.emailTextField.frame=CGRectMake(16, 32, 280, 30);
        emailView.emailTextField.textColor =[UIColor blackColor];
        emailView.emailTextField.layer.borderColor=[UIColor colorWithRed:193.0/255.0 green:193.0/255.0 blue:193.0/255.0 alpha:1.0].CGColor;
        emailView.emailTextField.borderStyle = UITextBorderStyleNone;
        emailView.emailTextField.layer.borderWidth= 0.5f;
        
        emailView.emailTextField.layer.masksToBounds=YES;
        
        [self IndentSpaceIntextFieldseWhenBorderIsNone];
        emailView.delegate=self;
        [emailView setTextFieldDelegate];
        [shadedView addSubview:emailView];

                
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma  mark
#pragma  mark cancel, select all and done buttons clicked in followers
-(IBAction)ButtonsClicked:(id)sender{
    UIButton *button = (UIButton*)sender;
    if(button.tag==1){
        // cancel button clicked
        NSArray *arr = [self.navigationController viewControllers];
        [self.navigationController popToViewController:[arr objectAtIndex:1] animated:YES];
    }else if(button.tag==2){
        
             // select all button clicked
            if(self.isselectAllclicked){
                
                [((RecommendTemplateProvider*)pagedDataView.templateProvider) makeUnselectAll];
                self.isselectAllclicked=NO;
                [self.selectAllBtn setTitle:@"SelectAll" forState:UIControlStateNormal] ;
            }else{
                
               
                [((RecommendTemplateProvider*)pagedDataView.templateProvider) makeSelectAll];
                self.isselectAllclicked=YES;
                [self.selectAllBtn setTitle:@"DeselectAll" forState:UIControlStateNormal] ;
            }
            
            [pagedDataView reloadData];
        
        
       

    }else if(button.tag==3){
        
       
       // done button clicked
        if([((RecommendTemplateProvider*)pagedDataView.templateProvider).userIDsList count]==0){
            [self  showMessageBox:@"Please select atleast one user to recommend !"];
            
        }else{
            UIView *transparentBackGround = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, appDelegate.winHeight)];
            transparentBackGround.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5f];
            transparentBackGround.opaque=NO;
            
            [self.view addSubview:transparentBackGround];
            
            msgView = [[EnterMessageView alloc] initWithFrame:CGRectMake(10, (appDelegate.winHeight-100)/2, 300, 100)];
            msgView.center=self.view.center;
            msgView.delegate=self;
            [self.view addSubview:msgView];

        }
        
}
    
    }
#pragma  mark
#pragma  mark delegate method from the message view when skip or send is clicked
-(void)clickEvent:(id)sender andMessage:(NSString *)text{
    
    UIButton *button = (UIButton*)sender;
    UITextField *textField = (UITextField*)sender;
    if(button.tag==1){
         [self sendrequestToServerAfterSkipAndSendBtnClick:text];
    }else if (button.tag==2){
        if([text isEqualToString:@""]){
           
            [self showMessageBox:@"Please enter message "];
        }else{
            [self sendrequestToServerAfterSkipAndSendBtnClick:text];
        }
    }else if(textField){
        [self sendrequestToServerAfterSkipAndSendBtnClick:text];
    }
    
       
    
    
    
}
- (void)sendrequestToServerAfterSkipAndSendBtnClick:(NSString *)text{
    
    NSMutableArray *totalUsersList = [[NSMutableArray alloc] init];
    
    for( int  i =0 ; i< [((RecommendTemplateProvider*)pagedDataView.templateProvider).userIDsList count]; i++){
        NSMutableDictionary *singleUserList = [[NSMutableDictionary alloc] init];
        [singleUserList setValue: [((RecommendTemplateProvider*)pagedDataView.templateProvider).userIDsList objectAtIndex:i] forKey:@"userId"];
        [totalUsersList addObject:singleUserList];
        singleUserList=nil;
    }
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:totalUsersList forKey:@"userList"];
    [dict setValue:[Utilities getToken] forKey:@"token"];
    [dict setValue:dishPlaceID forKey:@"dishPlaceId"];
    [dict setValue:text forKey:@"message"];
    [[DataSourceFactory getDataSourceInstance] requestDataWithURLString:GET_RECOMMEND_DISH_TO_USER_URL params:dict modelClass:nil callBack:^(bool success, NSObject *response) {
        if(success){
             [self showMessageBox:@"Recommended Successfully"];
            NSArray *arr = [self.navigationController viewControllers];
            [self.navigationController popToViewController:[arr objectAtIndex:1] animated:YES];
        }
    }];

}
#pragma  mark
#pragma  mark cancel button clicked in email
- (IBAction)cancelBtnClickedInEmail:(id)sender {
    NSArray *arr = [self.navigationController viewControllers];
    [self.navigationController popToViewController:[arr objectAtIndex:1] animated:YES];
}
#pragma  mark
#pragma  mark send button clicked in email
- (IBAction)sendBtnClickedInEmail:(id)sender {
    validUserEmailIDs = [self validateMultipleEmailWithString:emailView.emailTextField.text];
   // no valid email ids and 
    if( [unValidEmailIDs count]!= 0 && [emailView.emailTextField.text length]>0 ){
       
        [self showMessageBox:@"Please enter valid email ids !"];
        [unValidEmailIDs removeAllObjects];
        unValidEmailIDs=nil;

    }else if([emailView.emailTextField.text isEqualToString:@""]){
        
        [self showMessageBox:@"Please enter atleast one email id !"];

    
    }else{
        NSMutableArray *totalemailIDsList = [[NSMutableArray alloc] init];
        
        for( int  i =0 ; i< [validUserEmailIDs count]; i++){
            NSMutableDictionary *emailIDsDict = [[NSMutableDictionary alloc] init];
            [emailIDsDict setValue:[validUserEmailIDs objectAtIndex:i] forKey:@"email"];
            [totalemailIDsList addObject:emailIDsDict];
            emailIDsDict=nil;
            
        }
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setValue:totalemailIDsList forKey:@"emailIds"];
        [dict setValue:[Utilities getToken] forKey:@"token"];
        [dict setValue:dishPlaceID forKey:@"dishPlaceId"];
        [[DataSourceFactory getDataSourceInstance] requestDataWithURLString:GET_RECOMMEND_DISH_EMAIL_URL params:dict modelClass:nil callBack:^(bool success, NSObject *response) {
            if(success){
                // TODO
                NSLog(@"Recommended Successfully");
                [self showMessageBox:@"Recommended Successfully"];
                NSArray *arr = [self.navigationController viewControllers];
                [self.navigationController popToViewController:[arr objectAtIndex:1] animated:YES];
            }
        }];

    }
       

}
- (void)viewDidUnload {
    
    [self setSelectAllBtn:nil];
    [self setDoneBtn:nil];
    [self setCancelBtnClickInEmail:nil];
    [self setSendBtnClickInEmail:nil];
    [self setRecommendBtnsView:nil];
    [super viewDidUnload];
}
#pragma  mark
#pragma  mark to get array of user email ids
- (NSMutableArray*)validateMultipleEmailWithString:(NSString*)emails
{
    NSMutableArray *validEmails = [[NSMutableArray alloc] init];
    NSArray *emailArray = [emails componentsSeparatedByString:@","];
    for (NSString *email in emailArray)
    {
        NSString *trimmedEmail = [Utilities trimmedSting:email];
        NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";

        NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
        if ([emailTest evaluateWithObject:trimmedEmail]){
            [validEmails addObject:trimmedEmail];
        }else {
            [unValidEmailIDs addObject:trimmedEmail];
           
        }
    }
    
    return validEmails;
}
#pragma  mark
#pragma  mark email text field delegate methods 
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
   validUserEmailIDs = [self validateMultipleEmailWithString:textField.text];
   return YES;
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
    
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    // validUserEmailIDs = [self validateMultipleEmailWithString:textField.text];
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
}
#pragma mark
#pragma mark profileButtonClick

-(void)profielPicActionFormTemplateProivider:(UserFollowers *)userData{
    ProfileController *profileController = [[ProfileController alloc] initWithNibName:@"ProfileController" bundle:nil uid:userData.user.uid];
    // [self.navigationController pushViewController:profileController animated:YES];
    [PageUtil push:profileController];
}
#pragma mark
#pragma mark delegate method from data provider to hide the selectall and done button in recommend view controller

-(void)disabledoneButtonfromTemplateprovider{
    self.doneBtn.enabled=NO;
    self.selectAllBtn.enabled=NO;
        // [PageUtil addNoDataFoundImage:self.view];
}

-(void)IndentSpaceIntextFieldseWhenBorderIsNone{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 30)];
    emailView.emailTextField.leftView = paddingView;
    emailView.emailTextField.leftViewMode = UITextFieldViewModeAlways;
}
-(void)showMessageBox:(NSString*)message{
    
      [[[iToast makeText:NSLocalizedString( message, @"")]
      setGravity:iToastGravityCenter] show];
    
}

@end
