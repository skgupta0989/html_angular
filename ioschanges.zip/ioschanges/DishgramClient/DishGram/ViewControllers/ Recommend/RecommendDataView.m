//
//  RecommendDataView.m
//  DishGram
//
//  Created by Rags on 19/06/13.
//
//

#import "RecommendDataView.h"
#import "FontUtil.h"
#import "UserFollowers.h"
#import "User.h"
#import "PageUtil.h"

@implementation RecommendDataView

@synthesize listOfFriends;
@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"RecommendDataView" owner:self options:nil];
        UIView *view = [array objectAtIndex:0];
        [self addSubview:view];
       [FontUtil decorateView:view];
        self.profileImg =[PageUtil profileImageView:CGRectMake(10, 10, 45, 45)];
        [self addSubview:self.profileImg];
        listOfFriends= [[NSMutableArray alloc] init];
        self.profileImg.userInteractionEnabled=YES;
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cellprofileViewClicked)];
        [self.profileImg addGestureRecognizer:tapGesture];
        

    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)populateData:(UserFollowers *)data rowDataProvider:(MutableRowDataProvider *)rowDataProvider   {
    _rowDataProvider =rowDataProvider;
    localUserFollowers = data;
    
    self.userName.text = data.user.username;
    if([data.user.dishPlacesesCount  intValue]<=1){
      self.totalPosts.text =[NSString stringWithFormat:@"%@ Post",data.user.dishPlacesesCount];  
    }else{
        self.totalPosts.text =[NSString stringWithFormat:@"%@ Posts",data.user.dishPlacesesCount];
    }
    
    CGSize constraint = CGSizeMake(296,9999);
    CGSize size = [self.totalPosts.text sizeWithFont:[UIFont systemFontOfSize:12]
                                   constrainedToSize:constraint
                                       lineBreakMode:UILineBreakModeWordWrap];
    self.totalPosts.numberOfLines=0;
    
    [self.totalPosts setFrame:CGRectMake(self.totalPosts.frame.origin.x, self.totalPosts.frame.origin.y, size.width, size.height)];
    
    self.line.frame=CGRectMake(self.totalPosts.frame.origin.x+size.width+3, self.line.frame.origin.y, 3, size.height);
    self.line.textColor =[UIColor colorWithRed:80.0/255.0 green:80.0/255.0 blue:80.0/255.0 alpha:1.0];
    self.followers.frame=CGRectMake(self.line.frame.origin.x+7, self.followers.frame.origin.y, size.width+30, size.height);
    if([data.user.userFollowersCount intValue]<= 1){
         self.followers.text =[NSString stringWithFormat:@"%@ Follower",data.user.userFollowersCount];
    }else{
         self.followers.text =[NSString stringWithFormat:@"%@ Followers",data.user.userFollowersCount];
    }
   
   
    
    NSString *profileUrl = data.user.userProfileImage;
    if(profileUrl){
        [PageUtil fetchPofileImage:self.profileImg url:profileUrl notify:nil];
    }

    if(localUserFollowers.isSelected == YES){
        
        [self.checkBtn setImage:[UIImage imageNamed:@"selectedCheck.png"] forState:UIControlStateNormal];
       
    }else{
        [self.checkBtn setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        
        
    }
    
    
    
}

-(void)chechUncheck{
    if(localUserFollowers.isSelected == YES){
        
        [self.checkBtn setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        localUserFollowers.isSelected = NO;
           
    }else{
        
        [self.checkBtn setImage:[UIImage imageNamed:@"selectedCheck.png"] forState:UIControlStateNormal];
        localUserFollowers.isSelected = YES;
      
    }
    [self.delegate userSelectedToSendTheDishDetails:localUserFollowers];
}

- (IBAction)checkBtnClicked:(id)sender {
    
    [self chechUncheck];
    
}

-(void)cellprofileViewClicked{
   
    [self.delegate userDataForProfilePicSelection:localUserFollowers];
}

@end
