//
//  RecommendTemplateProvider.m
//  DishGram
//
//  Created by Rags on 17/06/13.
//
//

#import "RecommendTemplateProvider.h"
#import "PageUtil.h"
#import "RecommendDataProvider.h"
#import "RecommendDataView.h"
#import "UserFollowers.h"

int __tileWidth1=300;
int __tileHeight1=65;
int cellHeight = 65;

@implementation RecommendTemplateProvider
//@synthesize numRows;
//@synthesize owner;
@synthesize userIDsList;
@synthesize delegate;


-(id)initWithPostedUserID:(NSNumber *)postedUserID{
    self = [super init];
    if(self){
        self.postedUserID = postedUserID;
        self.numRows=0;
        [self reloadDataprovider:(NSNumber *)postedUserID];
        userIDsList = [[NSMutableArray alloc] init];
    }
    return self;
}
-(void)reloadDataprovider:(NSNumber *)postedUserID {
    
    RecommendDataProvider *dataProvider = [[RecommendDataProvider alloc] initWithPostedUserID:self.postedUserID];
    dataProvider.delegate = self;
    _rowDataProvider = [[MutableRowDataProvider alloc] initWithPageSize:10000 numberOfPagesToCache:100 pagedDataProvider:dataProvider nextPageTrigger:0];
    
    
    __weak typeof(self) weakSelf = self;
    _rowDataProvider.sizeChangedCallBack = ^(int newSize) {
        
        
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf.owner != nil) {
            
            strongSelf.numRows = newSize;
            [strongSelf performSelectorOnMainThread:@selector(update:)
                                       withObject:^{
                                           [strongSelf.owner reloadData];
                                       } waitUntilDone:false];
        }
    };
}

-(UIView *)getTemplate:(int)index{
     
    UIView *backGroundView = [[UIView alloc] initWithFrame:CGRectMake(5,0 ,310 ,__tileHeight1 )];
//    UIImageView *image = [PageUtil profileImageView:CGRectMake(10, 10, 45, 45)];
//    [backGroundView addSubview:image];
    [backGroundView addSubview:[PageUtil createSeparatorLineInTable:CGRectMake(10, cellHeight-1, 290, 1)]];

    void (^callBack)(NSObject *data) = [self getCallBackMethod:backGroundView];
    
    
    
    NSObject *data = nil;// [_rowDataProvider getLocalRow:index];
    
    if (data) {
        callBack(data);
        
    } else {
        
        [_rowDataProvider getRow:index withCallBack:callBack];
    }

    return backGroundView;
    
}
-(float)getCellHeight{
    return cellHeight;
    
}
-(void)update:(void (^)(void))updateDo {
    updateDo();
}


-(void (^)(NSObject *data)) getCallBackMethod:(UIView *)masterView {
    
    
    void (^callBack)(NSObject *data) = ^(NSObject *data){
        if (data) {
            
            [self performSelectorOnMainThread:@selector(update:)
                                   withObject:^{
                                        [PageUtil removeNoDataFoundImage:self.owner];
                                       RecommendDataView *tileController = [[RecommendDataView alloc] initWithFrame:CGRectMake(0, 0, 310, 64)];
                                       tileController.delegate=self;
                                       [masterView addSubview:tileController];
                               
                                       [tileController populateData:(UserFollowers *)data rowDataProvider:_rowDataProvider];
                                                                             
                                     
                                   } waitUntilDone:true];
            
            
        }
    };
    
    return callBack;
}

-(void)makeSelectAll{
    
    int end = [_rowDataProvider getEndSize];
    
    for (int i =0; i<end; i++) {
        
      UserFollowers *data = (UserFollowers *)[_rowDataProvider getLocalRow:i];
        
        data.isSelected = YES;
        [userIDsList addObject:data.user.uid];
      
        
    }
    
}

-(void)makeUnselectAll{
    int end = [_rowDataProvider getEndSize];
    
    for (int i =0; i<end; i++) {
        
        UserFollowers *data = (UserFollowers *)[_rowDataProvider getLocalRow:i];
        
        data.isSelected = NO;
        [userIDsList removeObject:data.user.uid];
       

    }
 
}
-(void)userSelectedToSendTheDishDetails:(UserFollowers *)userDetails{
    if([userIDsList containsObject:userDetails.user.uid]){
        [userIDsList removeObject:userDetails.user.uid];
    }else {
        [userIDsList addObject:userDetails.user.uid];
    }
    
    
}

-(void)userDataForProfilePicSelection:(UserFollowers *)userDetails{
    [self.delegate profielPicActionFormTemplateProivider:userDetails];
}


-(void)disableDoneButtonFromDataProvider{
    [self.delegate disabledoneButtonfromTemplateprovider];
    
}
@end
