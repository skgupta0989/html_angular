//
//  RecommendDataView.h
//  DishGram
//
//  Created by Rags on 19/06/13.
//
//

#import <UIKit/UIKit.h>
#import "NVLabel.h"
#import "UserFollowers.h"
#import "MutableRowDataProvider.h"


@protocol TotalSelectedUsersDelegate <NSObject>

-(void)userSelectedToSendTheDishDetails:(UserFollowers *)userDetails;
-(void)userDataForProfilePicSelection:(UserFollowers *)userDetails;

@end
@interface RecommendDataView : UIView{
    
    UserFollowers *localUserFollowers;
    MutableRowDataProvider *_rowDataProvider;
}
@property (strong, nonatomic) IBOutlet UIImageView *profileImg;
@property (strong, nonatomic) IBOutlet NVLabel *userName;
@property (strong, nonatomic) IBOutlet NVLabel *totalPosts;
@property (strong, nonatomic) IBOutlet NVLabel *line;
@property (strong, nonatomic) IBOutlet NVLabel *followers;
@property (weak, nonatomic) IBOutlet UIButton *checkBtn;
@property (strong, nonatomic) NSMutableArray *listOfFriends;
@property (nonatomic, weak) id<TotalSelectedUsersDelegate> delegate;



-(void)populateData:(UserFollowers *)data rowDataProvider:(MutableRowDataProvider *)rowDataProvider ;
- (IBAction)checkBtnClicked:(id)sender;


@end


