//
//  RecommendDataProvider.m
//  DishGram
//
//  Created by Rags on 17/06/13.
//
//

#import "RecommendDataProvider.h"
#import "PageUtil.h"
#import "Utilities.h"
#import "UserFollowers.h"
#import "DataSingleton.h"
@implementation RecommendDataProvider
@synthesize delegate,postedUserID;

-(id)initWithPostedUserID:(NSNumber*)userID{
    self.postedUserID=userID;
    self = [super init:GET_USER_FOLLOWERS_URL respType:[UserFollowers class]];
    if(self){
        
    }
    return self;
}

// overrid the super class method if custom parameters need to be added to the webservice request.
-(NSMutableDictionary *)getRequest {
    NSMutableDictionary *request = [super getRequest];
    NSLog(@"self.postedUserID=%@",self.postedUserID);
    [request setObject:[Utilities getFromUserDefault:USERID] forKey:@"uid"];
    [request setObject:self.postedUserID forKey:@"dishPostedBy"];
       
    
    // START Add custom reqeust parameters here
    // END Add custom reqeust parameters here
    
    return request;
}

//// TODO
-(void)onError:(NSString *)message {
    if ([message isEqualToString:[DataSingleton stringValueForKey:@"error_network_connection"]]) {
        [self noResultsFoundWithImage:@"notfound_no_internet"];
    }else {
        [[[iToast makeText:message] setGravity:iToastGravityTop] show];
        
    }
    
}
-(void)noResultsFound{
    [self noResultsFoundWithImage:@"notfound_followers.png"];
    [self.delegate disableDoneButtonFromDataProvider];
    
}


@end
