//
//  ActivityFeedController.h
//  DishGram
//
//  Created by Ramesh Varma on 27/05/13.
//
//

#import <UIKit/UIKit.h>
#import "DishInfo.h"
#import "NVLabel.h"
#import "RemovePostPromptView.h"

@class AppDelegate;

// View, which displayes a post in ActivityFeed screen
@interface ActivityFeedController : UIView<RemovePostPromptDelegate> {
    
    // application delegate singleton
    AppDelegate *appDelegate;
    
    // recycle box image when clicked should deletes the post. This view is shown only for
    // self posted dishes
    UIImageView *removePostView_;
    
    // dish image
    UIImageView *dishView;
    
    // profile image
    UIImageView *profileView;
}

// Dish name
@property (weak, nonatomic) IBOutlet NVLabel *dishLabel;

// header sub text where when the dish is posted is displayed
@property (weak, nonatomic) IBOutlet NVLabel *dishLabelSubtext;

// place (restaurant) name
@property (weak, nonatomic) IBOutlet NVLabel *place;

// address
@property (weak, nonatomic) IBOutlet NVLabel *location;

// post description
@property (weak, nonatomic) IBOutlet NVLabel *description;

// rating of this post
@property (weak, nonatomic) IBOutlet UIImageView *starImageView;

// distance in km/miles from current known device location
@property (weak, nonatomic) IBOutlet NVLabel *distance;


// total number of thimes this post is viewed by users
@property (weak, nonatomic) IBOutlet NVLabel *numberOfViews;
@property (weak, nonatomic) IBOutlet UIImageView *viewsIcon;

// total mnumber of loves for this post
@property (weak, nonatomic) IBOutlet NVLabel *loves;
@property (weak, nonatomic) IBOutlet UIImageView *lovesIcon;

// total number of comments on this post
@property (weak, nonatomic) IBOutlet NVLabel *comments;
@property (weak, nonatomic) IBOutlet UIImageView *commentsIcon;


// love/unlove button
@property (weak, nonatomic) IBOutlet UIButton *loveButton;

// called when user click comment button
- (IBAction)commentButton:(id)sender;

// called when user click love/unlove button
- (IBAction)loveClicked:(id)sender;

// data fo this view (received from server)
@property (nonatomic, strong) DishInfo *data;

// This method must be called by TemplateProvider when row data is available
-(void)populateData:(DishInfo *)data;


@end