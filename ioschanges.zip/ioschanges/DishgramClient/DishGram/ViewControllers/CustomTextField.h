//
//  CustomTextField.h
//  DishGram
//
//  Created by Satish on 5/3/13.
//
//

#import <UIKit/UIKit.h>

@interface CustomTextField : UITextField


@end
