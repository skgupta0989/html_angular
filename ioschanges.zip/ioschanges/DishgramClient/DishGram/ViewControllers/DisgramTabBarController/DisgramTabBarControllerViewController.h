//
//  DisgramTabBarControllerViewController.h
//  DishGram
//
//  Created by SumanAmit on 23/05/13.
//
//

#import <UIKit/UIKit.h>
@protocol ButtonSelectionDelegate <NSObject>
@required
-(void)buttonSelectedAction:(id)sender;
@end


@interface DisgramTabBarControllerViewController : UITabBarController{
    UIView *inactiveView;
    CGRect centerButtonFrame;

}
@property(nonatomic,strong)UIButton *btnNew,*btnNew1, *btnNew2,* button;;
@property (nonatomic,assign) BOOL isCenterButtonSelected;

-(UIViewController*) viewControllerWithTabTitle:(NSString*)title image:(UIImage*)image;


-(void) addCenterButtonWithImage:(UIImage*)buttonImage highlightImage:(UIImage*)highlightImage;

- (void)hideDisgramButton;

@property(nonatomic,weak)id <ButtonSelectionDelegate>buttonSelectionDelegate;

@end
