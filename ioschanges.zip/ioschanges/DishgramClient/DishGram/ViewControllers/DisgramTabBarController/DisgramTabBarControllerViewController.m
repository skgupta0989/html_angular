//
//  DisgramTabBarControllerViewController.m
//  DishGram
//
//  Created by SumanAmit on 23/05/13.
//
//

#import "DisgramTabBarControllerViewController.h"
#import "Utilities.h"
#import "AppDelegate.h"
#import "PageUtil.h"


@interface DisgramTabBarControllerViewController ()

@end

@implementation DisgramTabBarControllerViewController


@synthesize buttonSelectionDelegate;
@synthesize btnNew,btnNew1,btnNew2,button;


-(UIViewController*) viewControllerWithTabTitle:(NSString*) title image:(UIImage*)image
{
    return nil;
}

-(void) addCenterButtonWithImage:(UIImage*)buttonImage highlightImage:(UIImage*)highlightImage
{
//    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    CGRect backFrame=CGRectMake(-1, -2, 320+5, appDelegate.winHeight+40);
//    inactiveView=[[UIView alloc] initWithFrame:backFrame];
//    inactiveView.tag=k_BACKVIEW_TAG;
//    inactiveView.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:.7];
    _isCenterButtonSelected=NO;
    
    self.button = [UIButton buttonWithType:UIButtonTypeCustom];
    self.button.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin;
    self.button.frame = CGRectMake(0.0, 0.0, buttonImage.size.width, buttonImage.size.height);
    [self.button setBackgroundImage:BUTTON_UN_SELECTED_IMAGE forState:UIControlStateNormal];
    [self.button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    self.button.tag=1;
    CGFloat heightDifference = buttonImage.size.height - self.tabBar.frame.size.height;
    if (heightDifference < 0)
        self.button.center = self.tabBar.center;
    else
    {
        CGPoint center = self.tabBar.center;
        center.y = center.y - heightDifference/2.0;
        self.button.center = center;
    }

    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    CGRect backFrame=CGRectMake(-1, button.frame.origin.y-500, 320+5, appDelegate.winHeight+80);
    inactiveView=[[UIView alloc] initWithFrame:backFrame];
    inactiveView.tag=k_BACKVIEW_TAG;
    inactiveView.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:.7];

    centerButtonFrame=self.button.frame;
    CGRect mainButtonFrame;//=self.button.frame;
    self.btnNew=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnNew setTitle:@"Open Gallery" forState:UIControlStateNormal];
    [self.btnNew setTitleColor:[UIColor colorWithRed:248.0/255.0 green:199.0/255.0 blue:197.0/255.0 alpha:1] forState:UIControlStateNormal];
    self.btnNew.titleLabel.font=[UIFont fontWithName:@"Roboto-Bold" size:11];
    self.btnNew.titleLabel.textAlignment=UITextAlignmentLeft;
    [self.btnNew setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"gallery" ofType:@"png"]] forState:UIControlStateNormal];
   mainButtonFrame= CGRectMake(button.frame.origin.x-80, button.frame.origin.y-50,70, 60);
    self.btnNew.frame=mainButtonFrame;
    self.btnNew.tag=10001;
    self.btnNew.imageEdgeInsets = UIEdgeInsetsMake(-30, 12, 0, 10);
    self.btnNew.titleEdgeInsets = UIEdgeInsetsMake(30,-50, -10, -10);
    [self.btnNew addTarget:self action:@selector(buttonSelected:) forControlEvents:UIControlEventTouchUpInside];
    self.btnNew.hidden=YES;
    [self.view addSubview:self.btnNew];
    
    self.btnNew1=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnNew1 setTitle:@"Take Picture" forState:UIControlStateNormal];
    self.btnNew1.titleLabel.font=[UIFont fontWithName:@"Roboto-Bold" size:11];
    self.btnNew1.titleLabel.textAlignment=UITextAlignmentLeft;
    [self.btnNew1 setTitleColor:[UIColor colorWithRed:248.0/255.0 green:199.0/255.0 blue:197.0/255.0 alpha:1] forState:UIControlStateNormal];
    ;
    [self.btnNew1 setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"photo" ofType:@"png"]] forState:UIControlStateNormal];
   mainButtonFrame= CGRectMake(button.frame.origin.x, button.frame.origin.y-90,70, 60);
    self.btnNew1.frame=mainButtonFrame;
    self.btnNew1.tag=10002;
    self.btnNew1.imageEdgeInsets = UIEdgeInsetsMake(-30, 12, 0, 10);
    self.btnNew1.titleEdgeInsets = UIEdgeInsetsMake(30,-50, -10, -10);
    [self.btnNew1 addTarget:self action:@selector(buttonSelected:) forControlEvents:UIControlEventTouchUpInside];
   self.btnNew1.hidden=YES;
    [self.view addSubview:self.btnNew1];

    
    self.btnNew2=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnNew2 setTitle:@"Draft" forState:UIControlStateNormal];
    self.btnNew2.titleLabel.font=[UIFont fontWithName:@"Roboto-Bold" size:11];
    self.btnNew2.titleLabel.textAlignment=UITextAlignmentLeft;
    [self.btnNew2 setTitleColor:[UIColor colorWithRed:248.0/255.0 green:199.0/255.0 blue:197.0/255.0 alpha:1] forState:UIControlStateNormal];
    [self.btnNew2 setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"draft" ofType:@"png"]] forState:UIControlStateNormal];
    mainButtonFrame=CGRectMake(button.frame.origin.x+80, button.frame.origin.y-50,70, 60);
    self.btnNew2.frame=mainButtonFrame;
    self.btnNew2.tag=10003;
    self.btnNew2.imageEdgeInsets = UIEdgeInsetsMake(-30, 12, 0, 10);
    self.btnNew2.titleEdgeInsets = UIEdgeInsetsMake(40,-40, 0, 0);
    [self.btnNew2 addTarget:self action:@selector(buttonSelected:) forControlEvents:UIControlEventTouchUpInside];
    self.btnNew2.hidden=YES;
    [self.view addSubview:self.btnNew2];
    
    [self.view addSubview:button];
}
-(void)getFirstRetauList{
    [PageUtil bufferRestaurantNearToLocation];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return NO;
}
-(void)buttonSelected:(id)sender{
    [self.buttonSelectionDelegate performSelector:@selector(buttonSelectedAction:) withObject:sender];
}
-(void)showButton{
    self.btnNew1.hidden=NO;
    [Utilities bounceAndMoveAnimationForButtons:CGRectMake(centerButtonFrame.origin.x, centerButtonFrame.origin.y-40, centerButtonFrame.size.width, centerButtonFrame.size.height) endPosition:CGRectMake(centerButtonFrame.origin.x, centerButtonFrame.origin.y-90,70, 60) withButton:self.btnNew1];
 
}

-(void)hideButton{
    
    [Utilities moveAnimationForButtons:CGRectMake(centerButtonFrame.origin.x, centerButtonFrame.origin.y-90,70, 60) endPosition:CGRectMake(centerButtonFrame.origin.x, centerButtonFrame.origin.y-45, centerButtonFrame.size.width, centerButtonFrame.size.height)  withButton:self.btnNew1];
    
}

-(void)showButton1{
        self.btnNew.hidden=NO;
    [Utilities bounceAndMoveAnimationForButtons:CGRectMake(centerButtonFrame.origin.x-20, centerButtonFrame.origin.y-40, centerButtonFrame.size.width, centerButtonFrame.size.height) endPosition:CGRectMake(centerButtonFrame.origin.x-80, centerButtonFrame.origin.y-50,70, 60) withButton:self.btnNew];

}

-(void)hideButton1{
    
    [Utilities moveAnimationForButtons:CGRectMake(centerButtonFrame.origin.x-80, centerButtonFrame.origin.y-50,70, 60)   endPosition:CGRectMake(centerButtonFrame.origin.x-20, centerButtonFrame.origin.y-45, centerButtonFrame.size.width, centerButtonFrame.size.height) withButton:self.btnNew];
}

-(void)showButton2{
        self.btnNew2.hidden=NO;
    [Utilities bounceAndMoveAnimationForButtons:CGRectMake(centerButtonFrame.origin.x+20, centerButtonFrame.origin.y-40, centerButtonFrame.size.width, centerButtonFrame.size.height) endPosition:CGRectMake(centerButtonFrame.origin.x+80, centerButtonFrame.origin.y-50,70, 60)withButton:self.btnNew2];
}

-(void)hideButton2{
    [Utilities moveAnimationForButtons:CGRectMake(centerButtonFrame.origin.x+80, centerButtonFrame.origin.y-50,70, 60) endPosition:CGRectMake(centerButtonFrame.origin.x+20, centerButtonFrame.origin.y-45, centerButtonFrame.size.width, centerButtonFrame.size.height) withButton:self.btnNew2];
}


-(void)showButtons{
    
    [NSTimer scheduledTimerWithTimeInterval:0.0 target:self selector:@selector(showButton1) userInfo:nil repeats:NO];
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(showButton) userInfo:nil repeats:NO];
    [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(showButton2) userInfo:nil repeats:NO];
    

    inactiveView.userInteractionEnabled=YES;
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    CGRect backFrame=CGRectMake(-1, self.view.frame.origin.x, 320+5, appDelegate.winHeight+80);
    [inactiveView setFrame:backFrame];
    [self.view addSubview:inactiveView];
    
    [self.view bringSubviewToFront:btnNew];
    [self.view bringSubviewToFront:btnNew1];
    [self.view bringSubviewToFront:btnNew2];
    [self.view bringSubviewToFront:self.button];
        [self.button setBackgroundImage:BUTTON_SELECTED_IMAGE forState:UIControlStateNormal];
    
}
-(void)hideButtons{
    [self.button setBackgroundImage:BUTTON_UN_SELECTED_IMAGE forState:UIControlStateNormal];
    [inactiveView removeFromSuperview];
    [NSTimer scheduledTimerWithTimeInterval:0.0 target:self selector:@selector(hideButton1) userInfo:nil repeats:NO];
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(hideButton) userInfo:nil repeats:NO];
    [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(hideButton2) userInfo:nil repeats:NO];

}
-(void)buttonAction:(id)sender{
     [self getFirstRetauList];
    if (![PageUtil isLoggedin]) {
        [PageUtil requiresLogin];
        return;
    }
    
    if (self.selectedIndex==2) {
        [[[iToast makeText:NSLocalizedString( @"Please Save/Discard Draft", @"")]
          setGravity:iToastGravityCenter] show];
        return;
    }

    UIButton *btn=(UIButton *)sender;
    if (btn.tag==1) {
        _isCenterButtonSelected=YES;
            btn.tag=2;
        [self showButtons];
    }else{
        _isCenterButtonSelected=NO;
        btn.tag=1;
        [self hideButtons];
    }
    
}
-(void)hideDisgramButton{

    self.button.tag=1;
    [self hideButtons];
}
-(void)dealloc{
    inactiveView=nil;
    self.button=nil;
    self.btnNew=nil;
    self.btnNew1=nil;
    self.btnNew2=nil;
    DLog();
}
@end
