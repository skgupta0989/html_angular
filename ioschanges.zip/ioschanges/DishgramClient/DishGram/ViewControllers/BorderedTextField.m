//
//  BorderedTextField.m
//  DishGram
//
//  Created by SumanAmit on 05/07/13.
//
//

#import "BorderedTextField.h"
#import "QuartzCore/QuartzCore.h"
@implementation BorderedTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (CGRect)textRectForBounds:(CGRect)bounds {
    
    CGRect inset = CGRectMake(bounds.origin.x + 7, bounds.origin.y, bounds.size.width - 10, bounds.size.height);
    [[self layer] setBorderWidth:.9];
    [[self layer] setBorderColor:[UIColor lightGrayColor].CGColor];
    

    return inset;
}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    CGRect inset = CGRectMake(bounds.origin.x + 7, bounds.origin.y, bounds.size.width - 10, bounds.size.height);
    return inset;
}

- (void)drawPlaceholderInRect:(CGRect)rect {
    rect=CGRectMake(rect.origin.x+3, rect.origin.y, rect.size.width, rect.size.height);
    [[UIColor lightGrayColor] setFill];
    [[self placeholder] drawInRect:rect withFont:[UIFont fontWithName:@"Roboto-Italic" size:12]];
}

@end
