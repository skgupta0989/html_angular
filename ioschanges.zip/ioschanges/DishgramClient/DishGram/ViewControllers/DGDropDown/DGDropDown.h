//
//  DGDropDown.h
//  DishGram
//
//  Created by SumanAmit on 05/06/13.
//
//

#import <UIKit/UIKit.h>
#import "DataSourceInterface.h"
@interface DGDropDown : UIView<UITableViewDataSource,UITableViewDelegate>{
    NSArray *contentArray;
    NSString *baseUrl,*typeOfSearch;
    Class contentModuleClass;
    DataSourceInterface *dataSourceObj;;
    void (^callback)(NSObject *object);
    NSString *selectorOnObject;
}
@property (strong, nonatomic)  UITableView *DropDownTableView;

- (id) initWithFrame:(CGRect)frame callback:(void (^)(NSObject *place))controllerCallback;

- (void) loadContentFor:(NSString *)url moduleClass:(Class)moduleClass searchString:(NSString *)str typeOfSearch:(NSString *)searchType;
- (void) reloadContentFor:(NSString *)str;

- (void)completeSearchOperation;


- (void) loadContent:(NSString *)url moduleClass:(Class)moduleClass searchString:(NSString *)str typeOfSearch:(NSString *)searchType param:(NSString *)selector;
@end
