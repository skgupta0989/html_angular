//
//  DGDropDown.m
//  DishGram
//
//  Created by SumanAmit on 05/06/13.
//
//

#import "DGDropDown.h"
#import "DataSourceFactory.h"
#import "Dish.h"
#import "Cuisine.h"
#import "City.h"
#import "QuartzCore/QuartzCore.h"
@implementation DGDropDown

-(void)setHeight{
    CGFloat height=[contentArray count]*40;
    CGRect rectOfTable,rectOfView;
    
    if (height<=200){
        rectOfTable=CGRectMake(5, 0, self.frame.size.width-5, 100);
        rectOfView=CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, 100);
    }else{
        rectOfTable=CGRectMake(5, 0, self.frame.size.width-5, 100);
        rectOfView=CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, 100);
    }
    [self.DropDownTableView setFrame:rectOfTable];
    [self setFrame:rectOfView];

}
- (id)initWithFrame:(CGRect)frame callback:(void (^)(NSObject *place))controllerCallback
{
    if (frame.size.height>200) {
        frame=CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, 50);
    }
    self = [super initWithFrame:frame];
    if (self) {
        _DropDownTableView=[[UITableView alloc] initWithFrame:CGRectMake(5, 0, frame.size.width-5, 100)];
        _DropDownTableView.delegate=self;
        _DropDownTableView.dataSource=self;
        _DropDownTableView.layer.borderWidth=1.0;
        _DropDownTableView.layer.borderColor=[UIColor lightGrayColor].CGColor;
        [self addSubview:_DropDownTableView];
        callback=controllerCallback;
    }//self.backgroundColor=[UIColor redColor];

    return self;
}
#pragma mark -
- (void) loadContentFor:(NSString *)url moduleClass:(Class)moduleClass searchString:(NSString *)str typeOfSearch:(NSString *)searchType{
    dataSourceObj = [DataSourceFactory getDataSourceInstance];
    
    contentModuleClass=moduleClass;
    baseUrl=url;
    typeOfSearch=searchType;
        
}
- (void) loadContent:(NSString *)url moduleClass:(Class)moduleClass searchString:(NSString *)str typeOfSearch:(NSString *)searchType param:(NSString *)selector{
    
    selectorOnObject=selector;
    
    dataSourceObj = [DataSourceFactory getDataSourceInstance];
    
    contentModuleClass=moduleClass;
    baseUrl=url;
    typeOfSearch=searchType;

}
-(NSString *)checkType:(NSString *)str{
    if (str==nil) {
        return @"";
    }else if([str isEqualToString:@"FOOD"]||[str isEqualToString:@"BEVERAGE"]){
        return @"DISH";
    }
        return str;
}
- (void) reloadContentFor:(NSString *)str{
    
    NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
    [param setObject:@"14aca7cdfe48523df8cfbf27c457975b" forKey:@"token"];
    [param setObject:str forKey:@"text"];
    [param setObject:[NSNumber numberWithInt:20] forKey:@"max"];
    [param setObject:[NSNumber numberWithInt:0] forKey:@"offset"];
    [param setObject:[self checkType:typeOfSearch] forKey:@"type"];
    [param setObject:typeOfSearch forKey:@"dishType"];
    [dataSourceObj requestDataWithURLString:baseUrl params:param  modelClass:contentModuleClass callBack:^(bool success, NSObject *response) {
        if (success) {
            contentArray=(NSArray *)response;
//            NSLog(@"%@",contentArray);
            if (contentArray.count>0) {
                self.hidden=NO;
                [_DropDownTableView reloadData];
                [self setHeight];
            }else {
                self.hidden=YES;
            }


        }else{
            
        }
        
    }];
    
}

#pragma mark -UITableViewDelegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPat{
    static NSString *tableViewCell=@"DGDropDown";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:tableViewCell];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableViewCell];
        cell.backgroundColor=[UIColor grayColor];
        cell.textLabel.font=[UIFont fontWithName:@"Roboto-Condensed" size:14];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }
    NSObject *object=[contentArray objectAtIndex:indexPat.row];
//    if ([contentModuleClass class]==[City class]) {
//        City *content=(City*)object;
//        cell.textLabel.text=content.cityName;
//    }else     if ([contentModuleClass class]==[Dish class]) {
//        Dish *content=(Dish*)object;
//        cell.textLabel.text=content.dishName;
//    }    if ([contentModuleClass class]==[Cuisine class]) {
//        Cuisine *content=(Cuisine*)object;
//        cell.textLabel.text=content.cuisineName;
//    }else   if ([contentModuleClass class]==[City class]) {
//        City *content=(City*)object;
//        cell.textLabel.text=content.cityName;
//    }
    cell.textLabel.text=[object valueForKey:selectorOnObject];
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return[contentArray count];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSObject *objec=[contentArray objectAtIndex:indexPath.row];
    self.hidden=YES;
    if (callback!=nil) {
        callback(objec);
    }
}
-(void)dealloc{
    //  self.DropDownTableView=nil;
    _DropDownTableView.delegate=nil;
    
}
- (void)completeSearchOperation{
    
}

@end
