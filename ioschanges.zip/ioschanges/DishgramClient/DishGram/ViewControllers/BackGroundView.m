//
//  BackGroundView.m
//  POPMarket
//
//  Created by kamit on 11/11/12.
//  Copyright (c) 2013 Neev Technologies. All rights reserved.
//

#import "BackGroundView.h"
#import "ViewController.h"
#import "AppDelegate.h"


@implementation BackGroundView

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:.7];
        self.tag = k_BACKVIEW_TAG;
      //  [self setUserInteractionEnabled:NO];
    }
    return self;
    
}

- (void)hideBackgroundView{
    
}
- (void)showBackGroundView{
    
}
@end
