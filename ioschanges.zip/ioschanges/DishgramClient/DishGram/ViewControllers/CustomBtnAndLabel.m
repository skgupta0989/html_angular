//
//  CustomBtnAndLabel.m
//  DishGram
//
//  Created by Rags on 26/04/13.
//
//

#import "CustomBtnAndLabel.h"

@implementation CustomBtnAndLabel
@synthesize buttons;

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"CustomBtnAndLabel" owner:self options:nil];
        UIView *buttonAndLabelView = [array objectAtIndex:0];
        [self addSubview:buttonAndLabelView];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (IBAction)buttonsCliked:(id)sender {
    
    [delegate landingPageBtnsClicked:sender];
    
}

@end
