//
//  BackGroundView.h
//  POPMarket
//
//  Created by kamit on 11/11/12.
//  Copyright (c) 2013 Neev Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BackGroundView : UIView{
}
@end
