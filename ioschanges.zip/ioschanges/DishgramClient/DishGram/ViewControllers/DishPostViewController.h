//
//  DishPostViewController.h
//  DishGram
//
//  Created by Ramesh Varma on 13/06/13.
//
//

#import <Foundation/Foundation.h>
#import "DishPostTemplateProvider.h"
#import "RestaurantInfoHeaderView.h"

@interface DishPostViewController : UIViewController {
    DishPostTemplateProvider *templateProvider;
    RestaurantInfoHeaderView *restaurantInfoHeaderView;
    
}


- (id)init:(NSString *)placeId dishId:(NSString *)dishId;


@end
