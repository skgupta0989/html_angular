//
//  DGRestuarentViewController.h
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import <UIKit/UIKit.h>
#import "DGLocationManager.h"
#import "DataSourceInterface.h"
#import "DGRestuarantData.h"

#define PLACEBYDISTANCECELL @"Distance"
#define PLACEBYNORMALCELL @"Normal"

@class DishDraft;
@interface DGRestuarentViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIAlertViewDelegate,DataInvokerDelegate>
{
    DGLocationManager *locationManager;
    CLLocation *userCurrentLocation;
    DataSourceInterface *dataSourceObj;
    NSString *placeType;
    BOOL isAddRestuarentButtonHidden;
    DGRestuarantData *restuarantData;
}
- (IBAction)addRestaurentButtonAction:(id)sender;
@property (nonatomic,strong)    NSMutableArray *placeArray;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *busyView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITableView *placeContainer;
@property (weak, nonatomic) IBOutlet UITextField *placeEnteryBox;
@property (weak, nonatomic) IBOutlet UIButton *addRestaurentButton;
@property (nonatomic,strong) DishDraft *dishDraft;
@end
