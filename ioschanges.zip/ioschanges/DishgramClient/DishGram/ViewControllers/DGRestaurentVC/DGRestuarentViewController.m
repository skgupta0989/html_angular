//
//  DGRestuarentViewController.m
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import "DGRestuarentViewController.h"

#import "Place.h"
#import "AppDelegate.h"
#import "DishDraft.h"
#import "RestuerentDistanceController.h"
#import "RestuerentNormalController.h"
#import "AddNewRestuarentVC.h"
#import "DishDetailAddViewController.h"
#import "DGImageUploadSingeloton.h"
#import "QuartzCore/QuartzCore.h"
#import "PageUtil.h"
#import "FontUtil.h"
#import "ZipCode.h"
#define but     CGRectMake(20,40,280,30)
#define FRAMEOFTEXTADD     CGRectMake(20,40,280,30)
@interface DGRestuarentViewController ()

@end

@implementation DGRestuarentViewController
@synthesize dishDraft,placeArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.placeArray=[[NSMutableArray alloc] init];
        
        DGRestuarantData *restuarantDataI=[[DGRestuarantData alloc] init];
        restuarantDataI.delegate=self;
        [restuarantDataI reset];
        restuarantData=restuarantDataI;
        restuarantDataI=nil;

    }
    return self;
}
- (void) configureNavigationControllerFor{
    ImageData *leftButtonData=[[ImageData alloc] init];
    
    NSMutableDictionary *leftDictionary=[[NSMutableDictionary alloc] init];
    [leftDictionary setObject:@"Cancel" forKey:@"title"];
    [leftDictionary setObject:[NSValue valueWithPointer:@selector(barButtonAction:)] forKey:@"selector"];
    [leftDictionary setObject:self forKey:@"target"];
    
    
    leftButtonData.imageInfo=leftDictionary;
    leftButtonData.image=[UIImage imageNamed:@"Post_cancel.png"];
    
    ImageData *rightButtonData=[[ImageData alloc] init];
    
    NSMutableDictionary *rightDictionary=[[NSMutableDictionary alloc] init];
    [rightDictionary setObject:@"   Next   " forKey:@"title"];
    [rightDictionary setObject:[NSValue valueWithPointer:@selector(barButtonAction:)] forKey:@"selector"];
    [rightDictionary setObject:self forKey:@"target"];
    
    
    rightButtonData.imageInfo=rightDictionary;
    rightButtonData.image=[UIImage imageNamed:@"Post_Next.png"];
    
    if(self.dishDraft.dishMode==dishModePost)
        [Utilities  setNavigation:@"Post" leftButtonInfo:leftButtonData rightButtonInfo:rightButtonData on:self.navigationItem];
    else
        [Utilities  setNavigation:@"Draft" leftButtonInfo:leftButtonData rightButtonInfo:rightButtonData on:self.navigationItem];

}
-(void)resetContent{
    NSLog(@"clear data");
    [self.busyView stopAnimating];
    [self.placeArray removeAllObjects];
    [restuarantData reset];
}
- (void)viewDidLoad
{
    [super viewDidLoad];

    [self configureNavigationControllerFor];
    
    
    self.titleLabel.font=[FontUtil robotoCondensedWithSize:16];
    self.placeContainer.hidden=YES;
    self.placeContainer.layer.borderColor=[UIColor lightGrayColor].CGColor;
    self.placeContainer.layer.borderWidth=.9;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textChanged:) name:UITextFieldTextDidChangeNotification object:self.placeEnteryBox];


}
-(void)textChanged:(NSNotification *)notification{
    NSLog(@"%d",self.placeEnteryBox.isEditing);
    
        if ([self isTextFieldIsEmpty:self.placeEnteryBox]) {
            [self performSelector:@selector(getPlaceByAutoSuzzetion:) withObject:self.placeEnteryBox.text afterDelay:.5];
        }else{
            [self performSelector:@selector(getDataForAPIDistance) withObject:nil afterDelay:.5];
        
    }

}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];


    self.placeContainer.separatorColor=[UIColor lightGrayColor];
    
    self.addRestaurentButton.hidden=YES;
    isAddRestuarentButtonHidden=YES;
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateLocation) name:DG_LOC_UPDATED object:nil];
        [self resetContent];
   // [NSThread detachNewThreadSelector:@selector(getDataForAPIDistance) toTarget:self withObject:nil];
    [self getDataForAPIDistance];
}

-(void)isTableIsVisible:(NSArray *)contentArray{
    if (contentArray.count==0) {
        self.placeContainer.hidden=YES;
    }else{
       self.placeContainer.hidden=NO;
    }

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setPlaceEnteryBox:nil];
    [self setPlaceContainer:nil];
    [self setAddRestaurentButton:nil];
    [self setTitleLabel:nil];
    [self setBusyView:nil];
    [super viewDidUnload];
}

- (void)updateLocation
{
    
    
}
-(NSMutableArray *)sorterArray:(NSArray *)array{
    NSSortDescriptor *discriptor = [[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES];
    NSArray *sorted = [array sortedArrayUsingDescriptors:[NSArray arrayWithObjects:discriptor, nil]];
    return [sorted mutableCopy];
}
#pragma mark- API Calls
-(NSMutableDictionary *)getParam:(NSString *)targetUrl{
    if ([targetUrl isEqualToString:PLACEBYDISTANCE]) {
        NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
        AppDelegate *app=(AppDelegate *)[UIApplication sharedApplication].delegate;
        CLLocation *locaiton=app.locations;
        [param setObject:[NSNumber numberWithFloat:locaiton.coordinate.latitude] forKey:@"latitude"];
        [param setObject:[NSNumber numberWithFloat:locaiton.coordinate.longitude] forKey:@"longitude"];

        return param;
    }else if([targetUrl isEqualToString:GET_AUTOFILL]){
        NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
        [param setObject:self.placeEnteryBox.text forKey:@"text"];
        [param setObject:@"PLACE" forKey:@"type"];
        AppDelegate *app=(AppDelegate *)[UIApplication sharedApplication].delegate;
        CLLocation *locaiton=app.locations;
        [param setObject:[NSNumber numberWithFloat:locaiton.coordinate.latitude] forKey:@"latitude"];
        [param setObject:[NSNumber numberWithFloat:locaiton.coordinate.longitude] forKey:@"longitude"];

        return param;
    }
    return nil;
}
-(void)getDataForAPIDistance{
    [self resetContent];
  [self.busyView startAnimating];
    [restuarantData fetchWithUrl:PLACEBYDISTANCE targetClass:[Place class]];
    
     DGRestuarentViewController * __weak blocksafeSelf = self;
    [restuarantData getNewDataFromServer:^(NSArray * fetcheArray){
                DGRestuarentViewController *strongSelf = blocksafeSelf;
        if (strongSelf) {
            if (fetcheArray.count != 0) {
                [strongSelf hideAddButtonToAddNewREstuarent];
                [strongSelf.placeArray addObjectsFromArray:fetcheArray];
                // placeArray=[self sorterArray:placeArray];
                [strongSelf isTableIsVisible:strongSelf.placeArray];
                [strongSelf reloadContentViewFor:PLACEBYDISTANCECELL];
                
                
            }else{
                [[[iToast makeText:@"No restuarant found near"] setGravity:iToastGravityCenter] show];
            }
          [blocksafeSelf.busyView stopAnimating];
        }

    }];
    
}
- (void)getPlaceByAutoSuzzetion:(NSString *)word{
    [self resetContent];
    [self.busyView startAnimating];
    [restuarantData fetchWithUrl:GET_AUTOFILL targetClass:[Place class]];
    
     DGRestuarentViewController * __weak blocksafeSelf = self;
    [restuarantData getNewDataFromServer:^(NSArray * fetcheArray){
        DGRestuarentViewController *strongSelf = blocksafeSelf;

        if (fetcheArray.count>0) {
           strongSelf.placeContainer.hidden=NO;
            [strongSelf.placeArray addObjectsFromArray:fetcheArray];
            [strongSelf isTableIsVisible:strongSelf.placeArray];
            [strongSelf hideAddButtonToAddNewREstuarent];
        }else{
            [strongSelf.placeArray removeAllObjects];
            [strongSelf showAddButtonToAddNewRestuarent];
            [strongSelf isTableIsVisible:strongSelf.placeArray];
            
        }
        [strongSelf reloadContentViewFor:PLACEBYNORMALCELL];
       [blocksafeSelf.busyView stopAnimating];
    }];


}

#pragma mark-
- (void) reloadContentViewFor:(NSString *)type{
    placeType=type;
    [self.placeContainer reloadData];
    
}

#pragma mark -UITableViewDelegate
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.placeArray==nil ||[self.placeArray class]==[NSNull class]) {
        
    }else{
        return    [self.placeArray count];
    }
    return 0;
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPat{
    static NSString *RestauIdentified=nil;
    
    if ([placeType isEqualToString:PLACEBYDISTANCECELL]) {
            RestauIdentified=@"a";
    }else if([placeType isEqualToString:PLACEBYNORMALCELL]){
            RestauIdentified=@"b";
    }
  //  static NSString *RestauIdentified=@"rest";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:RestauIdentified];
    if (cell==nil) {
        if ([placeType isEqualToString:PLACEBYDISTANCECELL]){
            cell=[[RestuerentDistanceController alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:RestauIdentified];
        }else if ([placeType isEqualToString:PLACEBYNORMALCELL]){
            cell=[[RestuerentNormalController alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:RestauIdentified];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;

    }
    @try {
        if ([placeType isEqualToString:PLACEBYDISTANCECELL]) {
            RestuerentDistanceController *distanceCell=(RestuerentDistanceController *)cell;
            [distanceCell populateRestuarent:[self.placeArray objectAtIndex:indexPat.row]location:userCurrentLocation];
            [distanceCell addControlActivity:[self getCallBack]];
            distanceCell=nil;
            
        }else if([placeType isEqualToString:PLACEBYNORMALCELL]){
            RestuerentNormalController *distanceCell=(RestuerentNormalController *)cell;
            [distanceCell populateRestuarent:[self.placeArray objectAtIndex:indexPat.row]location:userCurrentLocation];
            [distanceCell addControlActivity:[self getCallBack]];
            distanceCell=nil;
            
        }

    }
    @catch (NSException *exception) {
        
    }
    @finally {

    }
    return cell;
}


#pragma mark CELL Callback
-(void(^)(Place *place))getCallBack{
    
    DGRestuarentViewController * __weak blocksafeSelf = self;
    

    return ^(Place *place){
    DGRestuarentViewController *strongSelf = blocksafeSelf;
        strongSelf.dishDraft.restuarentName=[NSString stringWithFormat:@"%@ %@ %@ %@",place.name,place.address1,place.address2,place.zipCode];
        strongSelf.dishDraft.place=place;
        strongSelf.placeEnteryBox.text=place.name;
        strongSelf.dishDraft.city=place.zipCode.city;
    };
}

#pragma mark UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSLog(@"%@ %@",textField.text,string);
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
}
#pragma mark-
-(void)showAddButtonToAddNewRestuarent{
    DGRestuarentViewController * __weak blocksafeSelf = self;
    


    [UIView animateWithDuration:.2 animations:^{
    DGRestuarentViewController *strongSelf = blocksafeSelf;
        strongSelf.placeEnteryBox.frame=FRAMEOFTEXTADD;
    }completion:^(BOOL fin){
    DGRestuarentViewController *strongSelf = blocksafeSelf;
        strongSelf.addRestaurentButton.hidden=NO;
        isAddRestuarentButtonHidden=NO;
    }];
}
-(void)hideAddButtonToAddNewREstuarent{
        __weak typeof(self) weakSelf = self;
    [UIView animateWithDuration:.4 animations:^{
                    __weak typeof(weakSelf) strongSelf=weakSelf;
         strongSelf.addRestaurentButton.hidden=YES;
        strongSelf.placeEnteryBox.frame=but;
       
        
    }completion:^(BOOL fin){
        
    }];
}
- (IBAction)addRestaurentButtonAction:(id)sender {
    if (![self isTextFieldIsEmpty:self.placeEnteryBox]) {
        [[[iToast makeText:NSLocalizedString( @"Please Enter a Restaurant", @"")]
          setGravity:iToastGravityCenter] show];
        return;
    }
    

    NSString *rawString = [self.placeEnteryBox text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];

        if (self.dishDraft.place!=nil) {
            if (![self.dishDraft.place.name isEqualToString:self.placeEnteryBox.text]) {
                self.dishDraft.place=nil;
                Place *place=[[Place alloc] init];
                place.name=trimmed;
                place.uid=[NSNumber numberWithInt:-1];
                self.dishDraft.place=place;
                self.dishDraft.restuarentName=place.name;
            }
        }


    
    AddNewRestuarentVC *addNewRestuarentVC=[[AddNewRestuarentVC alloc] initWithNibName:@"AddNewRestuarentVC" bundle:nil];
    addNewRestuarentVC.searchedText=trimmed;
    addNewRestuarentVC.isVisible=@"POSTDETAIL";
    addNewRestuarentVC.dishDraft=self.dishDraft;
//    self.dishDraft.delegate=nil;
//    self.dishDraft=nil;
    [PageUtil push:addNewRestuarentVC];
    
}

#pragma mark-
-(BOOL)isTextFieldIsEmpty:(UITextField *)textField{
    if (textField.text==nil||[textField.text isEqualToString:@""]) {
        return NO;
    }else{
        NSString *rawString = [textField text];
        NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
        if ([trimmed length] == 0) {
            return NO;
        }
        //textField.text=trimmed;
    }
    return YES;
}
-(void)barButtonAction:(id)sender{
    
    UIButton *barItem=(UIButton *)sender;
    if (barItem.tag==2001) {
        if (![self isTextFieldIsEmpty:self.placeEnteryBox] && self.dishDraft.dishMode==dishModeDraft) {
            AppDelegate *delgate=(AppDelegate *)[UIApplication sharedApplication].delegate;
            [delgate.dgHomeController changeTabSelected:4 subSectionInTab:4];
            return;
        }

        [[DGImageUploadSingeloton singelton] discardDraft:self.dishDraft target:self];
                //[self cleanData];
    }else if(barItem.tag==2002){
        if (![self isTextFieldIsEmpty:self.placeEnteryBox]) {
            [[[iToast makeText:NSLocalizedString( @"Please Enter a Restaurant", @"")]
              setGravity:iToastGravityCenter] show];
        }else if(![self isTextFieldIsEmpty:self.placeEnteryBox]||dishDraft.place==nil){
            [[[iToast makeText:NSLocalizedString( @"Please add restaurant", @"")]
              setGravity:iToastGravityCenter] show];
            
        }else if(![dishDraft.place.name isEqualToString:self.placeEnteryBox.text]){
            [[[iToast makeText:NSLocalizedString( @"Please Select a Restaurant from List", @"")]
              setGravity:iToastGravityCenter] show];
        }else{
            if (self.dishDraft.dishMode == dishModePost) {
                [self showDishDetailAddVC:self.dishDraft];
            }
            else if (self.dishDraft.dishMode == dishModeDraft) {
                DGRestuarentViewController * __weak blocksafeSelf = self;
                

                [[DGImageUploadSingeloton singelton] uploadNewDraft:self.dishDraft callback:^(id response) {
                DGRestuarentViewController *strongSelf = blocksafeSelf;
                    if (strongSelf.dishDraft.draft.uid) {
                        [strongSelf showDishDetailAddVC:strongSelf.dishDraft];
                    }
                    else {
                        NSLog(@"Unable to post draft on server !!!");
                    }
                    
                }];
            }
        }
    }
}
-(void)cleanData{
    locationManager=nil;;
    userCurrentLocation=nil;;
    dataSourceObj=nil;;
    placeType=nil;
        [placeArray removeAllObjects];
    placeArray=nil;

    restuarantData.delegate=nil;
    restuarantData=nil;

    self.dishDraft.delegate=nil;
    self.dishDraft=nil;
    
    
    self.placeContainer.delegate=nil;
    self.placeContainer.dataSource=nil;
    [self cleanNototification];
}
-(void)cleanNototification{
    @try {
            [[NSNotificationCenter defaultCenter] removeObserver:UITextFieldTextDidChangeNotification];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}
- (void)showDishDetailAddVC:(DishDraft *)dd {

    DishDetailAddViewController *dishDetialVc=[[DishDetailAddViewController alloc] initWithNibName:@"DishDetailAddViewController" bundle:nil];
    dishDetialVc.dishDraft = dd;
//    self.dishDraft.delegate=nil;
//    self.dishDraft=nil;
     //   [self cleanData];
    [PageUtil push:dishDetialVc];

}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
        AppDelegate *delgate=(AppDelegate *)[UIApplication sharedApplication].delegate;
    if (buttonIndex==0) {
        [self.dishDraft discardDraft];
        [delgate.dgHomeController changeTabSelected:4 subSectionInTab:1];
    }else if(buttonIndex==1){
        if (self.dishDraft.place!=nil) {
            if (![self.dishDraft.place.name isEqualToString:self.placeEnteryBox.text]) {
                self.dishDraft.place=nil;
                Place *place=[[Place alloc] init];
                place.name=self.placeEnteryBox.text;
                place.uid=[NSNumber numberWithInt:-1];
                self.dishDraft.place=place;
                self.dishDraft.restuarentName=place.name;
            }
        }else{
            self.dishDraft.place=nil;
            Place *place=[[Place alloc] init];
            place.name=self.placeEnteryBox.text;
            place.uid=[NSNumber numberWithInt:-1];
            self.dishDraft.place=place;
            self.dishDraft.restuarentName=place.name;
        }
        
        [self.dishDraft uploadDraftJsonWithCallback:^(id response) {
        [delgate.dgHomeController changeTabSelected:4 subSectionInTab:4];
            if (response) 
                NSLog(@"%@",response);
            else
                DLog(@"Unable to save draft to server");
            
        }];
         
    }
    
}
#pragma UIScrollViewDelegate
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self.view endEditing:YES];    
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (!self.busyView.isAnimating) {
        float bottomEdge = scrollView.contentOffset.y + scrollView.frame.size.height;
        if (bottomEdge >= scrollView.contentSize.height) {
          [self.busyView startAnimating];
            
     DGRestuarentViewController * __weak blocksafeSelf = self;
            [restuarantData getMoreDataFromServer:^(NSArray * fetcheArray,NSString *target){
        DGRestuarentViewController *strongSelf = blocksafeSelf;
                if (fetcheArray!=nil) {
                   [strongSelf.placeArray addObjectsFromArray:fetcheArray];
                    if ([target isEqualToString:PLACEBYDISTANCE]) {
                        [strongSelf reloadContentViewFor:PLACEBYDISTANCECELL];
                    }else if([target isEqualToString:GET_AUTOFILL]){
                        [strongSelf reloadContentViewFor:PLACEBYNORMALCELL];
                    }
                    
                }
             [blocksafeSelf.busyView stopAnimating];
            }];
            
        }
        
    }
    
}
-(void)dealloc{
[self.placeEnteryBox resignFirstResponder];
    
    [self.placeArray removeAllObjects];
    self.dishDraft.delegate=nil;
    self.dishDraft=nil;
    [self cleanNototification];
    DLog("DGRestuarantVC dealloc");
}

@end
