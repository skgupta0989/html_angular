//
//  RestuerentNormaController.h
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
@class Place;
@interface RestuerentNormalController : UITableViewCell{
    void (^callback)(Place *object);
    Place *data;;

}
@property (weak, nonatomic) IBOutlet UILabel *restuarentAddressLine2;
@property (weak, nonatomic) IBOutlet UILabel *restuarentAddressLabel;
@property (weak, nonatomic) IBOutlet UILabel *restuarentNameLabel;
-(void)addControlActivity:(void (^)(Place *place))controllerCallback;
-  (void)populateRestuarent:(Place*)restuarent location:(CLLocation *)userLocation;
@end
