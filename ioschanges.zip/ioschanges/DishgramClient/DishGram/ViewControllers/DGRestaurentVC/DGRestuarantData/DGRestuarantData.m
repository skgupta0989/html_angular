//
//  DGRestuarantData.m
//  DishGram
//
//  Created by SumanAmit on 01/08/13.
//
//

#import "DGRestuarantData.h"
#import "DataSourceInterface.h"
#import "DataSourceFactory.h"
#import "MKNetworkEngine.h"
@implementation DGRestuarantData
/*
 set the url and target class for request
 targetURL: url to be fetched
 invokerclass: the desired class
 @prams
 
 */

-(void)fetchWithUrl:(NSString *)URL targetClass:(Class)targetClass{
        [self reset];
        self.targetUrl=URL;
        self.invokerClass=targetClass;
}

/*
 request for new data by picking out page number and maz,
 
 @prams
 dictionary:contain mutable request data
 max: limit
 offset: is poition from where page number is to be fetched
 
 controllerCallback:return the data
 
 */

-(void)getNewDataFromServer:(void (^)(NSArray *fetchArray))controllerCallback{
    [self reset];
    if (self.isRequiredToMakeCall) {
        if ([self.delegate respondsToSelector:@selector(getParam:)]) {
            NSMutableDictionary *dictionary=[self.delegate getParam:self.targetUrl];
            if (dictionary!=nil) {
                [dictionary setObject:[NSNumber numberWithInt:self.offset] forKey:@"offset"];
                [dictionary setObject:[NSNumber numberWithInt:self.max] forKey:@"max"];
            }
            DataSourceInterface *dataSourceObj = [DataSourceFactory getDataSourceInstance];
            
             DGRestuarantData * __weak blocksafeSelf = self;
            
            [dataSourceObj requestDataWithURLString:self.targetUrl params:dictionary modelClass:[self.invokerClass class] callBack:^(bool success, NSObject *response) {
                DGRestuarantData *strongSelf = blocksafeSelf;
                if (success) {
                    
                    NSArray *placeArray=(NSArray *)response;
                    if (placeArray.count>0) {
                       strongSelf.isRequiredToMakeCall=YES;
                        controllerCallback(placeArray);
                        strongSelf.offset=(strongSelf.offset+strongSelf.max+1);
                    }else{
                        strongSelf.isRequiredToMakeCall=NO;
                        if (strongSelf.offset==0) {
                            controllerCallback(nil);
                        }
                    }
                }else{
                    if (strongSelf.offset==0) {
                        strongSelf.isRequiredToMakeCall=YES;
                        controllerCallback(nil);
                    }else{
                        controllerCallback(nil);
                    }
                    
                }
            }];
        }
    }else{
        controllerCallback(nil);
    }
}
/*
    request for more data by picking out page number and maz,
    
    @prams
 
    max: limit
    offset: is poition from where page number is to be fetched
    
    controllerCallback:return the data
 
 */

-(void)getMoreDataFromServer:(void (^)(NSArray *fetchArray,NSString* target))controllerCallback{
    
    if (self.isRequiredToMakeCall) {
        if ([self.delegate respondsToSelector:@selector(getParam:)]) {
            NSMutableDictionary *dictionary=[self.delegate getParam:self.targetUrl];
            if (dictionary!=nil) {
                [dictionary setObject:[NSNumber numberWithInt:self.offset] forKey:@"offset"];
                [dictionary setObject:[NSNumber numberWithInt:self.max] forKey:@"max"];
            }

            DGRestuarantData * __weak blocksafeSelf = self;
            DataSourceInterface *dataSourceObj = [DataSourceFactory getDataSourceInstance];
            [dataSourceObj requestDataWithURLString:self.targetUrl params:dictionary modelClass:[self.invokerClass class] callBack:^(bool success, NSObject *response) {
                DGRestuarantData *strongSelf = blocksafeSelf;
                if (success) {
                    NSArray *placeArray=(NSArray *)response;
                    
                    if (placeArray.count>0) {
                        strongSelf.isRequiredToMakeCall=YES;
                        controllerCallback(placeArray,strongSelf.targetUrl);
                        strongSelf.offset=(strongSelf.offset+strongSelf.max+1);
                    }else{
                        blocksafeSelf.isRequiredToMakeCall=NO;
                        if (strongSelf.offset==0) {
                            controllerCallback(nil,strongSelf.targetUrl);
                        }else{
                            controllerCallback(nil,strongSelf.targetUrl);
                        }
                    }
                }else{
                    if (strongSelf.offset==0) {
                        strongSelf.isRequiredToMakeCall=YES;
                        controllerCallback(nil,strongSelf.targetUrl);
                    }
                            controllerCallback(nil,strongSelf.targetUrl);
                }
            }];
        }
    }else{
        controllerCallback(nil,self.targetUrl);
    }
}
- (void)reset{
    @try {
        [MKNetworkEngine cancelOperationsContainingURLString:self.targetUrl];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    self.offset=0;
    self.max=10;
    self.isRequiredToMakeCall=YES;
    
}
@end
