//
//  DGRestuarantData.h
//  DishGram
//
//  Created by SumanAmit on 01/08/13.
//
//

#import <Foundation/Foundation.h>

@protocol DataInvokerDelegate <NSObject>
-(NSMutableDictionary *)getParam:(NSString *)targetUrl;
@end

@interface DGRestuarantData : NSObject{
}
@property (nonatomic , weak)id <DataInvokerDelegate>delegate;
@property (nonatomic, weak) NSString *targetUrl;
@property (nonatomic, weak) Class invokerClass;
@property (nonatomic,assign)    BOOL isRequiredToMakeCall;
@property (nonatomic,assign)int offset,max;
- (void)fetchWithUrl:(NSString *)URL targetClass:(Class)targetClass;

- (void)reset;


-(void)getNewDataFromServer:(void (^)(NSArray *fetchArray))controllerCallback;


-(void)getMoreDataFromServer:(void (^)(NSArray *fetchArray,NSString* target))controllerCallback;
@end
