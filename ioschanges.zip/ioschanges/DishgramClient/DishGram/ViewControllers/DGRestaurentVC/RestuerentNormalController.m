//
//  RestuerentNormaController.m
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import "RestuerentNormalController.h"
#import "DGLocationManager.h"
#import "Place.h"
#import "City.h"
#import "ZipCode.h"
#import "State.h"
@implementation RestuerentNormalController
@synthesize restuarentNameLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"RestaurentNormalController" owner:self options:nil];
        UIView *buttonAndLabelView = [array objectAtIndex:0];
        // buttonAndLabelView.frame=CGRectMake(0, 5, frame.size.width, 30);
        buttonAndLabelView.backgroundColor=[UIColor clearColor];
        [self addSubview:buttonAndLabelView];
    }
    return self;
}


-(void)addControlActivity:(void (^)(Place *place))controllerCallback{
    callback=[controllerCallback copy];
}
-  (void)populateRestuarent:(Place*)restuarent location:(CLLocation *)userLocation{
    data=nil;
    data=restuarent;
    restuarentNameLabel.text=data.name;
    self.restuarentAddressLabel.text=data.address1;
//    NSString *resturant;
//    if (data.address2!=nil) {
//        resturant=data.address2;
//    }else if(data.zipCode.city.cityName!=nil && data.zipCode.city.state.stateName!=nil){
//        resturant=[NSString stringWithFormat:@"%@,%@",data.zipCode.city.cityName,data.zipCode.city.state.stateName];
//    }else if(data.zipCode.city.cityName!=nil){
//        resturant=[NSString stringWithFormat:@"%@",data.zipCode.city.cityName];
//        
//    }else if(data.zipCode.city.state.stateName!=nil){
//        resturant=[NSString stringWithFormat:@"%@",data.zipCode.city.state.stateName];
//    }
//
//    self.restuarentAddressLine2.text=resturant;

}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    if (selected) {
        self.backgroundColor=[UIColor grayColor];
        callback(data);
    }else{
        self.backgroundColor=[UIColor clearColor];
    }
}

-(void)dealloc{
    data=nil;
    callback=nil;
  //  DLog();
}
@end
