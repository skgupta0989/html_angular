//
//  RestuerentDistanceController.m
//  DishGram
//
//  Created by SumanAmit on 30/05/13.
//
//

#import "RestuerentDistanceController.h"
#import "Place.h"
#import "ZipCode.h"
#import "City.h"
#import "State.h"
#import "DGLocationManager.h"
#import "AppDelegate.h"
#import "PageUtil.h"
#import "PlaceCoords.h"
@implementation RestuerentDistanceController
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"RestuarentDistanceView" owner:self options:nil];
        UIView *buttonAndLabelView = [array objectAtIndex:0];
        buttonAndLabelView.backgroundColor=[UIColor clearColor];
        [self addSubview:buttonAndLabelView];
    }
    return self;
}
-(void)addControlActivity:(void (^)(Place *place))controllerCallback{
    @autoreleasepool {
        callback=[controllerCallback copy];
    }
}

-  (void)populateRestuarent:(Place*)restuarent location:(CLLocation *)userLocation{
    data=nil;
    data=restuarent;

    self.RestuarentNameLabel.text=data.name;
    PlaceCoords *coordinate=[[PlaceCoords alloc] init:[data.latitude doubleValue]  longitude:[data.longitude doubleValue] address:nil];
    NSString *message=[PageUtil distanceFromCurDeviceLock:coordinate];
    self.farFromLabel.text=message;
    self.restuarentAddressLabel.text=data.address1;
    
//    NSString *resturant;
//    if (data.address2!=nil) {
//        resturant=data.address2;
//    }else if(data.zipCode.city.cityName!=nil && data.zipCode.city.state.stateName!=nil){
//        resturant=[NSString stringWithFormat:@"%@,%@",data.zipCode.city.cityName,data.zipCode.city.state.stateName];
//    }else if(data.zipCode.city.cityName!=nil){
//        resturant=[NSString stringWithFormat:@"%@",data.zipCode.city.cityName];
//        
//    }else if(data.zipCode.city.state.stateName!=nil){
//                resturant=[NSString stringWithFormat:@"%@",data.zipCode.city.state.stateName];
//    }
//    
//    self.restuarentAddressLine2.text=resturant;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    if (selected) {
        self.backgroundColor=[UIColor lightGrayColor];
          callback(data);
    }else{
        self.backgroundColor=[UIColor clearColor];
    }
}

-(void)dealloc{
    //self.data=nil;
    data=nil;
    callback=nil;
//    [self removeGestureRecognizer:tap];
//    tap=nil;
 //   DLog();
}
@end
