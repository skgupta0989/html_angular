//
//  DishDetailAddViewController.m
//  DishGram
//
//  Created by SumanAmit on 04/06/13.
//
//

#import "DishDetailAddViewController.h"

#import "DGRatingView.h"
#import "DGToggel.h"
#import "DGOptionSet.h"
#import "DGDropDown.h"

#import "PageUtil.h"
#import "AppDelegate.h"

#import "DGImageUploadSingeloton.h"
#import "DishDraft.h"
#import "ViewPostController.h"

#import "Dish.h"
#import "Cuisine.h"
#import "DishType.h"
#import "StringConstant.h"
#import "ComboboxView.h"
#import "QuartzCore/QuartzCore.h"
#import "SettingController.h"
#import "PostDishViewController.h"
#import "FontUtil.h"
#import "Token.h"
#define DDFOOD @"FOOD"
#define DDBEVERAGES @"BEVERAGE"
#define DDRATEDISH @"Rate the dish"
#define DDRATEBEVERAGES  @"Rate the beverages"
@interface DishDetailAddViewController ()

@end

@implementation DishDetailAddViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void) configureNavigationControllerFor{
    ImageData *leftButtonData=[[ImageData alloc] init];
    
    NSMutableDictionary *leftDictionary=[[NSMutableDictionary alloc] init];
    [leftDictionary setObject:@"Cancel" forKey:@"title"];
    [leftDictionary setObject:[NSValue valueWithPointer:@selector(barButtonAction:)] forKey:@"selector"];
    [leftDictionary setObject:self forKey:@"target"];
    
    
    leftButtonData.imageInfo=leftDictionary;
    leftButtonData.image=[UIImage imageNamed:@"Post_cancel.png"];
    
    ImageData *rightButtonData=[[ImageData alloc] init];
    
    NSMutableDictionary *rightDictionary=[[NSMutableDictionary alloc] init];
    [rightDictionary setObject:@"   Post   " forKey:@"title"];
    [rightDictionary setObject:[NSValue valueWithPointer:@selector(barButtonAction:)] forKey:@"selector"];
    [rightDictionary setObject:self forKey:@"target"];
    
    
    rightButtonData.imageInfo=rightDictionary;
    rightButtonData.image=[UIImage imageNamed:@"Post_Next.png"];
    
    if(self.dishDraft.dishMode==dishModePost)
        [Utilities  setNavigation:@"Post" leftButtonInfo:leftButtonData rightButtonInfo:rightButtonData on:self.navigationItem];
    else
        [Utilities  setNavigation:@"Draft" leftButtonInfo:leftButtonData rightButtonInfo:rightButtonData on:self.navigationItem];

}
-(Cuisine *)getSelected{
    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    __block Cuisine *searchCusine;
    DishDetailAddViewController * __weak blocksafeSelf = self;


    [dataSource requestDataWithURLString:GET_CUISINE_LIST params:[[NSMutableDictionary alloc] init] modelClass:[Cuisine class] callBack:^(bool success, NSObject *response){
        DishDetailAddViewController *strongSelf = blocksafeSelf;
        if (success) {
            NSArray *data = (NSArray *)response;
            NSPredicate *predicate=[NSPredicate predicateWithFormat:@"cuisineName==%@",strongSelf.cuisine.textField_.text];
            NSArray *result=[data filteredArrayUsingPredicate:predicate];
            searchCusine=[result lastObject];
        }
    }];
    return searchCusine;
}

#pragma mark- WebComboDeleate
-(void)textFieldReturn:(ComboboxView *)view{
            [self textFieldShouldReturn:view.textField_];
}
-(Class)getTargetClass:(WebComboBoxView *)view{
    return     [Dish class];
}
-(NSString *)getDesiredUrl:(ComboboxView *)view{
    return GET_AUTOFILL;
}

-(NSString *)getTargetMeamber:(ComboboxView *)view{
    return @"dishName_";
}

-(NSMutableDictionary *)getParamDictionary:(ComboboxView *)view{
    NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
    [param setObject:[NSNumber numberWithInt:100] forKey:@"max"];
    [param setObject:[NSNumber numberWithInt:0] forKey:@"offset"];
    if (dgOptionSet.selectedOptoin==1) {
        [param setObject:DDFOOD forKey:@"dishType"];
    }else if(dgOptionSet.selectedOptoin==2){
        [param setObject:DDBEVERAGES forKey:@"dishType"];
    }

    [param setObject:@"DISH" forKey:@"type"];
    return param;
}
-(void)selectedOption:(NSObject *)object ofView:(ComboboxView *)view{
    Dish *dish=(Dish *)object;
    dishNameComboBox.textField_.text=dish.dishName;
    self.dishDraft.dish=dish;
    if ([dish.dishType.dishTypeName isEqualToString:VEG]) {
        [dgToggelViewFood setSelectedIndex:1];
    } else if ([dish.dishType.dishTypeName isEqualToString:NONVEG]) {
        [dgToggelViewFood setSelectedIndex:2];
    }else if(([dish.dishType.dishTypeName isEqualToString:ALCOHOLIC])){
        [dgToggelViewBeverage setSelectedIndex:1];
    }else if([dish.dishType.dishTypeName isEqualToString:NONALCOHOLIC]){
        [dgToggelViewBeverage setSelectedIndex:2];
    }
}
-(void)textFieldBeginEditing:(ComboboxView *)view{
    [Utilities makeTextFieldVisibleForRect:view.textField_];
}
-(void)initDishView{
    dishNameComboBox = [[WebComboBoxView alloc]initWithFrame:CGRectMake(13, 103, 285, 30) data:nil ddSize:80 placeHolder:DISH_NAME ddType:0 ];
    dishNameComboBox.delegate=self;
    dishNameComboBox.textField_.returnKeyType=UIReturnKeyNext;
    [self.containerView addSubview:dishNameComboBox];
}
#pragma mark-
-(void)makeCusineField:(NSArray *)data{
    self.cuisine = [[ComboboxView alloc] initWithFrame:CGRectMake(140, 150, 158, 30) data:data ddSize:80 placeHolder:@"Cuisine" ddSize:0];
    self.cuisine.delegate=self;
    [self.containerView addSubview:self.cuisine];
    
    self.cuisine.backgroundColor = [UIColor whiteColor];
    self.cuisine.textField_.returnKeyType=UIReturnKeyNext;
  
    
}
-(void)initCuisineField{
    if (self.cuisine!=nil) {
        self.cuisine.delegate=nil;
        [self.cuisine removeFromSuperview];
        self.cuisine=nil;
    }

    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    
    DishDetailAddViewController * __weak blocksafeSelf = self;


    [dataSource requestDataWithURLString:GET_CUISINE_LIST params:[[NSMutableDictionary alloc] init] modelClass:[Cuisine class] callBack:^(bool success, NSObject *response){
            DishDetailAddViewController *strongSelf = blocksafeSelf;
        if (success) {
            
            NSArray *data = (NSArray *)response;
            
            NSMutableArray *arr = [[NSMutableArray alloc] init];
            for (int i = 0; i < data.count; ++i) {
                [arr addObject:((Cuisine *)[data objectAtIndex:i]).cuisineName];
            }
            [strongSelf makeCusineField:[arr copy]];

        } else {
            [[[iToast makeText:@"Server conneciton failed"]
              setGravity:iToastGravityCenter] show];
        }
    }];
}
#pragma mark-
-(void)populateInfoForView{
    if (self.dishDraft.dishMode==dishModeDraft) {
            [self.pickDishImageButton setBackgroundImage:[UIImage imageNamed:@"upload.png"] forState:UIControlStateNormal];
            self.pickDishImageButton.imageEdgeInsets=UIEdgeInsetsMake(-30, 12, 0, 10);
            [self.pickDishImageButton setHidden:FALSE];
        
        if ([self.dishDraft.dishType isEqualToString:@"1"] || [self.dishDraft.dishType isEqualToString:@"2"]) {
            [dgOptionSet setOptionSelected:1];
            [self loadViewForFood];
            [dgToggelViewFood setSelectedIndex:[self.dishDraft.dishType integerValue]];
        }
        
        else if ([self.dishDraft.dishType isEqualToString:@"3"] || [self.dishDraft.dishType isEqualToString:@"4"]) {
            [dgOptionSet setOptionSelected:2];
            [self loadViewForDrink];
            [dgToggelViewBeverage setSelectedIndex:([self.dishDraft.dishType integerValue]/2)];
            
        }else{
            [dgOptionSet setOptionSelected:1];
            [self loadViewForFood];
            [dgToggelViewFood setSelectedIndex:1];
            
        }
        
        //Show rating
        if (self.dishDraft.ratingForDish > 0)
            [dgRatingView loadRating:self.dishDraft.ratingForDish]; // To map rating with tag
        
        
        //Show Draft Image after Image Upload.
        if (self.dishDraft.image) {
            self.dishImageView.image = self.dishDraft.image;
            [self.pickDishImageButton setBackgroundImage:self.dishDraft.image forState:UIControlStateNormal];
            
        }
        else if(self.dishDraft.draft.dishImageThumbnail.dishURL) {
            NSURL *thmbUrl = [[NSURL alloc] initWithString:self.dishDraft.draft.dishImageThumbnail.dishURL];
            NSData *data = [[NSData alloc] initWithContentsOfURL:thmbUrl];
            UIImage *image = [[UIImage alloc] initWithData:data];
            if (image){
                self.dishImageView.image = image;
                [self.pickDishImageButton setBackgroundImage:image forState:UIControlStateNormal];
            }
        }
        [dishNameComboBox.textField_ setText:self.dishDraft.dish.dishName];
        
        [self.cuisine.textField_ setText: self.dishDraft.cuisine.cuisineName];
        
        [self.nameOfTextField setText:self.dishDraft.userDishDescription] ;

    }else if(self.dishDraft.dishMode==dishModePost){
            [self loadViewForFood];
            [self.pickDishImageButton setHidden:TRUE];
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_pattern.png"]];
    
    self.titleLabel.font=[FontUtil robotoCondensedWithSize:16];
    
    UIImageView *dashImage=[PageUtil addDashedHLine:56 start:13 end:298 color:[UIColor grayColor] ofView:self.containerView];
    
    [self.normalBackView addSubview:dashImage];
    
    CGRect rect;
    rect=CGRectMake(15, 230, 290, 38);
    dgRatingView=[[DGRatingView alloc] initWithFrame:rect];
    dgRatingView.backgroundColor=[UIColor blackColor];
    [dgRatingView addTarget:self rootAction:@selector(rationChange:)];
     dgRatingView.containerViewOfRating.frame=CGRectMake(70, 3, 141, 39);
    [dgRatingView.nameOfLabel setFont:[UIFont fontWithName:@"Roboto-Condensed" size:12]];

    [self.containerView addSubview:dgRatingView];
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [PageUtil addHLine:280 start:0 end:310 context:context color:[UIColor lightGrayColor]];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIImageView * imageView = [[UIImageView alloc] initWithImage:newImage];
    //CGContextRelease(context);
    UIGraphicsEndImageContext();

    [self.containerView addSubview:imageView];
    [self.containerView bringSubviewToFront:imageView];
    rect=CGRectMake(10, 41, 183, 33);

    NSMutableDictionary *opContext=[[NSMutableDictionary alloc] init];

    dgOptionSet = [PageUtil foodBeverageOptionSet:(NSObject *)self width:rect.size.width height:rect.size.height action:@selector(dgOptionAction:)context:opContext];
    dgOptionSet.frame=rect;
    [self.containerView addSubview:dgOptionSet];

    rect=CGRectMake(15, 286, 278, 145);
    socialNetork=[[ShareSocialNetworkView alloc] initWithFrame:CGRectMake(rect.origin.x-6, rect.origin.y-5, rect.size.width+40, rect.size.height)];
    socialNetork.dishDraft=_dishDraft;
    socialNetork.delegate = self;
    
    dashImage=[PageUtil addDashedHLine:30 start:3 end:288 color:[UIColor grayColor] ofView:socialNetork];
    [socialNetork addSubview:dashImage];
    
    
    [self.containerView addSubview:socialNetork];
    
    self.dishImageView.image=self.dishDraft.image;
    
    [self.view bringSubviewToFront:self.containerView];
    
    [self configureNavigationControllerFor];
    
    [self initDishView];
    
    
   // self.nameOfTextField.placeholder=DISH_DESCRIPTION;
    
    [self.containerView setShowsVerticalScrollIndicator:NO];
    self.containerView.contentSize=CGSizeMake(self.containerView.frame.size.width, self.containerView.frame.size.height+150);

    [self populateInfoForView];
    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:TRUE];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewDidUnload {
    //self.dishDraft=nil;
        
    
    [self setImageBackgroundImage:nil];
    [self setDishImageView:nil];
    [self setNameOfTextField:nil];
    [self setContainerView:nil];
    [self setNormalBackView:nil];
    [self setPickDishImageButton:nil];

    self.cuisine.delegate=nil;
    dishNameComboBox.delegate=nil;
    

    socialNetork=nil;
    dgRatingView=nil;
    dishNameComboBox=nil;
    dgToggelViewBeverage=nil;
    dgToggelViewFood=nil;
    dgOptionSet=nil;
    dishNameComboBox=nil;
    self.cuisine=nil;

    
    [self setTitleLabel:nil];
    [super viewDidUnload];
}
#pragma mark -
- (void)dgOptionAction:(DGOptionSet *)sender{
    [dishNameComboBox removeDropDownView];
    
    dishNameComboBox.textField_.text=@"";
    _nameOfTextField.text=@"";
    [dgRatingView markRating:nil];
    if (sender.selectedOptoin==1) {
                dgRatingView.containerViewOfRating.frame=CGRectMake(70, 3, 141, 39);
        [self loadViewForFood];
        [dgRatingView.nameOfLabel setText:DDRATEDISH];

    }else if(sender.selectedOptoin==2){
                dgRatingView.containerViewOfRating.frame=CGRectMake(100, 3, 141, 39);
        [self loadViewForDrink];
        [dgRatingView.nameOfLabel setText:DDRATEBEVERAGES];

    }
}
-(void)cleanAllCusine{
    NSArray *views=[self.containerView subviews];
    for (UIView *view in views) {
        if ([view class]==[ComboboxView class]) {
            ComboboxView *c=(ComboboxView *)view;
            if (c==self.cuisine) {
                [self.cuisine removeFromSuperview];
                self.cuisine.delegate=nil;
                [self.cuisine.textField_ resignFirstResponder];
                self.cuisine=nil;
                
            }
        }
    }
}
- (void)loadViewForFood{
    
    
    [dgToggelViewBeverage removeFromSuperview];
    [dgToggelViewFood removeFromSuperview];
    
    /**
     @amit: ##change UIModificatin with veg and non Veg
     ****/
   // [self initCuisineField];
    
    dgToggelViewFood=[[DGToggel alloc] initWithItems:[NSArray arrayWithObjects:VEG,NONVEG, nil]];
    [dgToggelViewFood setLeftButtonSelectdColor:[UIColor colorWithRed:95.0/255 green:210.0/255 blue:114.0/255 alpha:1.0] unslectedColor:[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0]];
    [dgToggelViewFood setRightButtonSelectdColor:[UIColor colorWithRed:249.0/255 green:64.0/255 blue:70.0/255 alpha:1.0] unslectedColor:[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0]];
    [dgToggelViewFood setTextColorSelected:[UIColor whiteColor] unSelectColor:[UIColor lightGrayColor]];
    [dgToggelViewFood setFont:[UIFont fontWithName:@"Roboto-Regular" size:12]];
    [dgToggelViewFood addTarget:self action:@selector(toggelAction:)];
    CGRect rect=CGRectMake(13, 150, 120, 29);
    dgToggelViewFood.tag=3001;
    dgToggelViewFood.frame=CGRectMake(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height);;

    /**
     @amit: ##change UIModificatin with veg and non Veg
     Action:set dgToggelViewFood to center
     ****/
    
    dgToggelViewFood.center=CGPointMake(self.view.frame.size.width/2, (rect.origin.y+rect.size.height/2));
    [dgToggelViewFood setSelectedIndex:1];
    [self.containerView addSubview:dgToggelViewFood];

}
- (void)loadViewForDrink{
    [dgToggelViewBeverage removeFromSuperview];
    [dgToggelViewFood removeFromSuperview];
    [self cleanAllCusine];
    
    dgToggelViewBeverage=[[DGToggel alloc] initWithItems:[NSArray arrayWithObjects:ALCOHOLIC, NONALCOHOLIC, nil]];
    [dgToggelViewBeverage setLeftButtonSelectdColor:[UIColor colorWithRed:249.0/255 green:64.0/255 blue:70.0/255 alpha:1.0] unslectedColor:[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0]];
     [dgToggelViewBeverage setRightButtonSelectdColor:[UIColor colorWithRed:95.0/255 green:210.0/255 blue:114.0/255 alpha:1.0] unslectedColor:[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0]];
    [dgToggelViewBeverage setTextColorSelected:[UIColor whiteColor] unSelectColor:[UIColor lightGrayColor]];
    [dgToggelViewBeverage setFont:[UIFont fontWithName:@"Roboto-Regular" size:12]];
    [dgToggelViewBeverage addTarget:self action:@selector(toggelAction:)];
    CGRect rect=CGRectMake(13, 150, 106, 29);;
    dgToggelViewBeverage.tag=3002;
    dgToggelViewBeverage.frame=CGRectMake(rect.origin.x, rect.origin.y, rect.size.width+100, rect.size.height);
    /**
     @amit: ##change UIModificatin with veg and non Veg
     Action:set dgToggelViewBeverages to center
     ****/
    dgToggelViewBeverage.center=CGPointMake(self.view.frame.size.width/2, (rect.origin.y+rect.size.height/2));
    [dgToggelViewBeverage setSelectedIndex:1];
    [self.containerView addSubview:dgToggelViewBeverage];
    

}

- (void)toggelAction:(DGToggel *)toggle{
    
    if (toggle.tag==3001) {
        if (toggle.selectedToggel==1) {
            self.dishDraft.dishType=VEG;
        }else if(toggle.selectedToggel==2){
            self.dishDraft.dishType=NONVEG;
        }
        
    }else  if (toggle.tag==3002){
        if (toggle.selectedToggel==1) {
            self.dishDraft.dishType=ALCOHOLIC;
        }else if(toggle.selectedToggel==2){
            self.dishDraft.dishType=NONALCOHOLIC;
        }
        
    }
}
- (void)rationChange:(DGRatingView *)ratingView{
    self.dishDraft.ratingForDish=ratingView.currentRating;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
#pragma mark-UITextFieldDeleate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField==self.nameOfTextField) {
        NSUInteger newLength = [textField.text length] + [string length] - range.length;
        return (newLength > 255) ? NO : YES;
        
    }
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (dishNameComboBox.textField_==textField) {
        if (self.cuisine!=nil) {
            [Utilities makeTextFieldVisibleForRect:self.cuisine.textField_];
            [self.cuisine textFieldBeginEditing];
            
        }else{
        [self.nameOfTextField becomeFirstResponder];            
        }
    }else if(self.cuisine.textField_==textField){
        [self.nameOfTextField becomeFirstResponder];
    }else if(textField==self.nameOfTextField){
        [self postActionForPostingDish];
    }
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
        [Utilities makeTextFieldVisibleForRect:textField];
        return YES;
}
- (BOOL)isPhoneNumberValid:(NSString *)phoneNumber{
    BOOL valid;
    NSCharacterSet *alphaNums = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *inStringSet = [NSCharacterSet characterSetWithCharactersInString:phoneNumber];
    valid = [alphaNums isSupersetOfSet:inStringSet];
    if (phoneNumber.length==10 && valid==YES) {
        return YES;
    }
    return NO;
}

-(BOOL)isTextFieldIsEmpty:(UITextField *)textField{
    if (textField.text==nil||[textField.text isEqualToString:@""]) {
        return NO;
    }else{
        NSString *rawString = [textField text];
        NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
        textField.text=trimmed;
        if ([trimmed length] == 0) {
            return NO;
        }

    }
    return YES;
}
-(NSString *)checkMandetoryField{
    
    if (![self isTextFieldIsEmpty:dishNameComboBox.textField_]) {
        return @"Please fill Dish Name";
    }
    
    /**
     @amit: ##change UIModificatin with veg and non Veg
     Action:Comment of code
     ****/
//    else if(dgOptionSet.selectedOptoin!=2 && (![self isTextFieldIsEmpty:self.cuisine.textField_])){
//        return @"Please fill Cuisine Name";
//    }
    
    
    else if(dgRatingView.currentRating==0){
        return @"Please Enter some rating";
    }
    
    
    /**
     @amit: ##change UIModificatin with veg and non Veg
     Action:Comment of code

    else if(dgOptionSet.selectedOptoin==1){
        Cuisine*cuisines= [self getSelected];
        if (cuisines==nil) {
        return @"Please select cuisine from cuisine list";
        }
    }
          ****/
    
    return nil;
}
- (void)completeInfo{

    self.dishDraft.userDishDescription=[Utilities trimmedSting:self.nameOfTextField.text];

    DishType *dt=[[DishType alloc] init];
    
    self.dishDraft.cuisine=[self getSelected];

    if (dgOptionSet.selectedOptoin==1) {
        self.dishDraft.dishType=[NSString stringWithFormat:@"%d", dgToggelViewFood.selectedToggel];
        dt.uid=[NSNumber numberWithInt:dgToggelViewFood.selectedToggel];
        
    }else if(dgOptionSet.selectedOptoin==2){
        self.dishDraft.dishType=[NSString stringWithFormat:@"%d", dgToggelViewBeverage.selectedToggel+2];
        dt.uid=[NSNumber numberWithInt:(dgToggelViewBeverage.selectedToggel+2)];
    }

    if (((self.dishDraft.dish==nil)&&(dishNameComboBox.textField_.text!=nil ||![dishNameComboBox.textField_.text isEqualToString:@""]))||(![dishNameComboBox.textField_.text isEqualToString:self.dishDraft.dish.dishName])) {
            self.dishDraft.dish=nil;
            Dish *dish=[[Dish alloc] init];
            dish.dishName=dishNameComboBox.textField_.text;
            dish.defaultDescription=self.nameOfTextField.text;
            dish.uid= [NSNumber numberWithInt:-1];
        
            dish.dishType=dt;
            self.dishDraft.dish=dish;

    }
    if (((self.dishDraft.cuisine==nil)&&(self.cuisine.textField_.text!=nil ||![self.cuisine.textField_.text isEqualToString:@""]))||(![self.cuisine.textField_.text isEqualToString:self.dishDraft.cuisine.cuisineName])) {
        self.dishDraft.cuisine=nil;
        Cuisine *cusine=[[Cuisine alloc] init];
        cusine.cuisineName=self.cuisine.textField_.text;
        cusine.uid= [NSNumber numberWithInt:-1];
        self.dishDraft.cuisine=cusine;
    }
}
#pragma mark- push of ViewPost
-(void)showViewPostScreen:(NSString *)postId{
    AppDelegate *delgate=(AppDelegate *)[UIApplication sharedApplication].delegate;
    [delgate.dgHomeController changeTabSelected:4 subSectionInTab:1];
    
    
    ViewPostController *viewPostController = [[ViewPostController alloc] initWithNibName:@"ViewPostController" bundle:nil uid:postId focusOnAddComment:NO];
    viewPostController.isLoadingFromProfile = YES;
    
    DisgramTabBarControllerViewController *tabBarController = (DisgramTabBarControllerViewController*)delgate.window.rootViewController;
    UINavigationController *NC = (UINavigationController*)tabBarController.selectedViewController;
    [NC popToRootViewControllerAnimated:NO];
    [PageUtil push:viewPostController];

}
#pragma mark-
-(void)postActionForPostingDish{
    
    @autoreleasepool {
        // Validate Email
        if (![socialNetork validateEmailField]) {
            return;
        }
        
        NSString *st=[self checkMandetoryField];
        if (st!=nil) {
            [[[iToast makeText:st] setGravity:iToastGravityCenter] show];
            return;
        }
        [self completeInfo];
        if (self.dishDraft.dish!=nil) {
            
            [socialNetork postOnSocialNetwor:nil image:self.dishDraft.image];
            DishDetailAddViewController * __weak blocksafeSelf = self;


            [[DGImageUploadSingeloton singelton] postNewDishDetail:self.dishDraft callback:^(NSString * postid){
                            DishDetailAddViewController *strongSelf = blocksafeSelf;
                [strongSelf showViewPostScreen:postid];
               // [strongSelf cleanDropDown];
                
                
            }];
            
        }else{
            DishDetailAddViewController * __weak blocksafeSelf = self;
            [[DGImageUploadSingeloton singelton] postNewDishDetail:self.dishDraft callback:^(NSString * postid){
                DishDetailAddViewController *strongSelf = blocksafeSelf;
                [strongSelf showViewPostScreen:postid];
                //[strongSelf cleanDropDown];
            }];
            
        }
        
    }
//    self.dishDraft.delegate=nil;
//    self.dishDraft=nil;
}

- (void)postDraft {
    
    NSString *message = [self checkMandetoryField];
    if (message) {
        [[[iToast makeText:message] setGravity:iToastGravityCenter] show];
        return;
    }

    if (!self.dishDraft.draft.dishImageThumbnail.dishURL) {
        [[[iToast makeText:@"Please upload a dish image."] setGravity:iToastGravityCenter] show];
        return;
    }
    DishDetailAddViewController * __weak blocksafeSelf = self;
    AppDelegate *appDelegate=(AppDelegate *)[UIApplication sharedApplication].delegate;
    __weak typeof(appDelegate) weakappDelegate = appDelegate;
    [self.dishDraft uploadDraftPost:^(id response) {
            DishDetailAddViewController *strongSelf = blocksafeSelf;
        if (response) {
           NSString * message = @"Draft posted successfully";
            [strongSelf showViewPostScreen:response];
                    [[[iToast makeText:message] setGravity:iToastGravityCenter] show];
        }
        else {
            NSString *message = @"Unable to post draft";
            [weakappDelegate.dgHomeController changeTabSelected:4 subSectionInTab:0];
                    [[[iToast makeText:message] setGravity:iToastGravityCenter] show];

        }

        //[strongSelf cleanDropDown];
    }];
    
}

-(void)barButtonAction:(id)sender{
    [PageUtil removeDropDown];
    UIButton *barItem=(UIButton *)sender;
    if (barItem.tag==2001) {
        [dishNameComboBox removeDropDownView];
        [PageUtil removeDropDown];
        [[DGImageUploadSingeloton singelton] discardDraft:self.dishDraft target:self];
    }else if(barItem.tag==2002){
        if (self.dishDraft.dishMode == dishModePost) {
            [self postActionForPostingDish];
        }
        else if (self.dishDraft.dishMode == dishModeDraft) {
            [self completeInfo];
            [self postDraft];
        }
    }
}

#pragma mark -
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==0) {
        [self.dishDraft discardDraft];
        AppDelegate *delgate=(AppDelegate *)[UIApplication sharedApplication].delegate;
               // [self cleanDropDown];
                        [delgate.dgHomeController changeTabSelected:4 subSectionInTab:4];
    }else if(buttonIndex==1){
                   [self completeInfo];
        AppDelegate *appDelegate=(AppDelegate *)[UIApplication sharedApplication].delegate;
        __weak typeof(appDelegate) weakappDelegate = appDelegate;


//        DishDetailAddViewController * __weak blocksafeSelf = self;
        [self.dishDraft uploadDraftJsonWithCallback:^(id response) {
//            DishDetailAddViewController *strongSelf = blocksafeSelf;
            //[strongSelf cleanDropDown];
            [weakappDelegate.dgHomeController changeTabSelected:4 subSectionInTab:4];
            if (response)
                NSLog(@"%@",response);
            else
                DLog(@"Unable to save draft to server");
           
        }];
        // [[DGImageUploadSingeloton singelton] saveAsDraft:self.dishDraft];
    }

}


-(void)callSettings{
    
    SettingController *settingVC = [[SettingController alloc] initWithNibName:@"SettingController" bundle:nil];
    [PageUtil push:settingVC];
}

#pragma mark- Pick Dish Image Clicked
- (IBAction)pickDishImageClicked:(id)sender {
    [self.view endEditing:YES];
    NSString *camera = @"Camera";
    NSString *gallery = @"Gallery";
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"Cancel"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:camera, gallery, nil];
    actionSheet.actionSheetStyle=UIActionSheetStyleDefault;
   // [actionSheet showInView:[self.view window]];
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    [actionSheet showFromTabBar:appDelegate.dgHomeController.dgTabsController.tabBar];
//    [actionSheet showFromTabBar:self.view];
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    UIImagePickerController *imagePicker =[[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    switch (buttonIndex) {
        case 0:
            NSLog(@"Camera Clicked");
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                [imagePicker setSourceType:UIImagePickerControllerSourceTypeCamera];
                [appDelegate.dgHomeController.dgTabsController.selectedViewController presentViewController:imagePicker animated:YES completion:nil];
            }else{
                [[[iToast makeText:NSLocalizedString( @"Camera not supported", @"")]
                  setGravity:iToastGravityBottom] show];
            }
            break;
        case 1:
            NSLog(@"Gallery Clicked");
            [imagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            [appDelegate.dgHomeController.dgTabsController.selectedViewController presentViewController:imagePicker animated:YES completion:nil];
            break;
    }
}

#pragma mark- UIImagePickerController Delegate
//select a picture and
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    [picker dismissModalViewControllerAnimated:TRUE];
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [PageUtil showImageCropView:image heightRatio:1.0 minHeight:500 maxHeight:1024 delegate:self];
}
-(void)cancelled {
    // TODO.. do some thing..
}

-(void)croppedImage:(UIImage *)image {
    
    
    [self completeInfo];
    
    self.dishDraft.image=image;

    if (self.dishDraft.draft.uid!=nil) {
        
        [PageUtil uploadDishImageForDraft:self.dishDraft];
        
        DishDetailAddViewController *dishDetail=[[DishDetailAddViewController alloc] initWithNibName:@"DishDetailAddViewController" bundle:nil];
        dishDetail.dishDraft = self.dishDraft;
        [PageUtil push:dishDetail];
    }
    
    
    /**
     @amit: ##change UIModificatin to remove filter view controller
     Action: removed controller removed business logic
     ****/
    /**
    PostDishViewController *postDishVC =[[PostDishViewController alloc] initWithDishDraft:self.dishDraft];
    [postDishVC setImageForFilter:image basicInfo:nil];
    [PageUtil push:postDishVC];
    
    **///
}

- (void)showDishDetailForDraft {

}
-(void)cleanDropDown{
    self.cuisine.delegate=nil;
    [self.cuisine.textField_ resignFirstResponder];
    [self.cuisine removeFromSuperview];
    self.cuisine=nil;
    
    dishNameComboBox.delegate=nil;
    [dishNameComboBox.textField_ resignFirstResponder];
    [dishNameComboBox removeFromSuperview];
    dishNameComboBox=nil;
}
-(void)dealloc{
    @try {
        [self.nameOfTextField resignFirstResponder];
        [self cleanDropDown];
        [self cleanAllCusine];
        [dgRatingView removeFromSuperview];
        dgRatingView=nil;
        [dgToggelViewFood removeFromSuperview];
        dgToggelViewBeverage=nil;
        [dgToggelViewFood removeFromSuperview];
        dgToggelViewFood=nil;
        
        self.dishDraft.delegate=nil;
        self.dishDraft=nil;
        [socialNetork removeFromSuperview];
        socialNetork=nil;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

    DLog("DishDetailAddVC");
}


#pragma mark ---   --- 

-(void)scrollUpCall{
    CGPoint scrollPoint = CGPointMake(0, 316);
    [self.containerView setContentOffset:scrollPoint animated:YES];
}

@end
