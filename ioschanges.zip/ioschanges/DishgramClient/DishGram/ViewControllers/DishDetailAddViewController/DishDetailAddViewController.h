//
//  DishDetailAddViewController.h
//  DishGram
//
//  Created by SumanAmit on 04/06/13.
//
//

#import <UIKit/UIKit.h>
#import "CustomTextField.h"
#import "WebComboBoxView.h"
#import "ShareSocialNetworkView.h"
#import "ImageCropView.h"
@class DGRatingView;
@class DGToggel;
@class DGOptionSet;
@class DishDraft;
@class DGDropDown;
@class ComboboxView;

 
@interface DishDetailAddViewController : UIViewController<UITextFieldDelegate,ComboBoxViewDelegate,ShareSocialDelegate, UIActionSheetDelegate, UIImagePickerControllerDelegate,CropDelegate>{
    
    ShareSocialNetworkView *socialNetork;
    DGRatingView *dgRatingView;
    DGToggel *dgToggelViewFood,*dgToggelViewBeverage;
    DGOptionSet *dgOptionSet;

    WebComboBoxView *dishNameComboBox;
     
}

@property (weak, nonatomic)   IBOutlet UIButton *pickDishImageButton;
@property (weak, nonatomic) IBOutlet UIView *normalBackView;

@property (weak, nonatomic) IBOutlet UIImageView *imageBackgroundImage;
@property (weak, nonatomic) IBOutlet UIImageView *dishImageView;
//@property (strong, nonatomic) IBOutlet UITextField *dishNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *nameOfTextField;
@property (weak, nonatomic) IBOutlet UIScrollView *containerView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (strong, nonatomic) DishDraft *dishDraft;

@property (strong, nonatomic)     ComboboxView *cuisine;
- (IBAction)pickDishImageClicked:(id)sender;
-(void)postActionForPostingDish;

@end
