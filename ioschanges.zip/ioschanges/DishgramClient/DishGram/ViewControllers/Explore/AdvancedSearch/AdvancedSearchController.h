//
//  AdvancedSearchController.h
//  DishGram
//
//  Created by Ramesh Varma on 25/06/13.
//
//

#import <UIKit/UIKit.h>
#import "MapDataProvider.h"
#import "PullRefreshTableViewController.h"
#import "NVPagedDataView.h"
#import "NVPullToRefreshPagedDataViewController.h"

@interface AdvancedSearchController : NVPullToRefreshPagedDataViewController<MapDataProvider>

- (id)init:(NSString *)dishName dishType:(NSString *)dishType cuisine:(NSString *)cuisine;

@end
