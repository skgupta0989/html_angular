//
//  CustomTableCellForFollowFriendsCell.h
//  DishGram
//
//  Created by Rags on 02/05/13.
//
//

#import <UIKit/UIKit.h>
#import "FriendsUserInformation.h"
#import "AppDelegate.h"

#define SHOWING_FOLLOW  0
#define SHOWING_UNFOLLOW  1

@protocol FollowUsersDelegate <NSObject>

- (void)addRemoveUserInFollowArray:(FriendsUserInformation*)frndUserInfo;
- (void)removeUserInFollowArray:(FriendsUserInformation*)frndUserInfo;


@end


@interface CustomTableCellForFollowFriendsCell : UITableViewCell{
   // id <FollowUsersButtonActions>delegate;
    
    int cellHeight;
    int followBtnState;
    FriendsUserInformation *cellFrndsUserInfo;
    int localFollowersCount;
    AppDelegate *appDelegate;

}

@property (nonatomic, strong) UIImageView *friendProfileImage;
@property (nonatomic, strong) UILabel   *friendName;
@property (nonatomic, strong) UILabel   *friendsPost;
@property (nonatomic, strong) UILabel   *friendsFollowers;
@property (nonatomic, strong) UIButton  *followbtn;
@property (nonatomic, strong) UILabel   *lineLabel;
@property (nonatomic, weak) id <FollowUsersDelegate>cellDelegate;

- (UILabel *)prepareLabelWithFontSize:(CGFloat)fontSize andFrame:(CGRect)frame;

-(void)loadCellData:(FriendsUserInformation*)frndsUserInfo;

@end
