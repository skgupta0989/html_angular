//
//  CustomBtnAndLabel.h
//  DishGram
//
//  Created by Rags on 26/04/13.
//
//

#import <UIKit/UIKit.h>

@protocol buttonClickDelegateForLandingPage <NSObject>

- (void)landingPageBtnsClicked :(id)sender;

@end

@interface CustomBtnAndLabel : UIView{
}
@property (weak, nonatomic) id delegate;
@property (strong, nonatomic) IBOutlet UIButton *buttons;


@end
