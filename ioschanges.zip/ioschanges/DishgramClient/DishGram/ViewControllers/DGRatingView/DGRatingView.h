//
//  DGRatingView.h
//  TabPOC
//
//  Created by SumanAmit on 03/06/13.
//  Copyright (c) 2013 NEEV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DGRatingView : UIView{
    int minimumRate,maximumRate;
    BOOL isTouchOnButtons;
    
}
@property (weak, nonatomic) IBOutlet UIButton *btn5;
@property (weak, nonatomic) IBOutlet UIButton *btn4;
@property (weak, nonatomic) IBOutlet UIButton *btn3;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn1;

@property (weak, nonatomic) IBOutlet UIView *containerViewOfRating;
@property (weak,nonatomic) id target;
@property (assign,nonatomic)SEL callBackMethod;
@property (weak, nonatomic) IBOutlet UILabel *nameOfLabel;
@property (nonatomic,assign) NSInteger currentRating;
- (IBAction)markRating:(id)sender;
- (IBAction)markRatingOnOutsideClick:(id)sender;
- (void)loadRating:(NSInteger)numberOfRates;
- (void)addTarget:(id)rootTarget rootAction:(SEL)action;
@end
