//
//  DGRatingView.m
//  TabPOC
//
//  Created by SumanAmit on 03/06/13.
//  Copyright (c) 2013 NEEV. All rights reserved.
//

#import "DGRatingView.h"
#import "AppDelegate.h"
#define  MAXRATING 1004
#define MINRATING 1000

@implementation DGRatingView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"DGRatingView" owner:self options:nil];
        UIView *buttonAndLabelView = [array objectAtIndex:0];
        [self addSubview:buttonAndLabelView];
        isTouchOnButtons=NO;
    }
    return self;
}
-(id)init{
    self = [super init];
    if (self) {
        // Initialization code
        
    }
    return self;
    
}

- (void) makeRatingUnSelectedFrom:(UIButton *)btn{
    @try {
        int counter=btn.tag+1;
        for (;counter<=MAXRATING;counter++) {
            UIButton *btn=(UIButton*)[self viewWithTag:counter];
            [btn setImage:[UIImage imageNamed:@"star_off.png"] forState:UIControlStateNormal];
        }

    }
    @catch (NSException *exception) {

    }
    @finally {

    }
}
-(void)makeRatingOfButton:(UIButton *)btn{
    @try {
       // UIButton *btn=(UIButton *)sender;
        [self makeRatingUnSelectedFrom:btn];
        
        int i=1000;
        int max=btn.tag;
        _currentRating=(max%1000)+1;
        for (; i<=max;i++ ) {
            UIButton *tbtn=(UIButton*)[self viewWithTag:i];
            [tbtn setImage:[UIImage imageNamed:@"star_on.png"] forState:UIControlStateNormal];
        }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [_target performSelector:_callBackMethod withObject:self];
#pragma clang diagnostic pop
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
- (IBAction)markRatingOnOutsideClick:(id)sender{
    UIButton *btn=(UIButton *)sender;
    [self makeRatingOfButton:btn];
}
-(IBAction)markRating:(id)sender{
    if (sender==nil) {
        UIButton *btn=(UIButton *)sender;
        [self makeRatingOfButton:btn];
        _currentRating=0;
    }else{
        UIButton *btn=(UIButton *)sender;
        [self makeRatingOfButton:btn];
        
    }
}
- (void)loadRating:(NSInteger)numberOfRates{
    _currentRating=numberOfRates;

    UIButton *btn=(UIButton*)[self viewWithTag:(1000+(numberOfRates-1))];

    [self markRating:btn];
}
- (void)addTarget:(id)rootTarget rootAction:(SEL)action{
    _target=rootTarget;
    _callBackMethod=action;
}


#pragma mark - fingure movement action

-(BOOL)isRatingViewAction:(NSArray *)array{
    for (UIView *view in array) {
//        NSLog(@"%@",view);
        if (view==self.containerViewOfRating) {
            return YES;
        }
    }
    return NO;
}
-(UIButton *)getIntersectButton:(CGPoint)current{
    NSArray *arrOfSubViews=[self.containerViewOfRating subviews];
    
    for (UIView *view in arrOfSubViews) {

        if ([view class]==[UIButton class]) {
            AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
            CGRect rect=[view bounds];
            CGRect mainViewRect = [view convertRect:rect fromView:appDelegate.window];

            mainViewRect=CGRectMake(-mainViewRect.origin.x, (-mainViewRect.origin.y)+mainViewRect.size.height, mainViewRect.size.width, mainViewRect.size.height);
            current=CGPointMake(current.x, mainViewRect.origin.y);
            BOOL contains = CGRectContainsPoint(mainViewRect, current);
            if (contains) {
                return (UIButton *)view;
            }
        }
    }
    return nil;
    
}
-(void)frameOfButtons:(CGPoint )currentTouchPoint{
    

    UIButton *btn=    [self getIntersectButton:currentTouchPoint];
    if (btn!=nil) {
            [self markRating:btn];
    }
}
-(void)touchSets:(UIEvent *)event{
    @try {
        NSSet *allTouch = [event allTouches];
        UITouch *touch = [[allTouch allObjects]objectAtIndex:0];
        AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
        
        CGPoint locInWin=[touch locationInView:appDelegate.window];
        [self frameOfButtons:locInWin];

    }
    @catch (NSException *exception) {

    }
    @finally {

    }

}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    isTouchOnButtons=YES;
    [self touchSets:event];
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    if (isTouchOnButtons) {
    }
    [self touchSets:event];
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    isTouchOnButtons=NO;
    [self touchSets:event];
}

#pragma mark -
- (void)dealloc{
    DLog();
}

@end
