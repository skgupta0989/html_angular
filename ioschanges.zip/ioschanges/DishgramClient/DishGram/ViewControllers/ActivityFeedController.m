//
//  ActivityFeedController.m
//  DishGram
//
//  Created by Ramesh Varma on 27/05/13.
//
//

#import "ActivityFeedController.h"
#import "DishInfo.h"
#import "DishPlaces.h"
#import "Dish.h"
#import "User.h"
#import "UserProfile.h"
#import "PageUtil.h"
#import "Place.h"
#import "DataSourceFactory.h"
#import "DataSourceInterface.h"
#import "DataSingleton.h"
#import "FontUtil.h"
#import "ViewPostController.h"
#import "AppDelegate.h"
#import "ProfileController.h"
#import "ActivityFeedTemplateProvider.h"

// gap between TEXT and icon within an item in footer
#define AFC_FOOTER_TEXT_ICON_GAP 5

// gap between to different items in the footer
#define AFC_FOOTER_ICON_TEXT_GAP 10

@implementation ActivityFeedController


int __tileTitleHeight = 55;
int __tileBottomHeight = 119;

// to init
int __dishImageHeight = 0;
int __dishImageWidth = 0;
int __profileFrameY = 0;

int __profileFrameX = 10;
int __dishImageMargin = 20;

CGRect descriptionOriginalFrame;

-(id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        if (__dishImageHeight == 0) {
            __dishImageHeight = __tileHeight - __tileTitleHeight - __tileBottomHeight;
            __dishImageWidth = __tileWidth - 2*__dishImageMargin;
            __profileFrameY = __tileTitleHeight - DEFAULT_PROFILE_IMAGE_HEIGHT + 20;
        }
        
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        [PageUtil loadDecoratedView:self nibName:@"ActivityFeedController"];
        
        // add gesture on dish label
        UITapGestureRecognizer *dishLabelTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dishTapped)];
        [self.dishLabel addGestureRecognizer:dishLabelTapGesture];
        
        descriptionOriginalFrame = self.description.frame;
    }
    return self;
    
}

// This method must be called by TemplateProvider when row data is available
-(void)populateData:(DishInfo *)data {
    self.description.frame = descriptionOriginalFrame;
    @autoreleasepool {
        
        self.data = data;
        [self addListener];
        // set label
        self.dishLabel.text = data.dishPlaces.dish.dishName;
        
        // set sub label
        NSString *days = [PageUtil dateToDays:data.dishPlaces.dateCreated];
        
        self.dishLabelSubtext.text = [NSString stringWithFormat:@"By %@ Spotted %@", data.dishPlaces.user.username, days];
        
        // set rating image
        self.starImageView.image = [PageUtil starRatingImage:data.dishPlaces.rating.floatValue];
        
        // set place
        self.place.text = data.dishPlaces.place.name;
        
        // set location
        if (data.dishPlaces.place.address2 != nil && ![data.dishPlaces.place.address2 isEqualToString:@""]) {
            self.location.text = [NSString stringWithFormat:@"%@\n%@", data.dishPlaces.place.address1, data.dishPlaces.place.address2];
        } else {
            self.location.text = data.dishPlaces.place.address1;
        }
        
        DLog(@"%@", data.dishPlaces.dishPlaceDescription);
        self.description.text = data.dishPlaces.dishPlaceDescription;
        [self.description sizeToFit];
        
        [self refreshDist];
        
        self.loveButton.selected = data.isLoved;
        
        // set footer labels
        {
            // set label values
            self.loves.text = data.dishPlaces.dishLovesCount.stringValue;
            self.comments.text = data.dishPlaces.dishCommentsCount.stringValue;
            self.numberOfViews.text = data.dishPlaces.viewCount.stringValue;
            
            // compress label width to fit the text
            [self.numberOfViews sizeToFit];
            [self.loves sizeToFit];
            [self.comments sizeToFit];
            
            // right adjust all footer labels on the right side.
            [PageUtil place:self.numberOfViews infrontOf:self.viewsIcon withMarging:AFC_FOOTER_TEXT_ICON_GAP];
            [PageUtil place:self.commentsIcon infrontOf:self.numberOfViews withMarging:AFC_FOOTER_ICON_TEXT_GAP];
            [PageUtil place:self.comments infrontOf:self.commentsIcon withMarging:AFC_FOOTER_TEXT_ICON_GAP];
            [PageUtil place:self.lovesIcon infrontOf:self.comments withMarging:AFC_FOOTER_ICON_TEXT_GAP];
            [PageUtil place:self.loves infrontOf:self.lovesIcon withMarging:AFC_FOOTER_TEXT_ICON_GAP];
        }
        [self handleImages:data];
    }
}

// handles profile and dish images
-(void)handleImages:(DishInfo *)data {
    // dish image
    dishView = [PageUtil defaultScalableBorderImage:__dishImageWidth height:__dishImageHeight];
    dishView.frame = CGRectMake(__dishImageMargin - self.frame.origin.x, __tileTitleHeight, __dishImageWidth, __dishImageHeight);
    dishView.tag = TAG_DISH_IMAGE_VIEW;
    dishView.userInteractionEnabled = YES;
    [self addSubview:dishView];
    
    // profile image
    profileView = [PageUtil profileImageViewWithX:__profileFrameX - self.frame.origin.x Y:__profileFrameY];
    profileView.tag = TAG_PROFILE_IMAGE_VIEW;
    profileView.userInteractionEnabled = YES;
    [self addSubview:profileView];
    
    NSString *dishUrl = data.dishPlaces.dishCoverImage;
    NSString *profileUrl = data.dishPlaces.user.userProfileImage;
    
    [self addRemoveOption];
    
    if (dishUrl) {
        // dish image
        [PageUtil fetchDishImage:dishView url:dishUrl notify:^(bool result) {
            [dishView bringSubviewToFront:[self viewWithTag:TAG_REMOVE_IMAGE]];
        } fitType:FitTypeAspectVClip];
    }
    
    if (profileUrl) {
        // profile image
        [PageUtil fetchPofileImage:profileView url:profileUrl notify:nil];
    }
    
    // DishImage
    UITapGestureRecognizer *dishTapGesture =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(dishTapped)];
    [dishView addGestureRecognizer:dishTapGesture];
    
    // Profile
    UITapGestureRecognizer *profileTapGesture =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(profileViewTapped)];
    [profileView addGestureRecognizer:profileTapGesture];
    
    
}

// called when user clicks on love button. If it is already loved by the user, an unlove request is set to the server. Otherwise a request is sent to server to mark this post as loved by current logged in user. if the request fails for some reason, then the butten is reverted back to its original state
- (IBAction)loveClicked:(id)sender {
    if (self.loveButton.selected) {
        /*
        // show a message that already loved
        [[[iToast makeText:[DataSingleton stringValueForKey:@"note_alreadyLoved"]]
          setGravity:iToastGravityTop] show];
        */
        
        // change button status
        self.loveButton.selected = NO;
        
        // increase loves count
        self.data.isLoved = NO;
        _data.dishPlaces.dishLovesCount = [NSNumber numberWithInt:(_data.dishPlaces.dishLovesCount.intValue - 1)];
        self.loves.text = _data.dishPlaces.dishLovesCount.stringValue;
        
        // send request to server
        [[DataSourceFactory getDataSourceInstance] requestDataWithURLString:LOVE_DISH_POST_URL params:[ActivityFeedController getReqForDish:self.data love:NO] modelClass:nil callBack:^(bool success, NSObject *response) {
            
            // request failed. so revert the button status and reduce the loves count
            if (!success) {
                [[iToast makeText:(NSString *)response] show];
                _data.dishPlaces.dishLovesCount = [NSNumber numberWithInt:(_data.dishPlaces.dishLovesCount.intValue + 1)];
                self.loves.text = _data.dishPlaces.dishLovesCount.stringValue;
                self.loveButton.selected = YES;
                
            }
        }];
    } else {
        // change button status
        self.loveButton.selected = true;
        
        // increase loves count
        self.data.isLoved = true;
        _data.dishPlaces.dishLovesCount = [NSNumber numberWithInt:(_data.dishPlaces.dishLovesCount.intValue + 1)];
        self.loves.text = _data.dishPlaces.dishLovesCount.stringValue;
        
        // send request to server
        [[DataSourceFactory getDataSourceInstance] requestDataWithURLString:LOVE_DISH_POST_URL params:[ActivityFeedController getReqForDish:self.data love:YES] modelClass:nil callBack:^(bool success, NSObject *response) {
            
            // resuest faild so revert the button status and also reduce the loves count
            if (!success) {
                [[iToast makeText:(NSString *)response] show];
                _data.dishPlaces.dishLovesCount = [NSNumber numberWithInt:(_data.dishPlaces.dishLovesCount.intValue - 1)];
                self.loves.text = _data.dishPlaces.dishLovesCount.stringValue;
                self.loveButton.selected = false;
                
            }
        }];
    }
}

// creates and returns resuts object with dishPlaceId prepopulated
+(NSMutableDictionary *)getReqForDish:(DishInfo *)data love:(BOOL)love{
    NSString *dishId = data.dishPlaces.uid.stringValue;
    NSMutableDictionary *req = [[NSMutableDictionary alloc] init];
    [req setObject:dishId forKey:@"dishPlaceId"];
    [req setObject:love?@"true":@"false" forKey:@"loveStatus"];
    return req;
}

// called when user clicks on comment button
- (IBAction)commentButton:(id)sender {
    [self launchDishInfoScreen:YES];
}

// launches View Post screen. if focusOnAddComment is set to true, then by default comment field is focused
-(void)launchDishInfoScreen:(BOOL)focusOnAddComment {
    NSString *dishId = self.data.dishPlaces.uid.stringValue;
    
    ViewPostController *viewPostController = [[ViewPostController alloc] initWithNibName:@"ViewPostController" bundle:nil uid:dishId focusOnAddComment:focusOnAddComment];
    [PageUtil push:viewPostController];
    
}

#pragma - Tap Gesture Actions

// called when user taps on dish image or dish label
-(void)dishTapped{
    [self launchDishInfoScreen:NO];
}

// callled when user taps profile image
-(void)profileViewTapped {
    ProfileController *profileController =
    [[ProfileController alloc] initWithNibName:@"ProfileController"
                                        bundle:nil uid:self.data.dishPlaces.user.uid];
    [PageUtil push:profileController];
}

// added location update listener
-(void)addListener {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateLocation)
                                                 name:DG_LOC_UPDATED
                                               object:nil];
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// when ever lat/long changes this method is called for recalculation the distance
-(void)updateLocation {
    [self refreshDist];
}


-(void)refreshDist {
    // distance always calculated from current device location
    self.distance.text =
    [PageUtil distanceFromCurDeviceLock:[[PlaceCoords alloc]
                                         init:self.data.dishPlaces.place.latitude.doubleValue
                                         longitude:self.data.dishPlaces.place.longitude.doubleValue
                                         address:@""]];
}

#pragma mark - remove post
-(void)addRemoveOption {
    [self performSelectorOnMainThread:@selector(addRemoveOptionDo) withObject:nil waitUntilDone:YES];
}

-(void)addRemoveOptionDo {
    if(self.data.dishPlaces.user.uid.longValue == ((NSNumber *)[Utilities getFromUserDefault:USERID]).longValue) {
        UIImage *flag = [UIImage imageNamed:@"delete_post"];
        removePostView_ = [[UIImageView alloc] initWithFrame:CGRectMake(dishView.frame.size.width - flag.size.width - 4, 4, flag.size.width,flag.size.height)];
        removePostView_.tag = TAG_REMOVE_IMAGE;
        
        removePostView_.image = flag;
        [dishView addSubview:removePostView_];
        // [[PageUtil getWindow] addSubview:flagView_];
        
        // add gesture recognizer
        removePostView_.userInteractionEnabled = YES;
        dishView.userInteractionEnabled = YES;
        
        UITapGestureRecognizer *profileTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(removePostTapped)];
        profileTapGesture.numberOfTapsRequired = 1;
        [removePostView_ addGestureRecognizer:profileTapGesture];
    }
}

-(void)removePostTapped {
    [PageUtil showRemovePostAlertViewWithDelegate:self];
}


#pragma mork - RemovePostPromptDelegate
-(void)proceedClicked {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"AF_REMOVE" object:self.data];
    [[NSNotificationCenter defaultCenter] postNotificationName:[PageUtil removePostEventName:self.data.dishPlaces.uid.stringValue] object:self.data];

}

-(void)cancelClicked {
    // do nothing
}


@end
