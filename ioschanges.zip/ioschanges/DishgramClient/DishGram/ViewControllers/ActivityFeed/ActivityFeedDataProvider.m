//
//  ActivityFeedDataProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import "ActivityFeedDataProvider.h"
#import "DishInfo.h"
#import "Header.h"
#import "DataSingleton.h"

@implementation ActivityFeedDataProvider

-(id)init {
    self = [super init:GET_DISH_LIST_URL respType:[DishInfo class] removeUrl:REMOVE_POST_URL];
    return self;
}


// override the super class method if custom parameters need to be added to the webservice request.
//-(NSMutableDictionary *)getRequest {
//    NSMutableDictionary *request = [super getRequest];
//    return request;
//}

-(void)onError:(NSString *)message {
    if ([message isEqualToString:[DataSingleton stringValueForKey:@"error_network_connection"]]) {
        [self noResultsFoundWithImage:@"notfound_no_internet"];
    }else {
        [[[iToast makeText:message] setGravity:iToastGravityTop] show];
        
    }
    
}
-(void)noResultsFound{
    [self noResultsFoundWithImage:@"notfound_first_time_users"];
}

-(NSMutableDictionary *)getRemoveRequest:(NSObject *)data {
    NSMutableDictionary *req = [[NSMutableDictionary alloc] init];
    [req setObject:((DishInfo *)data).dishPlaces.uid forKey:@"dishPlacesId"];
    return req;
}

@end
