//
//  ActivityFeedViewController.h
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import <UIKit/UIKit.h>
#import "PullRefreshTableViewController.h"
#import "NVPagedDataView.h"
#import "NVPullToRefreshPagedDataViewController.h"

@interface ActivityFeedViewController : NVPullToRefreshPagedDataViewController {
    BOOL firstTime_;
}

@end
