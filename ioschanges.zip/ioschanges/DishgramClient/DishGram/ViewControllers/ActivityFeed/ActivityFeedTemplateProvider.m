//
//  ActivityFeedTemplateProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import "ActivityFeedTemplateProvider.h"
#import "ActivityFeedDataProvider.h"
#import "NVImageProvider.h"
#import "CacheFactory.h"
#import <QuartzCore/QuartzCore.h>
#import "PageUtil.h"
#import "DishInfo.h"
#import "DishPlaces.h"
#import "ActivityFeedController.h"
#import "User.h"
#import "UserProfile.h"
#import "ReusableUIView.h"



@implementation ActivityFeedTemplateProvider


NSString *strLock = @"aftpLock";

-(id)init {
    self = [super init];
    if(self) {
        self.numRows = 0;
        [self reloadDataProvider];        
    }
    return self;
}

-(void)reloadDataProvider {
    [self handleRowDataProviders];
}

-(void)handleRowDataProviders {
    @autoreleasepool {
        MutableRowDataProvider *rdp = [self createRowDataProvider];
        [self markOldDataProvidersStale];
        if (_rowDataProvider == nil) {
            _rowDataProvider = rdp;
        } else {
            _nRowDataProvider = rdp;
            ((MutableDefaultDataProvider *)rdp.pagedDataProviderInst).pagedDataView = ((MutableDefaultDataProvider *)_rowDataProvider.pagedDataProviderInst).pagedDataView;
        }
        [self setSizeChangedCallBack];
    }
}

-(MutableRowDataProvider *)createRowDataProvider {
    MutableRowDataProvider *rdp = [[MutableRowDataProvider alloc] initWithPageSize:20 numberOfPagesToCache:10 pagedDataProvider:[[ActivityFeedDataProvider alloc] init] nextPageTrigger:20];
    return rdp;
}

-(void)trigger {
    // [self getTemplateTrigger:0];
    [self getTemplateDo:0 reuseView:nil isTrigger:YES];
}


-(UIView *)getTemplate:(int)index {
    return [self getTemplateDo:index reuseView:nil];
}

-(UIView *)getTemplate:(int)index reuseView:(UIView *)reuseView {
    return [self getTemplateDo:index reuseView:(ReusableUIView *)reuseView];
}

-(UIView *)getTemplateDo:(int)index reuseView:(ReusableUIView *)reuseView {
    return [self getTemplateDo:index reuseView:reuseView isTrigger:NO];
}

-(UIView *)getTemplateDo:(int)index reuseView:(ReusableUIView *)reuseView isTrigger:(BOOL)isTrigger {
    @synchronized(strLock) {
        
        @autoreleasepool {
            // tile background
            
            if (reuseView.updateInProgress) {
                reuseView = nil;
            }
            ReusableUIView *view = nil;
            if (!reuseView) {
                view = [[ReusableUIView alloc] initWithFrame:CGRectMake(0, 0, __tileWidth, __tileHeight)];
                view.backgroundColor = [UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1];
                [view addSubview:[PageUtil defaultScalableTile:__tileWidth height:__tileHeight]];
            } else {
                view = reuseView;
                [self cleanupCellView:view];
            }
            
            view.reservedForIndex = index;
            
            void (^callBack)(NSObject *data) = [self getCallBackMethod:view forIndex:index];
            
            if (isTrigger && _nRowDataProvider != nil) {
                [_nRowDataProvider getRow:index withCallBack:callBack];
            } else {
                [_rowDataProvider getRow:index withCallBack:callBack];
            }

            return view;
        }
    }
}

-(void)cleanupCellView:(ReusableUIView *)cellView {
    UIView *activityXib = [cellView viewWithTag:TAG_ACTIVITY_FEED_XIB_VIEW];
    if (cellView.updateInProgress) {
        [activityXib removeFromSuperview];
    } else {
        if (activityXib != nil) {
            [[activityXib viewWithTag:TAG_DISH_IMAGE_VIEW] removeFromSuperview];
            [[activityXib viewWithTag:TAG_PROFILE_IMAGE_VIEW] removeFromSuperview];
        }
    }
}



-(void (^)(NSObject *data)) getCallBackMethod:(ReusableUIView *)masterView forIndex:(int)index {
    ReusableUIView __weak *weakMasterView = masterView;

    void (^callBack)(NSObject *data) = ^(NSObject *data){
        if (data) {
            
            [self performSelectorOnMainThread:@selector(update:)
                                   withObject:^{
                                       
                                       @autoreleasepool {
                                           
                                           ReusableUIView *strongMaster = weakMasterView;
                                           
                                           if (strongMaster == nil || (index != strongMaster.reservedForIndex)) {
                                               return;
                                           }
                                           strongMaster.updateInProgress = YES;
                                           
                                           [PageUtil removeNoDataFoundImage:self.owner];
                                           ActivityFeedController *tileController = (ActivityFeedController *)[strongMaster viewWithTag:TAG_ACTIVITY_FEED_XIB_VIEW];
                                           // tileController = nil;
                                           if (tileController == nil) {
                                               tileController = [[ActivityFeedController alloc] initWithFrame:CGRectMake(20,10, __tileWidth - 40, __tileHeight - 20)];
                                               tileController.tag = TAG_ACTIVITY_FEED_XIB_VIEW;
                                               
                                               // UIView *view = tileController.view;
                                               [strongMaster addSubview:tileController];
                                           } else {
                                               [[tileController viewWithTag:TAG_DISH_IMAGE_VIEW] removeFromSuperview];
                                               [[tileController viewWithTag:TAG_PROFILE_IMAGE_VIEW] removeFromSuperview];
                                           }

                                           DishInfo *dishInfo = (DishInfo *)data;
                                           
                                           [tileController populateData:dishInfo];
                                           strongMaster.updateInProgress = NO;
                                           

                                           

                                       }
                                   } waitUntilDone:true];
        }
    };
    
    return callBack;
}

-(float)getCellHeight {
    return __tileHeight;
}

@end
