//
//  ActivityFeedViewController.m
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import "ActivityFeedViewController.h"
#import "NVPagedDataView.h"
#import "ActivityFeedTemplateProvider.h"
#import "MutableDefaultDataProvider.h"
#import "MutableRowDataProvider.h"

@implementation ActivityFeedViewController
- (id)init
{
    self = [super init];
    if (self) {
        firstTime_ = YES;
        CGRect frame = CGRectMake(0, 0, 180, 44);
        UILabel *nav_label = [[UILabel alloc] initWithFrame:frame];
        nav_label.backgroundColor = [UIColor clearColor];

        [nav_label setFont:[UIFont fontWithName:@"Roboto-Bold" size:18]];
        nav_label.shadowColor = [UIColor whiteColor];
        nav_label.shadowOffset  = CGSizeMake(0.5,0.5);
        nav_label.textAlignment = UITextAlignmentCenter;
        nav_label.textColor = [UIColor blackColor];
        nav_label.text = @"Activity Feed";
        [nav_label sizeToFit];
        self.navigationItem.titleView = nav_label;
        
    }
    
    return self;
}



-(void)viewWillAppear:(BOOL)animated {
    if (firstTime_) {
        [self loadData];
        firstTime_ = NO;
    } else {
        [self refreshDo];
    }
    
    // [self refreshDo];
    [super viewWillAppear:animated];
}

-(void)loadData {
    pagedDataView = [[NVPagedDataView alloc] initWithFrame:CGRectMake(0, 0, 300, 600)];
    pagedDataView.templateProvider = [[ActivityFeedTemplateProvider alloc] init];
    pagedDataView.templateProvider.owner = pagedDataView;
    
    
    if ([pagedDataView.templateProvider isKindOfClass:[DefaultTemplateProvider class]]) {
        DefaultTemplateProvider *tp = ((DefaultTemplateProvider *)pagedDataView.templateProvider);
        ((MutableDefaultDataProvider *)tp.rowDataProvider.pagedDataProviderInst).pagedDataView = pagedDataView;
    }
    
    pagedDataView.backgroundColor = [UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1];
    // trigger
    [pagedDataView.templateProvider trigger];
    self.tableView = pagedDataView;
    
    [self prepare];
    [self addObserverForDelete];
}

-(void)dealloc{
    DLog();
    [self removeObservers];
}


-(void)refreshDo {
    [(ActivityFeedTemplateProvider *)self.pagedDataView.templateProvider reloadDataProvider];
    // trigger
    [pagedDataView.templateProvider trigger];
}

#pragma mark - remove cell observer

-(void)addObserverForDelete {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(removeCell:) name:@"AF_REMOVE" object:nil];
}

-(void)removeObservers {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"AF_REMOVE" object:nil];
}

-(void)removeCell:(NSNotification *) notification {
    
    if ([pagedDataView.templateProvider isKindOfClass:[DefaultTemplateProvider class]]) {
        DefaultTemplateProvider *tp = ((DefaultTemplateProvider *)pagedDataView.templateProvider);
        [((MutableRowDataProvider *)tp.rowDataProvider)deleteRow:notification.object];
    }
    
//    DLog(@"%@", [pagedDataView indexPathForCell:notification.object]);
//    NSArray *indexs = [[NSArray alloc] initWithObjects:[pagedDataView indexPathForCell:notification.object], nil];
//    [pagedDataView deleteRowsAtIndexPaths:indexs withRowAnimation:UITableViewRowAnimationTop];
}


@end
