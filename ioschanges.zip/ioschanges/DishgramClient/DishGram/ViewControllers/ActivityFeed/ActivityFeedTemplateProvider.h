//
//  ActivityFeedTemplateProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import <Foundation/Foundation.h>
#import "NVTemplateProvider.h"
#import "MutableRowDataProvider.h"
#import "DefaultTemplateProvider.h"


#define __tileHeight 454
#define __tileWidth 320




@interface ActivityFeedTemplateProvider : DefaultTemplateProvider {

}

-(void)reloadDataProvider;


@end
