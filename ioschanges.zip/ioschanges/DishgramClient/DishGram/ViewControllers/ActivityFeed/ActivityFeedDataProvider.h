//
//  ActivityFeedDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import <Foundation/Foundation.h>
#import "PagedDataProvider.h"
#import "MutableDefaultDataProvider.h"

@interface ActivityFeedDataProvider : MutableDefaultDataProvider

@end
