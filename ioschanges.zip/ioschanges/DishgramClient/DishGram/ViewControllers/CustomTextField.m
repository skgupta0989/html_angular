//
//  CustomTextField.m
//  DishGram
//
//  Created by Satish on 5/3/13.
//
//

#import "CustomTextField.h"

@implementation CustomTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.font = [UIFont fontWithName:@"Roboto-Condensed" size:14];
        
    }
    return self;
}



- (CGRect)textRectForBounds:(CGRect)bounds {
    CGRect inset = CGRectMake(bounds.origin.x + 8, bounds.origin.y, bounds.size.width - 8, bounds.size.height);
    return inset;
}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    CGRect inset = CGRectMake(bounds.origin.x + 8, bounds.origin.y, bounds.size.width - 8, bounds.size.height);
    return inset;
}

- (void)drawPlaceholderInRect:(CGRect)rect {
//   rect=CGRectMake(rect.origin.x+8, rect.origin.y, rect.size.width, rect.size.height);
    [[UIColor lightGrayColor] setFill];
    [[self placeholder] drawInRect:rect withFont:[UIFont fontWithName:@"Roboto-Condensed" size:14]];
}



@end
