//
//  DGOptionSet.h
//  TabPOC
//
//  Created by SumanAmit on 04/06/13.
//  Copyright (c) 2013 NEEV. All rights reserved.
//

#import <UIKit/UIKit.h>

#define OPTION_SELECTED_IMAGE @"OPTION_SELECTED_IMAGE"
#define OPTION_UNSELECTED_IMAGE @"OPTION_UNSELECTED_IMAGE"
#define OPTION_SELECTED_TEXT_COLOR @"OPTION_SELECTED_TEXT_COLOR"
#define OPTION_UNSELECTED_TEXT_COLOR @"OPTION_UNSELECTED_TEXT_COLOR"
#define OPTION_SELECTED_TEXT_FONT @"OPTION_SELECTED_TEXT_FONT"

@interface DGOPtionButton:UIButton{
    UIImageView *optionImage;
    
}
@property (assign, nonatomic) BOOL isSelected;
@property (strong, nonatomic) UILabel *optionLbl;
@property (nonatomic, strong) NSDictionary *context;

- (void)setDGOptionButtonSelected:(BOOL)isOptionSelected;
@end



@interface DGOptionSet : UIView{
    __weak id delegate;
    SEL dgSelector;
    
}
@property (nonatomic,assign)NSInteger selectedOptoin;

- (void)addOptionButtons:(NSArray *)buttons selectedButton:(int)selected;
- (void)addOptionButtons:(NSArray *)buttons selectedButton:(int)selected withContext:(NSDictionary *)context spacing:(int)spacing;

- (void)addTarget:(id)target action:(SEL)selector;
- (void)setOptionSelected:(int)selectedOption;
- (void)setFrame:(CGRect)frame ofButtonIndex:(NSInteger)buttonIndex;
@end

