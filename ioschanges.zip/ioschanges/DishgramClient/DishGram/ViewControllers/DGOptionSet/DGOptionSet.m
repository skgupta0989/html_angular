//
//  DGOptionSet.m
//  TabPOC
//
//  Created by SumanAmit on 04/06/13.
//  Copyright (c) 2013 NEEV. All rights reserved.
//




#import "DGOptionSet.h"
#import "FontUtil.h"

@implementation DGOPtionButton
@synthesize optionLbl,isSelected;
@synthesize context;

- (void)initController{
    self.optionLbl=[[UILabel alloc] initWithFrame:CGRectMake(24, 0, 60, 30)];
    self.optionLbl.autoresizesSubviews=UIViewAutoresizingFlexibleWidth;
    self.optionLbl.backgroundColor=[UIColor clearColor];
    self.optionLbl.font=[FontUtil robotoCondensedWithSize:16];
    optionImage=[[UIImageView alloc] initWithFrame:CGRectMake(5, 8, 13, 13)];
    [self addSubview:self.optionLbl];
    [self addSubview:optionImage];

}

-(void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    self.optionLbl.frame = CGRectMake(self.optionLbl.frame.origin.x, self.optionLbl.frame.origin.y, frame.size.width, self.optionLbl.frame.size.height);
}

-(id)init{
    self=[super init];
    if (self) {
        [self initController];
    }
    return self;
}
- (void)setDGOptionButtonSelected:(BOOL)isOptionSelected{
    self.isSelected=isOptionSelected;
    
    if (self.context != nil) {
        if (isOptionSelected) {
            self.optionLbl.textColor=[context objectForKey:OPTION_SELECTED_TEXT_COLOR];
            optionImage.image=[context objectForKey:OPTION_SELECTED_IMAGE];
        }else{
            self.optionLbl.textColor=[context objectForKey:OPTION_UNSELECTED_TEXT_COLOR];
            optionImage.image=[context objectForKey:OPTION_UNSELECTED_IMAGE];
        }
        self.optionLbl.font=[context objectForKey:OPTION_SELECTED_TEXT_FONT];
    } else {
        if (isOptionSelected) {
            self.optionLbl.textColor=[UIColor blackColor];
            optionImage.image=[UIImage imageNamed:@"radio_active.png"];
            
        }else{
            self.optionLbl.textColor=[UIColor lightGrayColor];
            optionImage.image=[UIImage imageNamed:@"radio_normal.png"];
        }
    }
}
-(void)setOptionLblTitle:(NSString *)title{
    [self initController];
    self.optionLbl.text=title;
}
@end




@implementation DGOptionSet
@synthesize selectedOptoin;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

    }
    return self;
}
- (void)setOptionSelected:(int)selectedOption{
    NSArray *subViews=[self subviews];
    if (selectedOption>[subViews count]) {
        return;
    }

    int i=1;
    for (UIView *view in subViews) {
        if (i==selectedOption) {
            DGOPtionButton *btn=(DGOPtionButton *)[self viewWithTag:i];
            [self setSelectedDGOption:btn];
            self.selectedOptoin=i;
            break;
        }
        i++;
    }
}

- (void)addOptionButtons:(NSArray *)buttons selectedButton:(int)selected {
    [self addOptionButtons:buttons selectedButton:selected withContext:nil spacing:60];
}

- (void)addOptionButtons:(NSArray *)buttons selectedButton:(int)selected withContext:(NSDictionary *)context spacing:(int)spacing {
    CGFloat xOrgin=5;
    int i=1;
    self.selectedOptoin=selected;
    for (NSString *buttonTitle in buttons) {
        DGOPtionButton *btn=[DGOPtionButton buttonWithType:UIButtonTypeCustom];
        btn.context = context;

        [btn setOptionLblTitle:buttonTitle];
        
        btn.frame=CGRectMake(xOrgin, 5, spacing, 40);
        [btn addTarget:self action:@selector(optionButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        if (i==selected) {
            [btn setDGOptionButtonSelected:YES];
        }else{
            [btn setDGOptionButtonSelected:NO];
        }
        btn.tag=i;
        [self addSubview:btn];
        i++;
        xOrgin=xOrgin+spacing;
    }
}
- (void)addTarget:(id)target action:(SEL)selector{
    delegate=target;
    dgSelector=selector;
}

- (void)setSelectedDGOption:(DGOPtionButton *)selectedButton{
    NSArray *subViews=[self subviews];
    for (UIView *view in subViews) {
        if ([view class]==[DGOPtionButton class]) {
            DGOPtionButton *btn=(DGOPtionButton *)view;
            if (btn==selectedButton) {
                [selectedButton setDGOptionButtonSelected:YES];
            }else{
                [btn setDGOptionButtonSelected:NO];
            }
        }
    }
}

- (void) optionButtonAction:(id)sender{
    if (sender!=nil && [sender class]==[DGOPtionButton class]) {
        DGOPtionButton *btn=(DGOPtionButton *)sender;
        self.selectedOptoin=btn.tag;
        [self setSelectedDGOption:sender];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [delegate performSelector:dgSelector withObject:self];
#pragma clang diagnostic pop

    }
}

- (void)setFrame:(CGRect)frame ofButtonIndex:(NSInteger)buttonIndex{
    NSArray *subViews=[self subviews];
    for (UIView *view in subViews) {
        if (([view class]==[DGOPtionButton class])){
            DGOPtionButton *btn=(DGOPtionButton *)view;
            if (btn.tag==buttonIndex) {
                [btn setFrame:frame];
            }
            
        }
    }
}
-(void)dealloc{
    delegate=nil;
    dgSelector=nil;
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
