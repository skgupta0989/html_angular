//
//  ProfileCounts.m
//  DishGram
//
//  Created by Ramesh Varma on 26/08/13.
//
//

#import "ProfileCounts.h"

@implementation ProfileCounts

@synthesize postsCount = postsCount_;
@synthesize draftCount = draftCount_;
@synthesize lovesCount = lovesCount_;

-(id)init {
    self = [super init];
    if (self) {

    }
    return self;
}

@end
