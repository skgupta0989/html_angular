//
//  settings.h
//  DishGram
//
//  Created by Swathi on 8/2/13.
//
//

#import "KVCObject.h"
#import "ResponseDict.h"

@interface settings : ResponseDict
//@property(nonatomic, strong) NSString   *status;
//@property(nonatomic, strong) NSString   *message;
@property (nonatomic,assign) BOOL  object;

@end
