//
//  FollowUser.h
//  DishGram
//
//  Created by Rags on 09/05/13.
//
//

#import "KVCObject.h"

@interface FollowUser : KVCObject

@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) NSArray *object;

@end
