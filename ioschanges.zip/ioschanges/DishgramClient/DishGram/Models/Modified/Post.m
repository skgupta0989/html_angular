//
//  Post.m
//  DishGram
//
//  Created by Satish on 4/22/13.
//
//

#import "Post.h"
#import "Dish.h"
#import "User.h"
#import "Place.h"
#import "DishImage.h"
#import "DishLove.h"

@implementation Post

@synthesize uid, dish, user, place, dishImages, dishLovesCount,dishCommentsCount, viewCount, rating;

- (id)init
{
    self = [super init];
    if (self) {
        
        dish = [[Dish alloc] init];
        user = [[User alloc] init];
        place = [[Place alloc] init];
        dishImages = [[KVCArray alloc] initWithClass:NSClassFromString(@"DishImage")];
    }
    return self;
}
@end
