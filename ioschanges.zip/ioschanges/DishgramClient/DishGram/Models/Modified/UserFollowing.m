//
//  UserFollowing.m
//  DishGram
//
//  Created by Rags on 23/05/13.
//
//

#import "UserFollowing.h"
#import "User.h"

@implementation UserFollowing

@synthesize status;
@synthesize message;
@synthesize object;

-(id)init{
    self = [super init];
    if(self){
        
        object = [[KVCArray alloc] initWithClass:NSClassFromString(@"User")];
        
    }
    return  self ;
}
@end
