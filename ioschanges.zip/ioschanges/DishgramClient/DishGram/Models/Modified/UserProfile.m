//
//  UserProfile.m
//  DishGram
//
//  Created by Satish on 4/22/13.
//
//

#import "UserProfile.h"
#import "User.h"
#import "Post.h"




@implementation UserProfile

@synthesize object, followersCount, followingCount, lovesCount, postsCount, draftCount, isFollowing, userLocation;


- (id)init
{
    self = [super init];
    if (self) {
        object = [[User alloc] init];
    }
    return self;
}

@end
