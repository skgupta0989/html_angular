//
//  Post.h
//  DishGram
//
//  Created by Satish on 4/22/13.
//
//

#import <Foundation/Foundation.h>
#import "KVCObject.h"
@class Dish, Place, DishImage, DishLove, User;

@interface Post : KVCObject




@property (nonatomic, strong) NSNumber  *uid;
@property (nonatomic, strong) Dish      *dish;
@property (nonatomic, strong) User      *user;
@property (nonatomic, strong) Place     *place;
@property (nonatomic, strong) NSArray   *dishImages;
@property (nonatomic, strong) NSNumber  *dishLovesCount;
@property (nonatomic, strong) NSNumber  *dishCommentsCount;
@property (nonatomic, strong) NSNumber  *viewCount;
@property (nonatomic, strong) NSNumber  *rating;


@end
