//
//  ResponseStatus.h
//  DishGram
//
//  Created by Satish on 5/2/13.
//
//

#import "KVCObject.h"

@interface ResponseStatus : KVCObject

@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSMutableDictionary *object;
@end
