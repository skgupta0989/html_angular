//
//  RecommendDish.m
//  DishGram
//
//  Created by Rags on 28/06/13.
//
//

#import "RecommendDish.h"
#import "User.h"
#import "DishPlaces.h"
// for the recent updates
@implementation RecommendDish
@synthesize user;
@synthesize dishPlaces;
@synthesize recommendedToUser;
-(id)init{
    self = [super init];
    if(self){
        user= [[User alloc] init];
        dishPlaces = [[DishPlaces alloc] init];
        recommendedToUser=[[User alloc] init];
       
    }
    return self;
}


@end
