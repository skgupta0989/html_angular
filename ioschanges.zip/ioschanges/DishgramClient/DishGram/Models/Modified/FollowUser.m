//
//  FollowUser.m
//  DishGram
//
//  Created by Rags on 09/05/13.
//
//

#import "FollowUser.h"
#import "FriendsUserInformation.h"
@implementation FollowUser

@synthesize status, message, object;



-(id)init{
    
    self = [super init];
    
    if (self) {
        
        object = [[KVCArray alloc] initWithClass:NSClassFromString(@"FriendsUserInformation")];
        
    }
    return self;
}

@end
