//
//  FriendsUserInformation.h
//  DishGram
//
//  Created by Rags on 09/05/13.
//
//

#import "KVCObject.h"
#import "User.h"

@interface FriendsUserInformation : KVCObject{
    
}

@property (nonatomic, strong) User *user;
@property (nonatomic, strong) NSNumber *postsCount;
@property (nonatomic, strong) NSNumber *followersCount;
@property (nonatomic, assign) BOOL isFollowed;


// Used for Cell in UI
@property (nonatomic, assign) int rowNumber;
@property (nonatomic, strong) NSString* profileImageURL;

@end
