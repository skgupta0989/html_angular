//
//  FriendsUserInformation.m
//  DishGram
//
//  Created by Rags on 09/05/13.
//
//

#import "FriendsUserInformation.h"

@implementation FriendsUserInformation
@synthesize user;
@synthesize postsCount;
@synthesize followersCount;
@synthesize isFollowed;
@synthesize rowNumber, profileImageURL;


-(id)init{
    
    self  = [super init];
    
    if (self) {
    
        user = [[User alloc] init];
    }
    return self;
}


@end
