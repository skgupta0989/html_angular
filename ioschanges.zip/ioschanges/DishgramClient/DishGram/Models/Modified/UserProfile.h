//
//  UserProfile.h
//  DishGram
//
//  Created by Satish on 4/22/13.
//
//

#import <Foundation/Foundation.h>
#import "ResponseDict.h"

@class User;

@interface UserProfile : ResponseDict


@property(nonatomic, strong) User       *object;
@property(nonatomic, strong) NSNumber   *followersCount;
@property(nonatomic, strong) NSNumber   *followingCount;
@property(nonatomic, strong) NSNumber   *lovesCount;
@property(nonatomic, strong) NSNumber   *postsCount;
@property(nonatomic, strong) NSNumber   *draftCount;
@property(nonatomic, strong) NSNumber   *isFollowing;
@property(nonatomic, strong) NSString   *userLocation;

@end
