//
//  ResponseStatus.m
//  DishGram
//
//  Created by Satish on 5/2/13.
//
//

#import "ResponseStatus.h"


@implementation ResponseStatus
@synthesize message, status, object;

-(id)init{
    self = [super init];
    if (self) {
    
        object = [[NSMutableDictionary alloc] init];
        
    }
    return self;
}

@end
