//
//  RecommendDish.h
//  DishGram
//
//  Created by Rags on 28/06/13.
//
//

#import <Foundation/Foundation.h>
#import "User.h"
#import "DishPlaces.h"

@interface RecommendDish : KVCObject{
    
}
@property (nonatomic,strong) NSNumber *uid;
@property (nonatomic,strong) User *user;
@property (nonatomic,strong) DishPlaces *dishPlaces;
@property (nonatomic,strong) User *recommendedToUser;
@property (nonatomic,strong) NSString *message;

@end
