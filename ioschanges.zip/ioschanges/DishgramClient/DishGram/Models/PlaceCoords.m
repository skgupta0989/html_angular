//
//  PlaceCoords.m
//  DishGram
//
//  Created by Ramesh Varma on 27/06/13.
//
//

#import "PlaceCoords.h"
#import "DGLocationManager.h"
#import "PageUtil.h"

@implementation PlaceCoords

@synthesize latitude = latitude_;
@synthesize longitude = longitude_;
@synthesize address = address_;

-(id)init:(double)latitude longitude:(double)longitude address:(NSString *)address {
    self = [super init];
    if (self) {
        self.latitude = latitude;
        self.longitude = longitude;
        self.address = address;
    }
    return self;
}

-(CLLocationCoordinate2D)location {
    CLLocationCoordinate2D location;
    location.latitude = self.latitude;
    location.longitude = self.longitude;
    
    return location;
}

-(bool)similar:(PlaceCoords *)coords {
    NSNumber *dist = [DGLocationManager getDistanceInMeterFrom:[PageUtil placeCoordsToLocation:self] to:[PageUtil placeCoordsToLocation:coords]];
    return dist.doubleValue < 100;
}

@end
