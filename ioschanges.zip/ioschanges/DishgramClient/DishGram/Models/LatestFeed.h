//
//  LatestFeed.h
//  DishGram
//
//  Created by Rags on 27/06/13.
//
//

#import <Foundation/Foundation.h>
#import "DishPlaces.h"
#import "KVCObject.h"
#import "RecentUpdate.h"
#import "User.h"
@interface LatestFeed : KVCObject

@property (nonatomic, strong) NSString *eventType;
@property (nonatomic, strong) NSString *lastUpdated;
@property (nonatomic, strong) RecentUpdate *object1;
@property (nonatomic, strong) User *user;
@end
