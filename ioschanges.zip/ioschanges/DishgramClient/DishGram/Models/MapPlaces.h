//
//  MapPlaces.h
//  DishGram
//
//  Created by User on 8/16/13.
//
//

#import "KVCObject.h"

@interface MapPlaces : KVCObject{
@public
    NSNumber *placeId_;
    NSNumber *latitude_;
    NSNumber *longitude_;
    NSString *dishImage_;
}
@property (nonatomic, strong) NSNumber *placeId;
@property (nonatomic, strong) NSNumber *latitude;
@property (nonatomic, strong) NSNumber *longitude;
@property (nonatomic, strong) NSString *dishImage;
@end
