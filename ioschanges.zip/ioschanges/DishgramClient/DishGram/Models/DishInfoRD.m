//
//  DishInfoRD.m
//  DishGram
//
//  Created by Ramesh Varma on 31/05/13.
//
//

#import "DishInfoRD.h"
#import "DishPlaces.h"

@implementation DishInfoRD

@synthesize object;
@synthesize loggedInUser;
@synthesize isLoved;

- (id)init
{
    self = [super init];
    if (self) {
        object = [[DishPlaces alloc] init];
        loggedInUser =[[User alloc] init];
    }
    return self;
}

@end
