//
//  DishInfoRD.h
//  DishGram
//
//  Created by Ramesh Varma on 31/05/13.
//
//

#import "KVCObject.h"
#import "DishPlaces.h"
#import "User.h"
#import "ResponseDict.h"

@interface DishInfoRD : ResponseDict

@property(nonatomic, strong) DishPlaces       *object;
@property(nonatomic, strong) User              *loggedInUser;
@property(nonatomic) bool isLoved;

@end
