//
//  PlaceInfoRD.h
//  DishGram
//
//  Created by Ramesh Varma on 10/06/13.
//
//

#import "KVCObject.h"
#import "Place.h"
#import "DishPlaces.h"
#import "User.h"
#import "ResponseDict.h"

@interface PlaceInfoRD : ResponseDict

@property(nonatomic, strong) Place      *place;
@property(nonatomic, strong) KVCArray   *dishPlaceses;
@property(nonatomic, strong) NSNumber   *dishCount;
@property(nonatomic, strong) NSNumber   *followers;
@property(nonatomic, strong) NSNumber   *listCount;
@property(nonatomic) bool isFollowing;


@end
