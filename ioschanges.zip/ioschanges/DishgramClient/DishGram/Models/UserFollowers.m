//
//  UserFollowers.m
//  DishGram
//
//  Created by Rags on 19/06/13.
//
//

#import "UserFollowers.h"

@implementation UserFollowers
@synthesize user,followingStatus, isSelected,listOfFriends,isFollowBtnClickInFollowers;
-(id)init{
    self = [super init];
    if(self){
        user= [[User alloc] init];
        listOfFriends = [[NSMutableArray alloc] init];
    }
    return self;
}

@end
