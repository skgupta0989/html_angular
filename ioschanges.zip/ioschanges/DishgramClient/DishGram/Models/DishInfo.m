//
//  DishInfo.m
//  DishGram
//
//  Created by Satish on 4/24/13.
//
//

#import "DishInfo.h"
#import "Post.h"
@implementation DishInfo

@synthesize dishPlaces = dishPlaces_;
@synthesize isLoved = isLoved_;


-(id)init{
    self = [super init];
    if (self) {
        self.dishPlaces = [[DishPlaces alloc] init];
    }
    return self;
}

@end
