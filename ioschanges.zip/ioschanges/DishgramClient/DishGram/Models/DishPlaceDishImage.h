//
//  DishPlaceDishImage.h
//  DishGram
//
//  Created by AshishSharma on 12/07/13.
//
//

#import "KVCObject.h"
@class DishImageType;

@interface DishPlaceDishImage : KVCObject{
@public
NSNumber *uid_;
NSString *dishURL_;
DishImageType *dishImageType_;
NSString *imeiToken_;
NSString *dateCreated_;
NSString *lastUpdated_;
}

@property (nonatomic, strong) NSNumber *uid;
@property (nonatomic, strong) NSString *dishURL;
@property (nonatomic, strong) DishImageType *dishImageType;
@property (nonatomic, strong) NSString *imeiToken;
@property (nonatomic, strong) NSString *dateCreated;
@property (nonatomic, strong) NSString *lastUpdated;
@end
