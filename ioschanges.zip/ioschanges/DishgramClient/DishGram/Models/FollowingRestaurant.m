//
//  FollowingRestaurant.m
//  DishGram
//
//  Created by Rags on 30/05/13.
//
//

#import "FollowingRestaurant.h"


@implementation FollowingRestaurant
@synthesize place, dishCount,placeFollowCount,isFollowing,followingStatus;

-(id)init{
    self = [super init];
    if(self){
        
        place= [[Place alloc] init];
    }
    return self;
    
}

@end
