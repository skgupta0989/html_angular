//
//  ExplorePlace.h
//  DishGram
//
//  Created by Ramesh Varma on 25/06/13.
//
//

#import "KVCObject.h"
#import "Place.h"

@interface ExplorePlace : KVCObject {
    @public
    Place *place_;
    NSNumber *dishCount_;
    NSNumber *followersCount_;
    NSNumber *latitude_;
    NSNumber *longitude_;
    NSNumber *isFollowing_;
}

@property (nonatomic, strong) Place *place;
@property (nonatomic, strong) NSNumber *dishCount;
@property (nonatomic, strong) NSNumber *followersCount;
@property (nonatomic, strong) NSNumber *isFollowing;
@property (nonatomic, strong) NSNumber *latitude;
@property (nonatomic, strong) NSNumber *longitude;


@end

