//
//  DishInfo.h
//  DishGram
//
//  Created by Satish on 4/24/13.
//
//

#import <Foundation/Foundation.h>
#import "KVCObject.h"
#import "DishPlaces.h"

@interface DishInfo : KVCObject {
    @public
    DishPlaces *dishPlaces_;
    bool isLoved_;
}

@property (nonatomic, strong) DishPlaces  *dishPlaces;
@property (nonatomic) bool isLoved;

@end
