//
//  ProfileDetailModel.h
//  DishGram
//
//  Created by Satish on 7/18/13.
//
//

#import "KVCObject.h"


@class User;
@interface ProfileDetailModel : KVCObject



@property (nonatomic, strong) NSNumber  *uid;
@property (nonatomic, strong) NSString  *firstName;
@property (nonatomic, strong) NSString  *lastName;
@property (nonatomic, strong) NSString  *dob; // MM-dd-yyyy
@property (nonatomic, strong) User      *user;
@property (nonatomic, strong) NSString  *gender;
@property (nonatomic, strong) NSString  *location;

@end
