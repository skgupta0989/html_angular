//
//  FollowingUserResponseCount.h
//  DishGram
//
//  Created by Rags on 12/06/13.
//
//

#import "ResponseDict.h"

@interface FollowingUserResponseCount : ResponseDict
@property (nonatomic, strong) NSNumber *followingResturantCount;
@property (nonatomic, strong) NSNumber *followingUserCount;
@property (nonatomic, strong) NSArray *object;

    


@end
