//
//  RecentUpdate.h
//  DishGram
//
//  Created by Rags on 28/06/13.
//
//

#import <Foundation/Foundation.h>
#import "KVCObject.h"
#import "DishPlaces.h"
#import "User.h"
#import "RecommendDish.h"
#import "Place.h"

@interface RecentUpdate : KVCObject
// event type pist_dish 
@property (nonatomic,strong) DishPlaces *dishPlaces;



// event Type Follow_User
@property (nonatomic,strong) User *user;
@property (nonatomic,strong) User *followingUser;



//event Type Comment_dish
@property (nonatomic,strong) NSNumber *uid;
@property (nonatomic,strong) NSString  *comment;
// alreary added 
//@property (nonatomic,strong) User *user;
//@property (nonatomic,strong) DishPlaces *dishPlaces;

//event Type Love_dish
//already declared
//@property (nonatomic,strong) User *user;
//@property (nonatomic,strong) DishPlaces *dishPlaces;
// event Type Recommend_dish
@property (nonatomic,strong) RecommendDish *recommendDish;
@property (nonatomic, strong) Place *place;



@end
