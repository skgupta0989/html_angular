//
//  ResponseDict.m
//  DishGram
//
//  Created by Satish on 5/31/13.
//
//

#import "ResponseDict.h"

@implementation ResponseDict

@synthesize message;
@synthesize status;



@end
