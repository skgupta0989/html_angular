//
//  settings.m
//  DishGram
//
//  Created by Swathi on 8/2/13.
//
//

#import "settings.h"

@implementation settings

//@synthesize   status;
//@synthesize message;
@synthesize object;

@end
