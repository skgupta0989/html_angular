//
//  FollowingUserResponseCount.m
//  DishGram
//
//  Created by Rags on 12/06/13.
//
//

#import "FollowingUserResponseCount.h"

@implementation FollowingUserResponseCount

@synthesize  followingResturantCount;
@synthesize followingUserCount;
@synthesize object;

@end
