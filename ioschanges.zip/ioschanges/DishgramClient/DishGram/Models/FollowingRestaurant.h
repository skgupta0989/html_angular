//
//  FollowingRestaurant.h
//  DishGram
//
//  Created by Rags on 30/05/13.
//
//

#import "KVCObject.h"
#import "Place.h"

@interface FollowingRestaurant : KVCObject
@property (nonatomic, strong) Place *place;
@property (nonatomic, strong) NSNumber *dishCount;
@property (nonatomic, strong) NSNumber *placeFollowCount;
@property (nonatomic,assign) BOOL isFollowing;
@property (nonatomic,assign) BOOL followingStatus;


@end
