//
//  DishPlaceDishImage.m
//  DishGram
//
//  Created by AshishSharma on 12/07/13.
//
//

#import "DishPlaceDishImage.h"
#import "DishImageType.h"
@implementation DishPlaceDishImage

@synthesize uid = uid_;
@synthesize dishURL = dishURL_;
@synthesize dishImageType = dishImageType_;
@synthesize imeiToken = imeiToken_;
@synthesize dateCreated = dateCreated_;
@synthesize lastUpdated = lastUpdated_;

-(id)init{
    self = [super init];
    if (self) {
        self.dishImageType = [[DishImageType alloc] init];

    }
    return self;
}

@end
