//
//  LatestFeed.m
//  DishGram
//
//  Created by Rags on 27/06/13.
//
//

#import "LatestFeed.h"

@implementation LatestFeed
@synthesize eventType;
@synthesize lastUpdated;
@synthesize object1;
@synthesize user;



-(id)init{
    self = [super init];
    if(self){
        
        object1 = [[RecentUpdate alloc] init];
        user=[[User alloc] init];
    }
    return self;
}
@end
