//
//  ResponseDict.h
//  DishGram
//
//  Created by Satish on 5/31/13.
//
//

#import "KVCObject.h"

@interface ResponseDict : KVCObject

@property(nonatomic, strong) NSString   *status;
@property(nonatomic, strong) NSString   *message;



@end
