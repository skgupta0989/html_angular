//
//  ProfileDetailModel.m
//  DishGram
//
//  Created by Satish on 7/18/13.
//
//

#import "ProfileDetailModel.h"
#import "User.h"

@implementation ProfileDetailModel

@synthesize uid, firstName, lastName, dob, user, gender, location;

-(id)init{
    if (self = [super init]) {
        user = [[User alloc] init];
    }
    return self;
}

@end
