//
//  MapPlace.h
//  DishGram
//
//  Created by Ramesh Varma on 27/06/13.
//
//

#import "PlaceCoords.h"

@interface MapPlace : PlaceCoords

@property (nonatomic, strong) NSString *address2;
@property (nonatomic, strong) NSString *placeName;
@property (nonatomic, strong) NSNumber *lovesCount;
@property (nonatomic, strong) NSNumber *commentsCount;
@property (nonatomic, strong) NSNumber *rating;
@property (nonatomic, strong) NSString *imageUrl;
@property (nonatomic, strong) NSString *uid;

@end
