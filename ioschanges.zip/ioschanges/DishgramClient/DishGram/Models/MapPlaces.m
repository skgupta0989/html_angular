//
//  MapPlaces.m
//  DishGram
//
//  Created by User on 8/16/13.
//
//

#import "MapPlaces.h"

@implementation MapPlaces
@synthesize placeId = placeId_;
@synthesize latitude = latitude_;
@synthesize longitude = longitude_;
@synthesize dishImage = dishImage_;

-(id)init{
    self = [super init];
    if (self) {
        
    }
    return self;
}
@end
