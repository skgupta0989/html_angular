//
//  Draft.h
//  DishGram
//
//  Created by AshishSharma on 11/07/13.
//
//

#import "KVCObject.h"
#import "DishImage.h"
#import "DishType.h"
#import "User.h"
#import "Place.h"
#import "DishPlaceDishImage.h"

@class Dish;
@class City;
@class DishType;
@interface Draft : KVCObject {

    NSNumber *uid_;
    NSString *dishPlaceDescription_;
    NSDate *dateCreated_;
    NSNumber *viewCount_;
    NSNumber *rating_;
    NSNumber *dishPostedCount_;
    User *user_;
    Place *place_;
    Dish *dish_;
    DishPlaceDishImage *dishImageCover_;
    DishPlaceDishImage *dishImageThumbnail_;
    City *city_;
    DishType *dishType_;
}

@property (nonatomic, strong) NSNumber *uid;
@property (nonatomic, strong) NSString *dishPlaceDescription;
@property (nonatomic, strong) NSDate *dateCreated;
@property (nonatomic, strong) NSNumber *viewCount;
@property (nonatomic, strong) NSNumber *rating;
@property (nonatomic, strong) NSNumber *dishPostedCount;
@property (nonatomic, strong) User *user;
@property (nonatomic, strong) Place *place;
@property (nonatomic, strong) DishPlaceDishImage *dishImageCover;
@property (nonatomic, strong) DishPlaceDishImage *dishImageThumbnail;
@property (nonatomic, strong) Dish *dish;
@property (nonatomic, strong) City *city;
@property (nonatomic, strong) DishType *dishType;

@end
