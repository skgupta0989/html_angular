//
//  Draft.m
//  DishGram
//
//  Created by AshishSharma on 11/07/13.
//
//

#import "Draft.h"
#import "Dish.h"
#import "DishType.h"
#import "City.h"
@implementation Draft

@synthesize uid = uid_;
@synthesize dishPlaceDescription = dishPlaceDescription_;
@synthesize dateCreated = dateCreated_;
@synthesize viewCount = viewCount_;
@synthesize rating = rating_;
@synthesize dishPostedCount = dishPostedCount_;
@synthesize user = user_;
@synthesize place = place_;
@synthesize dishImageCover = dishImageCover_;
@synthesize dishImageThumbnail = dishImageThumbnail_;
@synthesize dish=dish_;
@synthesize city=city_;
@synthesize dishType=dishType_;
-(id)init{
    
    self = [super init];
    if (self) {
        self.user = [[User alloc] init];
        self.place = [[Place alloc] init];
        self.dish=[[Dish alloc] init];
        self.dishImageCover = [[DishPlaceDishImage alloc] init];
        self.dishImageThumbnail = [[DishPlaceDishImage alloc] init];
        self.city=[[City alloc] init];
        self.dishType=[[DishType alloc] init];
    }
    return self;
}

@end
