//
//  PlaceInfoRD.m
//  DishGram
//
//  Created by Ramesh Varma on 10/06/13.
//
//

#import "PlaceInfoRD.h"

@implementation PlaceInfoRD

@synthesize dishCount;
@synthesize dishPlaceses;
@synthesize followers;
@synthesize listCount;
@synthesize place;
@synthesize isFollowing;

- (id)init
{
    self = [super init];
    if (self) {
        place = [[Place alloc] init];
        dishPlaceses = [[KVCArray alloc] initWithClass:[DishPlaces class]];
    }
    return self;
}

@end
