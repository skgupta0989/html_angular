//
//  RecentUpdate.m
//  DishGram
//
//  Created by Rags on 28/06/13.
//
//

#import "RecentUpdate.h"

@implementation RecentUpdate

@synthesize  dishPlaces;
@synthesize user;
@synthesize followingUser;
@synthesize uid;
@synthesize comment;
@synthesize recommendDish;
@synthesize place;
-(id)init{
    self = [super init];
    if(self){
        user= [[User alloc] init];
        dishPlaces = [[DishPlaces alloc] init];
        followingUser = [[User alloc] init];
        recommendDish = [[RecommendDish alloc] init];
        place = [[Place alloc] init];
    }
    return self;
}
@end
