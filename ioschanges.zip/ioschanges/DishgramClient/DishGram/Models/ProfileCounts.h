//
//  ProfileCounts.h
//  DishGram
//
//  Created by Ramesh Varma on 26/08/13.
//
//

#import "KVCObject.h"


@interface ProfileCounts : KVCObject {
@public
    NSNumber *postsCount_;
    NSNumber *lovesCount_;
    NSNumber *draftCount_;
}

@property (nonatomic, strong) NSNumber *postsCount;
@property (nonatomic, strong) NSNumber *lovesCount;
@property (nonatomic, strong) NSNumber *draftCount;

@end
