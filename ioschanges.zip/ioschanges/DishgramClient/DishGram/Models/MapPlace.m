//
//  MapPlace.m
//  DishGram
//
//  Created by Ramesh Varma on 27/06/13.
//
//

#import "MapPlace.h"

@implementation MapPlace

@end
