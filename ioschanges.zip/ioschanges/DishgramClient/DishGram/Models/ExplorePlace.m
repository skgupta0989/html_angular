//
//  ExplorePlace.m
//  DishGram
//
//  Created by Ramesh Varma on 25/06/13.
//
//

#import "ExplorePlace.h"

@implementation ExplorePlace

@synthesize longitude=longitude_;
@synthesize latitude= latitude_;
@synthesize place=place_;
@synthesize dishCount=dishCount_;
@synthesize followersCount=followersCount_;
@synthesize isFollowing=isFollowing_;

-(id)init {
    self = [super init];
    if (self) {
        self.place = [[Place alloc] init];        
    }
    return self;
}

@end
