//
//  PlaceCoords.h
//  DishGram
//
//  Created by Ramesh Varma on 27/06/13.
//
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@interface PlaceCoords : NSObject

@property (nonatomic, assign) double longitude;
@property (nonatomic, assign) double latitude;
@property (nonatomic, strong) NSString *address;

-(CLLocationCoordinate2D)location;
-(bool)similar:(PlaceCoords *)coords;

-(id)init:(double)latitude longitude:(double)longitude address:(NSString *)address;

@end
