//
//  UserFollowers.h
//  DishGram
//
//  Created by Rags on 19/06/13.
//
//

#import <Foundation/Foundation.h>
#import "User.h"
#import "KVCObject.h"
@interface UserFollowers : KVCObject

@property (nonatomic, assign) BOOL followingStatus;
@property (nonatomic, strong)User *user;


// View Purpose
@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, strong) NSMutableArray *listOfFriends;
@property (nonatomic, assign) BOOL isFollowBtnClickInFollowers;

@end
