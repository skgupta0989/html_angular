//
//  WebServiceInvoker.m
//  DishGram
//
//  Created by Rags on 18/04/13.
//
//

#import "WebServiceInvoker.h"
#import "NetworkCheck.h"
#import "Utilities.h"
#import "Header.h"
#import "AppDelegate.h"
#import "DataSingleton.h"

@implementation WebServiceInvoker

-(void)sendUrlandParameters:(NSString *)URL andParameters:(NSMutableDictionary *)dict withCallBack:(void (^)(bool success, NSString* response)) callBack {

    AppDelegate *appdel = [[UIApplication sharedApplication] delegate];

    if([appdel checkWhetherInternetIsAvailable]) {
        [WebServiceInvoker addToken:dict];
        
        if (![URL hasPrefix:@"http"]) {
            URL = [NSString stringWithFormat:@"%@%@", URL_PREFIX, URL];
        }
        
        NSLog(@"URL  = %@", URL);
        NSLog(@"dict = %@", dict);
        MKNetworkOperation *operation = [self operationWithURLString:URL params:dict httpMethod:@"POST"];
        
        [operation setPostDataEncoding:MKNKPostDataEncodingTypeJSON];
        
        [operation onCompletion:^(MKNetworkOperation *completedOperation){
            NSString *str = [completedOperation responseString];
            callBack(true, str);
        }onError:^(NSError *error){
            callBack(false, [DataSingleton stringValueForKey:@"error_network_connection"]);
            NSLog(@"error=%@",error.description);
        }];
        
        [self enqueueOperation:operation];
    }else{
        [self performSelectorInBackground:@selector(asnycallback:) withObject:^{
            callBack(false, [DataSingleton stringValueForKey:@"error_network_connection"]);
        }];
    }
}

+(void)addToken:(NSMutableDictionary *)dict {
    NSString *token = [Utilities getToken];
    if (token != nil) {
        [dict setObject:token forKey:TOKEN];
    }
}

-(void)asnycallback:(void (^)(void))callback {
    callback();
}

@end
