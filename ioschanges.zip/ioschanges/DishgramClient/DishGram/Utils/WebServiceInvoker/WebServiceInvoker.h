//
//  WebServiceInvoker.h
//  DishGram
//
//  Created by Rags on 18/04/13.
//
//

#import "MKNetworkEngine.h"
#import "Utilities.h"
#import "NetworkCheck.h"
#import "Header.h"

// #define WEB_SERVICE_INVOKER_CALLBACK void (^)(bool success, NSString* response)

@interface WebServiceInvoker : MKNetworkEngine

-(void)sendUrlandParameters:(NSString *)URL
              andParameters:(NSMutableDictionary *)dict
               withCallBack: (void (^)(bool success, NSString* response)) callBack;

@end
