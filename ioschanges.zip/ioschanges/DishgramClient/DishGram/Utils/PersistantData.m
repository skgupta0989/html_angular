//
//  PersistantData.m
//  DishGram
//
//  Created by Ramesh Varma on 02/07/13.
//
//

#import "PersistantData.h"

@implementation PersistantData

@synthesize data = data_;

-(id)initWithName:(NSString *)name {
    self = [super init];
    if(self) {
        // load from file
        name_ = name;
        dirNotCreated = YES;
        [self load];
    }
    return self;
}

-(void)addData:(NSObject *)data {
    if ([self.data indexOfObject:data] != NSNotFound) {
        [self.data removeObject:data];
    }
    [self.data insertObject:data atIndex:0];
    [self persist];
}

-(void)removeData:(NSObject *)data {
    [self.data removeObject:data];
    [self persist];
}

-(void)persist {
    
    // check if the directory is already created.
    if (dirNotCreated) {
        // create directory
        [[NSFileManager defaultManager] createDirectoryAtPath:[self getFileNamePrefix] withIntermediateDirectories:YES attributes:nil error:nil];
        dirNotCreated = FALSE;
    }
    [self.data writeToFile:[self getFileName] atomically:YES];
}

-(void)load {
    NSMutableArray *loadedData = [NSMutableArray arrayWithContentsOfFile:[self getFileName]];
    if (loadedData == nil) {
        loadedData = [[NSMutableArray alloc] init];
    }
    data_ = loadedData;
}

-(NSString *)getFileNamePrefix {
    if (documentPathPrefix == nil) {
        documentPathPrefix = [Utilities getFileNamePrefix:@"DGHistory"];
    }
    return documentPathPrefix;
}

-(NSString *)getFileName {    
    // full directory path
    return [[self getFileNamePrefix] stringByAppendingPathComponent:name_];
}

@end
