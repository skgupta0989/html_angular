//
//  CacheFactory.h
//  DishGram
//
//  Created by User on 5/7/13.
//
//

#import <Foundation/Foundation.h>
#import "ImageCache.h"

#define CACHE_NAME_DEFAULT @"default"
#define CACHE_NAME_FB_IMAGE @"fbcache"
#define CACHE_NAME_DISH_IMAGE @"dishcache"

#define DEFAULT_CACHE_C1_SIZE 50
#define DEFAULT_CACHE_C2_SIZE 7
#define DEFAULT_CACHE_IS_PERSISTANT true

#define FB_IMAGE_CACHE_C1_SIZE 100
#define FB_IMAGE_CACHE_C2_SIZE 5
#define FB_IMAGE_CACHE_IS_PERSISTANT true

#define DISH_IMAGE_CACHE_C1_SIZE 100
#define DISH_IMAGE_CACHE_C2_SIZE 5
#define DISH_IMAGE_CACHE_IS_PERSISTANT true

// usage example:
// ImageCache *imageCache = [CacheFactory getImageCacheByName:CACHE_NAME_FB_IMAGE]
// // store imageCache as an instance variable
// [imageCache getImage:urlString withPrefetch:anArrayWith4adjacentImageUrls]
@interface CacheFactory : NSObject

// returns default implementation of image chache (CACHE_NAME_DEFAULT)
+(ImageCache *)getImageCache;

// returns image cache for specified name. names defined by CACHE_NAME_* are supported
// this class must be modified to add new image caches if required
+(ImageCache *)getImageCacheByName:(NSString *)name;


@end
