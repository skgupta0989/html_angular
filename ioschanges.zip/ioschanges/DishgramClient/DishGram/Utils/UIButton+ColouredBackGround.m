//
//  UIButton+ColouredBackGround.m
//  DishGram
//
//  Created by Rags on 09/05/13.
//
//

#import "UIButton+ColouredBackGround.h"
#import <QuartzCore/QuartzCore.h>

@implementation UIButton (ColouredBackGround)

- (void)setBackgroundImageByColor:(UIColor *)backgroundColor forState:(UIControlState)state{
    
    // tcv - temporary colored view
    UIView *tcv = [[UIView alloc] initWithFrame:self.frame];
    [tcv setBackgroundColor:backgroundColor];
    
    // set up a graphics context of button's size
    CGSize gcSize = tcv.frame.size;
    UIGraphicsBeginImageContext(gcSize);
    // add tcv's layer to context
    [tcv.layer renderInContext:UIGraphicsGetCurrentContext()];
    // create background image now
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    // set image as button's background image for the given state
    [self setBackgroundImage:image forState:state];
    UIGraphicsEndImageContext();
    
    // ensure rounded button
    self.clipsToBounds = YES;
    self.layer.cornerRadius = 8.0;
    
    
    
}


@end
