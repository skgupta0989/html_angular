//
//  NVPullToRefreshPagedDataViewController.h
//  DishGram
//
//  Created by Ramesh Varma on 18/07/13.
//
//

#import <UIKit/UIKit.h>
#import "PullRefreshTableViewController.h"
#import "NVPagedDataView.h"

@interface NVPullToRefreshPagedDataViewController : PullRefreshTableViewController {
        NVPagedDataView *pagedDataView;
}

@property (nonatomic, strong) NVPagedDataView *pagedDataView;

-(void)prepare;
-(void)refreshDo;

@end
