//
//  FontUtil.h
//  DishGram
//
//  Created by Satish on 5/28/13.
//
//

#import <Foundation/Foundation.h>
#import "NVLabel.h"

@interface FontUtil : NSObject

+ (void)decorate:(NVLabel *)label;
+(void)decorateView:(UIView *)view;

+(UIFont*)robotoCondensedWithSize:(int)size;
+(UIFont*)robotoRegularWithSize:(int)size;
+(UIFont*)robotoMediumWithSize:(int)size;
+(UIFont*)robotoItalicWithSize:(int)size;

@end
