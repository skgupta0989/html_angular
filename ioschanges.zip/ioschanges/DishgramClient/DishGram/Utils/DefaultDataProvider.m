//
//  DefaultDataProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 27/05/13.
//
//

#import "DefaultDataProvider.h"
#import "DataSourceFactory.h"
#import "DishInfo.h"
#import "Utilities.h"


#define MAX_PAGE_SIZE @"max"
#define PAGE_NO @"pageNo"

@implementation DefaultDataProvider

@synthesize url;

-(id)init:(NSString *)reqUrl respType:(Class)respTypeClass{
    self = [super init];
    if (self) {
        self.url = reqUrl;
        self.respType = respTypeClass;
    }
    return self;
}

// Adds user token to reqeust
-(NSMutableDictionary *)getRequest {
    NSMutableDictionary *request = [[NSMutableDictionary alloc] init];
    return request;
}

// Adds pange number and size to request 
-(NSMutableDictionary *)getRequest:(int)pageNo size:(int)pageSize {
    NSMutableDictionary *request = [self getRequest];
    [request setObject:[NSString stringWithFormat:@"%d", pageSize] forKey:MAX_PAGE_SIZE];
    [request setObject:[NSString stringWithFormat:@"%d", pageNo] forKey:PAGE_NO];
    return request;
}

-(NSObject *)getEntity {
    NSMutableDictionary *request = [self getRequest];
    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    NSCondition *requestLock = [[NSCondition alloc] init];
    
    NSObject __block *responseObj = nil;
    
    [requestLock lock];
    
    [dataSource requestDataWithURLString:url params:request modelClass:self.respType callBack:^(bool success, NSObject *response) {
        [requestLock lock];
        
        responseObj = response;
       
        if (!success) {
            if (![((NSString *)response) isEqualToString:TOKEN_DOES_NOT_EXIST]) {
                [self onError:(NSString *)response];
            }
        }
        [requestLock signal];
        [requestLock unlock];
    }];
    [requestLock wait];
    [requestLock unlock];
    return responseObj;
}

-(NSArray *)getPage:(int)pageNumber pageSize:(int)pageSize {
    NSMutableDictionary *request = [self getRequest:pageNumber size:pageSize];
    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    NSCondition *requestLock = [[NSCondition alloc] init];
    
    NSArray __block *responseArray = nil;
    
    [requestLock lock];
    
    [dataSource requestDataWithURLString:url params:request modelClass:self.respType callBack:^(bool success, NSObject *response) {
        [requestLock lock];
        if (success) {
            responseArray = (NSArray *)response;
        } else {
            if (![((NSString *)response) isEqualToString:TOKEN_DOES_NOT_EXIST]) {
                [self onError:(NSString *)response];
            }
        }
        [requestLock signal];
        [requestLock unlock];
    }];
    [requestLock wait];
    [requestLock unlock];
    return responseArray;
}

// override this method in subclasses to handle connection errors.
-(void)onError:(NSString *)message {
    
}

-(NSInteger)size {
    return 1000;
}

@end
