//
//  ImageSource.h
//  DishGram
//
//  Created by User on 5/3/13.
//
//


// class for fething image data from network
@interface ImageSource : NSObject

// retuns and UIImage object constructed from data
// fetched by accessing url.
// a loacl sample iamge is return after 1sec delay if the url starts with test://
-(UIImage *)getImage:(NSString *)url;

@end
