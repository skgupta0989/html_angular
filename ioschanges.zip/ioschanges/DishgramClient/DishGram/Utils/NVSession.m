//
//  NVSession.m
//  DishGram
//
//  Created by Ramesh Varma on 18/06/13.
//
//

#import "NVSession.h"

@implementation NVSession

NSMutableDictionary *_nv_session;

+(void)setInSession:(NSString *)key value:(NSObject *)val {
    
    if (_nv_session == nil) {
        _nv_session = [[NSMutableDictionary alloc] init];
    }
    
    [_nv_session setValue:val forKey:key];
}

+(void)removeFromSession:(NSString *)key {
    
    if (_nv_session == nil) {
        _nv_session = [[NSMutableDictionary alloc] init];
    }
    
    [_nv_session removeObjectForKey:key];
}

+(NSObject *)getFromSession:(NSString *)key {
    if (_nv_session == nil) {
        _nv_session = [[NSMutableDictionary alloc] init];
    }

    return [_nv_session objectForKey:key];
}


@end
