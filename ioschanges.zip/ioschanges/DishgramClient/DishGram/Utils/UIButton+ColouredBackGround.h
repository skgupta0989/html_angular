//
//  UIButton+ColouredBackGround.h
//  DishGram
//
//  Created by Rags on 09/05/13.
//
//

#import <UIKit/UIKit.h>

@interface UIButton (ColouredBackGround)
- (void)setBackgroundImageByColor:(UIColor *)backgroundColor forState:(UIControlState)state;

@end
