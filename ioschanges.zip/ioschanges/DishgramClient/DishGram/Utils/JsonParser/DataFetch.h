//
//  DataFetch.h
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#import <Foundation/Foundation.h>

@class UserProfile, Place, Dish, User, DishLove, DishInfo, ResponseStatus, FriendsUserInformation;
@interface DataFetch : NSObject



-(ResponseStatus*)responseStatusFilter:(NSString*)responseString;

//User Profile 
-(UserProfile*)userProfileFilter:(NSString*)responseString;


//
//-(Place*)placeFilter:(NSDictionary*)placeDict;
//-(Dish*)dishDataFilter:(NSDictionary*)dishDict;
//-(NSArray*)dishImageIdFilter:(NSArray*)imagesArray;
//-(NSArray *)userImagesFilter:(NSArray *)imagesArray;
//-(User*)userDataFilter:(NSDictionary*)userDict;
//-(NSArray*)dishLoveFilter:(NSArray*)dishLoveArray;
//-(NSArray*)postDataFilter:(NSArray*)postArray;


// DishPlacesList
-(NSArray*)dishListFilter:(NSArray*)placeArray;


// DishInfo

-(DishInfo*)dishInfoFilter:(NSString*)responseString;

- (NSArray *)followUserFilter:(NSString *)responseString;
// get following users details

-(NSArray *)followingUserFiler:(NSString *)responseString;



@end
