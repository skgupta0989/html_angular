//
//  JsonResponseParser.m
//  DishGram
//
//  Created by Rags on 15/04/13.
//
//

#import "JsonResponseParser.h"
#import "SBJson.h"

@implementation JsonResponseParser


+(NSDictionary*)getParserData:(NSString*)dataString{
    NSDictionary *info = [dataString JSONValue];
    return info;
}

@end
