//
//  DataFetch.m
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#import "DataFetch.h"
#import "JsonResponseParser.h"
#import "Constant.h"
#import "Place.h"
#import "Dish.h"
#import "UserImage.h"
#import "UserImageType.h"
#import "User.h"
#import "DishImage.h"
#import "DishLove.h"
#import "Post.h"
#import "UserProfile.h"
#import "DishPlaces.h"
#import "DishInfo.h"
#import "City.h"
#import "State.h"
#import "Country.h"
#import "ResponseStatus.h"
#import "FriendsUserInformation.h"
#import "FollowUser.h"
#import "UserFollowing.h"


@implementation DataFetch

-(void)registrationFilter:(NSString*)responseString{
    
    NSDictionary *dataDict = [JsonResponseParser getParserData:responseString];
    
    NSLog(@"\nStatus:%@,Message: %@",[dataDict objectForKey:@"status"],[dataDict objectForKey:@"message"]);
}


-(void)loginFilter:(NSString*)responseString{
    
    NSDictionary *dataDict = [JsonResponseParser getParserData:responseString];
    
    NSLog(@"\nStatus:%@, Message: %@",[dataDict objectForKey:@"status"],[dataDict objectForKey:@"message"]);
}


-(void)socialLoginFilter:(NSString*)responseString{
    
    NSDictionary *dataDict = [JsonResponseParser getParserData:responseString];
    
    NSLog(@"\nStatus:%@, Message: %@",[dataDict objectForKey:@"status"],[dataDict objectForKey:@"message"]);
}



//-(void)followUserFilter:(NSString*)responseString{
//
//    NSDictionary *dataDict = [JsonResponseParser getParserData:responseString];
//    NSLog(@"\nStatus:%@,Message: %@",[dataDict objectForKey:@"status"],[dataDict objectForKey:@"message"]);
//
//}



-(UserProfile*)userProfileFilter:(NSString*)responseString{
    
    NSString *personPath = [[NSBundle mainBundle] pathForResource:@"Person" ofType:@"txt"];
    //Read to NSString object
    NSString *personContent = [NSString stringWithContentsOfFile:personPath encoding:NSUTF8StringEncoding error:NULL];
    //    NSLog(@"%@",personContent);
    //Convert to NSDictionary
    NSDictionary *personDataDictionary = [NSJSONSerialization JSONObjectWithData:[personContent dataUsingEncoding:NSUTF8StringEncoding]options:NSJSONReadingMutableContainers error:nil];
    
    //    NSLog(@"\n\n\n%@",personDataDictionary);
    
    //    NSDictionary *responseDictionary = [JsonResponseParser getParserData:responseString];
    //    NSLog(@"%@",responseDictionary);
    
    UserProfile *userProfile = [[UserProfile alloc] init];
    [userProfile setValuesForKeysWithDictionary:personDataDictionary];
    
    return userProfile;
}


-(DishInfo*)dishInfoFilter:(NSString*)responseString{
    
    DishInfo *dishInfo = [[DishInfo alloc] init];
    NSString *dataPath = [[NSBundle mainBundle] pathForResource:@"DishInfo" ofType:@"txt"];
    //Read to NSString object
    NSString *contentString = [NSString stringWithContentsOfFile:dataPath encoding:NSUTF8StringEncoding error:NULL];
    
    NSDictionary *contentDataDictionary = [NSJSONSerialization JSONObjectWithData:[contentString dataUsingEncoding:NSUTF8StringEncoding]options:NSJSONReadingMutableContainers error:nil];
    
    
    [dishInfo setValuesForKeysWithDictionary:contentDataDictionary];
    
    return dishInfo;
}


// DishPlace


-(NSArray*)dishListFilter:(NSArray*)placeArray{
    
    
    return nil;
}


-(ResponseStatus*)responseStatusFilter:(NSString*)responseString{
    
    ResponseStatus *responseObj = [[ResponseStatus alloc] init];
    
    NSDictionary *responseDictionary = [JsonResponseParser getParserData:responseString];
    NSLog(@"%@aplle", responseDictionary);
    [responseObj setValuesForKeysWithDictionary:responseDictionary];
    return responseObj;
    
}



- (NSArray *)followUserFilter:(NSString *)responseString{
    
    FollowUser *followUserObj = [[FollowUser alloc] init];
    NSDictionary *dataDict = [JsonResponseParser getParserData:responseString];
    //      NSLog(@"%@aplle", dataDict);
    [followUserObj setValuesForKeysWithDictionary:dataDict];
    
    NSArray *followFrndArray = followUserObj.object;
    NSLog(@"followFrndArray=%@",followFrndArray);
    
    
    return followFrndArray;
}

-(NSArray *)followingUserFiler:(NSString *)responseString{
    
    UserFollowing *userFollowingInfo = [[UserFollowing alloc] init];
    NSDictionary *dataDict = [JsonResponseParser getParserData:responseString];
    [userFollowingInfo setValuesForKeysWithDictionary:dataDict];
    NSArray *followingUserArray= userFollowingInfo.object;
    NSLog(@"followFrndArray=%@",followingUserArray);
    return followingUserArray;
    
}
@end
