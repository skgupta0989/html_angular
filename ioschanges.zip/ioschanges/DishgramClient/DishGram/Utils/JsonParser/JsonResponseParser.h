//
//  JsonResponseParser.h
//  DishGram
//
//  Created by Rags on 15/04/13.
//
//

#import <Foundation/Foundation.h>

@interface JsonResponseParser : NSObject

+(NSDictionary*)getParserData:(NSString*)dataString;

@end

