//
//  PersistantDataFactory.m
//  DishGram
//
//  Created by Ramesh Varma on 02/07/13.
//
//

#import "PersistantDataFactory.h"

@implementation PersistantDataFactory

PersistantData *dishSearch;
PersistantData *locationSearch;

+(PersistantData *)get:(NSString *)name {
    if ([name isEqualToString:HISTORY_DISH_SEARCH]) {
        if (dishSearch == nil) {
            dishSearch = [[PersistantData alloc] initWithName:HISTORY_DISH_SEARCH];
        }
        return dishSearch;
    } else {
        if (locationSearch == nil) {
            locationSearch = [[PersistantData alloc] initWithName:HISTORY_LOCATION_SEARCH];
        }
        return locationSearch;
    }
}

@end
