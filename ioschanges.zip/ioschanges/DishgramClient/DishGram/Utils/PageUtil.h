//
//  PageUtil.h
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import <Foundation/Foundation.h>

#import "DGOptionSet.h"
#import "PlaceCoords.h"
#import "RemovePostPromptView.h"
#import "ImageCropView.h"

#import "DishDraft.h"

#define DEFAULT_PROFILE_IMAGE_WIDTH 60
#define DEFAULT_PROFILE_IMAGE_HEIGHT  60

#define TAG_DEFAULT_BG 100

typedef NS_ENUM(NSInteger, FitType) {
    FitTypeStretch, // stretched to fit the frame
    FitTypeAspectVExpand, // stretches the frame vertically to fit the image
    FitTypeAspect, // fits the max dimention. blank space on both sides of image
    FitTypeAspectVClip // horizontal fit. clips vertically
};

typedef NS_ENUM(NSInteger, DecorationType) {
    DecorationTypeLoves = 0,
    DecorationTypeComment = 1,
    DecorationTypeAddComment = 2,
    DecorationTypeList = 3
    
};

// this class contains utility methods for performing common tasks required in multiple screens
@interface PageUtil : NSObject

// returns image view for profile picture.
+(UIImageView *)profileImageView;
+(UIImageView *)profileImageViewWithX:(int)x Y:(int)y;
+(UIImageView *)profileImageView:(CGRect)frame;
//
+(void)profileImageViewWithDefaultProfile:(UIImageView *)profileView url:(NSString*)URL addProfileHandler:(NSObject *)addProfileHandler;


// creates a image view with degault back ground
+(UIImageView *)defaultScalableTile:(int)width height:(int)height;
+(UIImageView *)defaultScalablePageTile:(int)width height:(int)height;
+(UIImageView *)scalablePageTile:(int)width height:(int)height forName:(NSString *)name;
+(UIImageView *)scalableShadedBGTile:(int)width height:(int)height forName:(NSString *)name;

// returns an image will specified star rating
// rating must be between 0 and 5
+(UIImage *)starRatingImage:(float)rating;

//returns separator line in table
+(UIView *)createSeparatorLineInTable:(CGRect)frame;

//common colour in all screens
+(UIColor*)getColor;


// returns an ImageView with default border
+(UIImageView *)defaultScalableBorderImage:(int)width height:(int)height;

// added specified image to parent. maintains a default border around the image
+(void)addImageWithFrame:(UIImageView *)parent image:(id)image;
+(void)addImageWithFrame:(UIImageView *)parent image:(id)image frameWidth:(int)frameWidth  fitType:(FitType)fitType;

// adds image to parent after making the image circular. Also a default border is maintained around the image
+(void)addCircularImageWithFrame:(UIImageView *)parent image:(id)image;

// returns proper logo image that can be used as place holder in dishImages.
+(UIImage *)getCroppedLogo;

+(void)makeImageCircular:(UIImageView*)imageView;

+(UIImageView *)shaedeBackgroundImage:(CGRect)frame;

// returns time elapsed from specified date to current time. returned value will be in user readable formate (Ex: 3 min ago, 2 months ego etc).
+(NSString *)dateToDays:(NSString *)date;

// loads a view from specified nib file. also decorates all the labels of type NVLabel.
+(UIView *)loadDecoratedView:(UIView *)target nibName:(NSString *)nibName;

// similar to reposition:(UIView *)target below:(UIView *)below withMargin:(float)margin with margin = 0;
+(void)reposition:(UIView *)target below:(UIView *)below;

// positions target below "below" view. a gap of margin will be maintained.
+(void)reposition:(UIView *)target below:(UIView *)below withMargin:(float)margin;

+(void)resize:(UIView *)target toEnvelop:(UIView *)sub;
+(void)resize:(UIView *)target toEnvelop:(UIView *)sub withMargin:(int)margin;

+(void)fetchPofileImageWithoutPlaceHolder:(UIImageView *)profileView
                                      url:(NSString *)url
                                   notify:(void (^)(bool result))notify;

+(void)fetchCoverImageWithoutPlaceHolder:(UIImageView *)profileView
                                     url:(NSString *)url
                                  notify:(void (^)(bool result))notify;

// similar to (void)fetchSquarePofileImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify addProfileHandler:(NSObject *)addProfileHandler without addProfileHandler. this method can used for circular profile images
+(void)fetchPofileImage:(UIImageView *)profileView
                    url:(NSString *)url
                 notify:(void (^)(bool result))notify;

// asynchronously fethes a profile image and sets it in the profileView. used for square images. Until the image is fetched, a place holder image (profile default image) is displayed. profileView - view where the image need to be placed. url - image source url. notify - block, which will be executed after the image is set. nil value can be passed if not interested in the notification. addProfileHandler - handler for receiving profile click events. addProfileHandler must implement a method "-(void)profileViewTapped" which will be called when user taps of profile (profileView)
+(void)fetchSquarePofileImage:(UIImageView *)profileView
                          url:(NSString *)url
                       notify:(void (^)(bool result))notify
            addProfileHandler:(NSObject *)addProfileHandler;

// asynchronously fethes a dish image and sets it in the dishView. Until the image is fetched, a place holder image (dishgram logo) is displayed. dishView - view where the image need to be placed. url - image source url. notify - block, which will be executed after the image is set. nil value can be passed if not interested in the notification. fitType - specifies how the image fits in the dishView. refer to FitType.
+(void)fetchDishImage:(UIImageView *)dishView
                  url:(NSString *)url
               notify:(void (^)(bool result))notify
              fitType:(FitType)type;

// adds profile handler to parent object. parent must implement a method "-(void)profileViewTapped" which will be called when user taps of profile (view)
+(void)addProfileHandler:(UIView *)view parent:(NSObject *)parent;


// shrinks the specified view so that it is not obstructed by the keyboard.
+(void)shrinkForKeyboard:(UIView *)view;

// expands the specified view to its full length after keyboard is hidden.
+(void)expandAfterKeyboard:(UIView *)view;

// adds top ribon to the specified view. default height and offset will be used. Also refer to addTopRibon:(UIView *)view withHeight:(int)height offSet:(int)offSet
+(void)addTopRibon:(UIView *)view;

// similar to addTopRibon:(UIView *)view. height and offSet of the ribon can be specified.
+(void)addTopRibon:(UIView *)view withHeight:(int)height offSet:(int)offSet;

// adds bottam graphics to specified view. used in ViewPost
+(void)pageBottomWithTag:(UIView *)view;

+(CGSize)calculateLabelWidthFromString:(NSString*)str andFont:(UIFont*)font;

// trims specified text field by removing white spaces
+(void)trimField:(UITextField *)view;

// decorates spefified view as per specified decoration name
+(void)decorate:(UIView *)view decorationName:(DecorationType)decoration;

// decorated addcomment text field
+(void)decorateAddCommentBox:(UITextField *)textField;

// scalable tile for restaurant info screens
+(UIImageView *)restHeaderScalableTile:(int)width height:(int)height;

// returns a toggle control for food/beverage options. target - target to be notified when user toggles. width - width of the control. height - height of the control. action - selector in the target to be called. userContext. Additional parameters to be passed which will used by DGOptionSet. refet to DGOptionSet/DGOPtionButton for more details.
+(DGOptionSet *)foodBeverageOptionSet:(NSObject *)tagert
                                width:(float)width
                               height:(float)height
                               action:(SEL)action
                              context:(NSMutableDictionary *)userContext;

// decorates specified view as per specification in Explore places and Acvanced search screens.
+(void)decorateExploreRootView:(UIView *)view;

// A list of matching locations are fetched using google API for spefified address (search string).
+(NSArray *)addressLocation:(NSString *)address;

// returns location address for spefied lat/long. Address is fetched using Google APIs.
+(NSString *)locationAddress:(double)lat lng:(double)lng;

// adds drop down below specified view. size - height of drop down. width is automatically set to view width. data - data(array of strings) to populated in the dropdown. delegate - delegate to be notified when user clicks on an item. font - font to be used for the dropdown item. numLines - number of lines per item. ddType - 1 and 2 are supprted values for 2 different drop down types.
+(void)addDropDownBelow:(UIView *)view
                   size:(int)size
                   data:(NSArray *)data
               delegate:(id)delegate
                   font:(NSString *)font
               numLines:(int)numLines
             ddTypeCode:(int)ddType;

// removes the dropdown view. Also refer to addDropDownBelow:(UIView *)view size:(int)size data:(NSArray *)data delegate:(id)delegate font:(NSString *)font numLines:(int)numLines ddTypeCode:(int)ddType
+(void)removeDropDown;

// added history section in specified view (inView). frame - fram eto used for histpry section. data - data (array of strings) to be populated in the history section. First element is considered the header. delegate - delegate to be notified when user clicks on one of the history items. font - font to be used for history items. headerFont - font of the header. numLines - number of lines (per item) to be displayed. Also refer to removeHistorySection:(UIView *)parentView.
+(void)addHistorySection:(CGRect)frame
                  inView:(UIView *)inView
                    data:(NSArray *)data
                delegate:(id)delegate
                    font:(NSString *)font
              headerFont:(NSString *)headerFont
                numLines:(int)numLines;

// remove the history section. History section is used in Search location/food functionality in Explore Screens. Also refer to addHistorySection:(CGRect)frame inView:(UIView *)inView data:(NSArray *)data delegate:(id)delegate font:(NSString *)font headerFont:(NSString *)headerFont numLines:(int)numLines
+(void)removeHistorySection:(UIView *)parentView;


// adds lat long to request parameters. This is a conveniant method for constructing request parameters before sending the request to server.
+(void)fillLocation:(NSMutableDictionary *)request;

// returns the lat/long (PlaceCoords) of current location. if use didnt select any location when device location is returned. In device location is not known then nil is returned. also refer to getSelectedLocation, getDeviceLocation
+(PlaceCoords *)getCurrentLocation;

// returns the lat/long(PlaceCoords) of current device location. nil if not known. also refer to getSelectedLocation, getCurrentLocation
+(PlaceCoords *)getDeviceLocation;

// returns currently selectd location lat/long (PlaceCoords). nil if not selected. also refer to getDeviceLocation, getCurrentLocation
+(PlaceCoords *)getSelectedLocation;

// sets the current location to specified lat/long (PlaceCoords)
+(void)setLocation:(PlaceCoords *)place;

// converts CLLocation to PlaceCoords also refer to placeCoordsToLocation:(PlaceCoords *)place
+(PlaceCoords *)locationToPlaceCoords:(CLLocation *)location;

// converts PlaceCoords to CLLocation also refer to locationToPlaceCoords:(CLLocation *)location
+(CLLocation *)placeCoordsToLocation:(PlaceCoords *)place;

// returns distance in Km or Miles (depending on user preference) from the current user selected location. distance is specified with 2 decimal places Ex: 12.03Km. NOTE: value returned will contain Km or Mi as its last to chars. If user didnt select any location and the current device location is not known, then NA will returned. Also refer to distanceFromCurDeviceLock:(PlaceCoords *)place PlaceCoords specifies lat/long.
+(NSString *)distanceFromCurLock:(PlaceCoords *)place;

// returns distance in Km or Miles (depending on user preference) from the current device location. distance is specified with 2 decimal places Ex: 12.03Km. NOTE: value returned will contain Km or Mi as its last to chars. If the current device location is not known, then NA will returned. Also refer to distanceFromCurLock:(PlaceCoords *)place. PlaceCoords specifies lat/long
+(NSString *)distanceFromCurDeviceLock:(PlaceCoords *)place;

// returns a Explore Dishes Screen tile with specified width and height
+(UIImageView *)defaultScalableExploreTile:(int)width height:(int)height;

// pushes specified controller onto current tabs navigation controller
+(void)push:(UIViewController *)vc;

// returns true if the user last selected his location as device vurrent location. Returns false if use searched and selected a location manually.
+(bool)isSelectedLocationDeviceLocation;

// retuns the last known location (usually GPS) of the device.
+(CLLocation *)getLastknownDeviceLocation;

// adds a horizontal dent like line on specified view. dentline is 2 lines (dark followed by light color line). position indicates the Y co-ordinate where the line is drawn. start and end X postiones are automatically determined based on view width. A fixed margin is left on left and right sides.
+(void)addHDent:(UIView *)view position:(int)position;

// trims the specified string by stripping the leading and trailing white spaces.
+(NSString *)trim:(NSString *)str;

// change height as per screen size. Screens are designed for 3.5 inch displays. If these screens wish to be stretched in 4inch screens then this method must be called. Ex: a screen of height 100 in 3.5inch display will use its height as int height =  [PageUtil getAdjustedHeight:100];
+(int)getAdjustedHeight:(int)baseHeight;

// hides the bottom tab bar. and stertches the specified view to fill the gap. also refer to showTabBar:(UIView *)stretch
+(void)hideTabBar:(UIView *)stretch;

// shows the (already hidden) bottom tab bar. and stertches the specified view to fill the gap. also refer to hideTabBar:(UIView *)stretch
+(void)showTabBar:(UIView *)stretch;

// returns the window instance from AppDelegate
+(UIView *)getWindow;

// For Setting Textfield Border and Color 227.0 227.0 227.0
+(void)setTextFieldBorder:(UITextField*)textField;

// added gray shadow at the top of specified view. Usefull in ViewPost screen.
+(void)addTopGrayShadow:(UIView *)view;

// places specified target view after nextTo view with spesified gap (margin) in between. this function is useful in adjusting varibale width views.
+(void)place:(UIView *)target nextTo:(UIView *)nextTo withMarging:(int)margin;

// places specified target view infront of infrontOf view with spesified gap (margin) in between. this function is useful in adjusting varibale width views.
+(void)place:(UIView *)target infrontOf:(UIView *)infrontOf withMarging:(int)margin;

// addes a vertical line in specifed context. start, end specify start and end y co-ordinates. color specifies color of the line.
+(void)addVLine:(int)vPosition
          start:(int)start
            end:(int)end
        context:(CGContextRef)context
          color:(UIColor *)color;

// similar to addVLine. adds solid horizontal line.
+(void)addHLine:(int)hPosition
          start:(int)start
            end:(int)end
        context:(CGContextRef)context
          color:(UIColor *)color;

// similar to addHLine. addes a dashed (broken) line.
+(UIImageView *)addDashedHLine:(int)hPosition
                         start:(int)start
                           end:(int)end
                         color:(UIColor *)color
                        ofView:(UIView *)view;




// pads specified text field with apprpriate margins on left side (value of the margin is a costant through out the app).
+(void)padTextField:(UITextField *)textField;

// sets atributed text in specified logo. directly setting text value will erase old attributes so this method provides a conveniant way of retaining old attributes
+(void)setAttributedText:(UILabel *)label string:(NSString *)string;

// redefines label frame so that text always appears centered in reference to original frame
+(void)centerLabel:(UILabel *)label;


// Setting Navigation Bar Title
+(UILabel*)navBarTitleWith:(NSString*)titleStr;

// moved the specified view if the device has 4inch screen. amount moved will be the differenc between height of 3.5 nd 4 inch screens.
+(void)moveDownIfRequired:(UIView *)view;

+(void)requiresLogin;

// returns true if the user is already logged in
+(BOOL)isLoggedin;

// sets user logged in status. every time user logs in or logs out, this muthod must be called by the responsible module
+(void)setLoggedin:(BOOL)loggedin;

+ (void)sendDeviceTokenToServer;

// addes the no data found (hanging board) image to the specified view
+(void)addNoDataFoundImage:(UIView *)view;

+(void)addNoDataFoundImage:(UIView* )view imageName:(NSString *)imageName;

// removes the no data found image from specified view. also refer to addNoDataFoundImage:(UIView *)view
+(void)removeNoDataFoundImage:(UIView *)view;

//rotates an image appprorpiately to handle orientation problems
+ (UIImage*) rotateImage:(UIImage* )src;

// rotates image view by specified degrees.
+ (UIImage *)rotateImage:(UIImage*)src degrees:(float)degrees;

//session invalid message
+(void)showAlertView:(NSString *)message;

// shows an alert to get confirmation from user for deleting a post.
+(void)showRemovePostAlertViewWithDelegate:(id<RemovePostPromptDelegate>)delegate;

// name of the event for sending/listent remove post events. dispPostId will be a part of the event name
+(NSString *)removePostEventName:(NSString *)postId;

// pops curretn view controller from navigation controller of current tab
+(void)popVC;

// displayes image crop view.
// image image to be cropped/rotated
// heightRatio - height to width ratio. a value on 0.5 means hieght will be half of width. It is guarantied that the return image will be in this ration even if the input image is smaller than the reuired dimentions.
// minHeight - minimum height of the cropped image. (minimum widht will be automatically calculated). user will not be able to select an area less than the specified height. If the image is smaller than the required dimentions, then maximum avaibale area is used as minHeight.
// maxHeight - returned image will have spicied maximum height. If user selects a region bigger than this height, then image will be resized (maintaining aspect ration) to fit to the required dimentions.
// delegate - delegate will be called when user clicks on cancel or crop buttons.
+(UIView *)showImageCropView:(UIImage *)image heightRatio:(float)heightRatio minHeight:(float)minHeight maxHeight:(float)maxHeight delegate:(id<CropDelegate>)delegate;

// crops image to specified rect
+(UIImage *)cropImage:(UIImage *)image toRect:(CGRect)rect;
// fetch circular Dish image
+(void)fetchCircularDishImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify;
// fetch circular image
+(void)fetchCircularImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify imagePlaceHolder:(UIImage *)placeHolder;
// Fetch square dish image
+(void)fetchSquareDishImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify addProfileHandler:(NSObject *)addProfileHandler;
// Fetch square imge
+(void)fetchSquareImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify addProfileHandler:(NSObject *)addProfileHandler imagePlaceHolder:(UIImage *)placeHolder;

//buffer first page of restaurant
+(void)bufferRestaurantNearToLocation;




/****
    return dishdraft object after intialization
 ****/
+(DishDraft *)newDishDraft;
//set image for draft
+(void)setImageForDishDraft:(DishDraft *)dishDraft image:(UIImage *)image;
//upload image for post
+(BOOL)uploadDishImageForPost:(DishDraft *)dishDraft;
//upload image for draft
+(BOOL)uploadDishImageForDraft:(DishDraft *)dishDraft;
@end
