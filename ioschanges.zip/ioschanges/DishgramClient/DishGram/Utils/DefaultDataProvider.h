//
//  DefaultDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 27/05/13.
//
//

#import "PagedDataProvider.h"

@interface DefaultDataProvider : NSObject<PagedDataProvider> {
    
}

@property (nonatomic, strong) NSString *url;
@property (nonatomic, strong) Class respType;

-(id)init:(NSString *)reqUrl respType:(Class)respTypeClass;
-(NSMutableDictionary *)getRequest;
-(NSMutableDictionary *)getRequest:(int)pageNo size:(int)pageSize;

// subclasses must override this method to handle connection errors.
-(void)onError:(NSString *)message;
-(NSObject *)getEntity;

@end
