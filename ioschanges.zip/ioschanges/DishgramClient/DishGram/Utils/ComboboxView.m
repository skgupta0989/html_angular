//
//  ComboboxView.m
//  DishGram
//
//  Created by Ramesh Varma on 02/07/13.
//
//

#import "ComboboxView.h"
#import "PageUtil.h"
#import "BorderedTextField.h"
#import "SearchBorderTextField.h"

@implementation ComboboxView
@synthesize textField_;
- (id)initWithFrame:(CGRect)frame data:(NSArray *)data ddSize:(int)ddSize placeHolder:(NSString *)placeHolder ddSize:(int)ddType;
{
    self = [super initWithFrame:frame];
    if (self) {
        ddSize_ = ddSize;
        ddType_ = ddType;       
        programSet_ = false;
        selected_ = NO;
        data_ = data;
        if (ddType_ == 1 || ddType_ == 2) {
             textField_ = [[SearchBorderTextField alloc] initWithFrame:CGRectMake(0,0,frame.size.width, frame.size.height)];
            textField_.textColor = [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0];
            textField_.font = [UIFont fontWithName:@"Roboto-Italic" size:12];
                       
        }else{
            textField_ = [[BorderedTextField alloc] initWithFrame:CGRectMake(0,0,frame.size.width, frame.size.height)];
            textField_.textColor = [UIColor blackColor];
        }
        textField_.autocorrectionType = UITextAutocorrectionTypeNo;
        //textField_.textColor = [UIColor lightTextColor];
        [self addSubview:textField_];       
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textChanged:) name:UITextFieldTextDidChangeNotification object:textField_];
        
        textField_.placeholder = placeHolder;
        
        //textField_.textColor = [UIColor whiteColor];
        textField_.delegate = self;
        [self decorate];       

    }
    return self;
}

-(void)decorate {
    UIImage *corner = [UIImage imageNamed:@"dropdown.png"];
    UIImageView *cornerView = [[UIImageView alloc] initWithFrame:CGRectMake(self.frame.size.width - corner.size.width, self.frame.size.height - corner.size.height, corner.size.width, corner.size.height)];
    cornerView.image = corner;
    cornerView.tag=33333;

    [textField_ addSubview:cornerView];
}

-(void)textChanged:(NSNotification *)notification {
    [PageUtil removeDropDown];
    
    if (!programSet_) {
             
        if (ddType_ == 1 || ddType_ == 2) {
            [PageUtil addDropDownBelow:textField_ size:ddSize_ data:[self getFilteredData] delegate:self font:@"_dropdown_address_Custom" numLines:1 ddTypeCode:ddType_];
        }else{
            [PageUtil addDropDownBelow:textField_ size:ddSize_ data:[self getFilteredData] delegate:self font:@"_dropdown_address_" numLines:1 ddTypeCode:ddType_];
        }
//        [PageUtil addDropDownBelow:textField_ size:ddSize_ data:[self getFilteredData] delegate:self font:@"_dropdown_address_" numLines:1 ddTypeCode:ddType_];
        selected_ = NO;
        self.selectedText = nil;
    } else {
        programSet_ = NO;
    }
}

-(NSArray *)getFilteredData {
    
    if (textField_.text == nil || [textField_.text isEqualToString:@""]) {
        filteredData_ = data_;
    } else {
        NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
            NSString *obj = (NSString *)evaluatedObject;
            return !([obj rangeOfString:textField_.text options:NSCaseInsensitiveSearch].location == NSNotFound);
        }];
        
        filteredData_ = [data_ filteredArrayUsingPredicate:predicate];
    }
    
    return filteredData_;
}


- (BOOL)dropDownView:(DropDownView *)dropDownView selectedIndex:(int)selectedIndex {
    selected_ = YES;
    self.selectedText = [filteredData_ objectAtIndex:selectedIndex];
    textField_.text = self.selectedText;
    [PageUtil removeDropDown];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    [UIView animateWithDuration:0 animations:^{
        if ([_delegate respondsToSelector:@selector(textFieldBeginEditing:)]) {
            [_delegate textFieldBeginEditing:self];
        }
        
    }completion:^(BOOL ani){
        [PageUtil removeDropDown];
       
        if (ddType_ == 1 || ddType_ == 2) {
            [PageUtil addDropDownBelow:textField_ size:ddSize_ data:[self getFilteredData] delegate:self font:@"_dropdown_address_Custom" numLines:1 ddTypeCode:ddType_];
        }else{
            [PageUtil addDropDownBelow:textField_ size:ddSize_ data:[self getFilteredData] delegate:self font:@"_dropdown_address_" numLines:1 ddTypeCode:ddType_];
        }
        //[PageUtil addDropDownBelow:textField_ size:ddSize_ data:[self getFilteredData] delegate:self font:@"_dropdown_address_" numLines:1 ddTypeCode:ddType_];
        
    }];
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    [PageUtil removeDropDown];
    return YES;
}
-(BOOL)isSelectionIsFromTheList{
    if ([[self getFilteredData] count]==0) {
        return NO;
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([self isSelectionIsFromTheList]) {
        
        if ([_delegate respondsToSelector:@selector(textFieldReturn:)]) {
            [_delegate textFieldReturn:self];
        }
        return YES;
    }else{
        [[[iToast makeText:@"Please Select content from the list"] setGravity:iToastGravityCenter] show];
        return NO;
    }

    return YES;
}

#pragma mark-
- (void)textFieldBeginEditing{
    [textField_ becomeFirstResponder];
}

-(void)dealloc{
    textField_.delegate = nil;
    @try {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}
@end
