//
//  CacheManager.m
//  DishGram
//
//  Created by User on 5/3/13.
//
//

#import "CacheManager.h"

@implementation CacheManager

@synthesize name = _name;
@synthesize callBackDelegate = _callBackDelegate;

-(id)initWithMaxSize:(int)maxSize andName:(NSString *)name {
    self = [super init];
    self.name = name;
    _maxSize = maxSize;
    _objs = [[NSMutableDictionary alloc] initWithCapacity:maxSize];
    _objPositions = [[NSMutableArray alloc] initWithCapacity:maxSize];
    return self;
}

-(void)addKey:(NSString *)key andVal:(id)value {
    // NSLog(@"%@",self.name);
    // NSLog(@"%@",key);

    @synchronized(_objs) {
        [_objs setValue:value forKey:key];
        [_objPositions insertObject:key atIndex:0];
    }
    [self cleanCache];
}

// check and remove last object if needed
-(void)cleanCache {
    @synchronized(_objs) {
        if ([_objPositions count] > _maxSize) {
            // remove last object from array and corresponding key/value
            // from dictonary
            NSString *key = [_objPositions lastObject];
            // NSLog(@"######### key = %@", key);
            [_objs removeObjectForKey:key];
            [_objPositions removeLastObject];
      
            // check and call back on delegate
            if (self.callBackDelegate != nil && [self.callBackDelegate respondsToSelector:@selector(objDeleted:from:)]) {
                [self.callBackDelegate objDeleted:key from:self.name];
            }
        }
    }
    
}

// returns the cached object. In _objPositions, key is pulled up
// to index 0.
-(id)get:(NSString *)key {
    @synchronized(_objs) {
        id obj = [_objs objectForKey:key];
        if (obj != nil) {
            // pull the object to 0 postion on stack
            [_objPositions removeObject:key];
            [_objPositions insertObject:key
                            atIndex:0];
        }
        return obj;
    }
}

-(void)dealloc {
    _objs = nil;
    _objPositions = nil;
    self.name = nil;
    self.callBackDelegate = nil;
    
#if !(__has_feature(objc_arc))
    [super dealloc];
#endif
}

@end
