//
//  MutableDefaultDataProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 04/06/13.
//
//

#import "MutableDefaultDataProvider.h"
#import "DataSourceFactory.h"
#import "DataSourceInterface.h"
#import "DishInfo.h"
#import "Utilities.h"

// Web request pamameter maximum results expected
#define DATA_SIZE @"max"

// Web request parameter for paginated data. offset is the starting position from where the next set of results are returned
#define DATA_START_INDEX @"offset"


@implementation MutableDefaultDataProvider

@synthesize url;
@synthesize pagedDataView;

-(id)init:(NSString *)reqUrl respType:(Class)respTypeClass removeUrl:(NSString *)removeUrl {
    self = [super init];
    if (self) {
        self.url = reqUrl;
        self.respType = respTypeClass;
        self.removeUrl = removeUrl;
        self.isState = NO;
    }
    return self;
}

-(id)init:(NSString *)reqUrl respType:(Class)respTypeClass {
    self = [super init];
    if (self) {
        self.url = reqUrl;
        self.respType = respTypeClass;
        self.isState = NO;
    }
    return self;
}

// makes request params object with no params
-(NSMutableDictionary *)getRequest {
    NSMutableDictionary *request = [[NSMutableDictionary alloc] init];
    return request;
}

// Adds page number and size to request
-(NSMutableDictionary *)getRequest:(int)index size:(int)size {
    NSMutableDictionary *request = [self getRequest];
    
    [request setObject:[NSString stringWithFormat:@"%d", index] forKey:DATA_START_INDEX];
    [request setObject:[NSString stringWithFormat:@"%d", size] forKey:DATA_SIZE];
    return request;
}

-(NSObject *)getEntity {
    @autoreleasepool {
        
        NSMutableDictionary *request = [self getRequest];
        DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
        
        // following code makes the network request synchronous
        NSObject __block *responseObj = nil;
        NSCondition *requestLock = [[NSCondition alloc] init];
        [requestLock lock];
        
        __weak typeof(self) weakSelf = self;
        [dataSource requestDataWithURLString:url params:request modelClass:self.respType callBack:^(bool success, NSObject *response) {
            [requestLock lock];
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf) {
                responseObj = response;
                if (!success) {
                    if (![((NSString *)response) isEqualToString:TOKEN_DOES_NOT_EXIST]) {
                        [strongSelf onError:(NSString *)response];
                    }
                }
            }
            // wake up the main thread
            [requestLock signal];
            [requestLock unlock];
        }];
        // wait until network call returns
        [requestLock wait];
        [requestLock unlock];
        return responseObj;
    }
}

-(NSArray *)getPage:(int)startIndex size:(int)size {
    @autoreleasepool {
        NSMutableDictionary *request = [self getRequest:startIndex size:size];
        DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
        
        // following code makes the network request synchronous
        NSArray __block *responseArray = nil;
        NSCondition *requestLock = [[NSCondition alloc] init];
        [requestLock lock];
        NSLog(@"Req=%@",request);
        
        __weak typeof(self) weakSelf = self;
        [dataSource requestDataWithURLString:url params:request modelClass:self.respType callBack:^(bool success, NSObject *response) {
            
            NSLog(@"Success=%d",success);
            NSLog(@"Object=%@",response);
            [requestLock lock];
            __strong typeof(weakSelf) strongSelf = weakSelf;
            
            if (strongSelf.isState) return;
            
            [strongSelf gotResponse];
            if (strongSelf) {
                if (success) {
                    responseArray = (NSArray *)response;
                    if([responseArray count]==0){
                        [strongSelf responseIsNil];
                        if (startIndex == 0 || startIndex == 1) {
                            [strongSelf noResultsFound];
                        }
                    }
                } else {
                    if (![((NSString *)response) isEqualToString:TOKEN_DOES_NOT_EXIST]) {
                        [strongSelf onError:(NSString *)response];
                    }
                }
            }
            // wake up the main thread
            [requestLock signal];
            [requestLock unlock];
        }];
        // wait until network call returns
        [requestLock wait];
        [requestLock unlock];
        
        NSArray *retArray = responseArray;
        responseArray = nil;
        [[NSNotificationCenter defaultCenter] postNotificationName:DATA_FETCH_COMPLETE object:self];
        return retArray;
    }
}


-(void)remove:(NSObject *)data {
    NSMutableDictionary *request = [self getRemoveRequest:data];
    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    [dataSource requestDataWithURLString:self.removeUrl params:request modelClass:nil callBack:[self getRemoveCallback]];
}

// override this method in subclasses to perform some post delete operations
-(void (^)(bool success, NSObject *response))getRemoveCallback {
    return nil;
}

// override this method in subclasses to handle connection errors.
-(void)onError:(NSString *)message {
    
}

// sub classes must overide this method
-(NSMutableDictionary *)getRemoveRequest:(NSObject *)data {
    return nil;
}

-(void)responseIsNil {
    
}

-(void)noResultsFound {
    if (self.pagedDataView != nil) {
        [self.pagedDataView noDataFound];
    }
}

-(void)noResultsFoundWithImage:(NSString*)imageName{
    if (self.pagedDataView != nil) {
        [self.pagedDataView noDataFoundImage:imageName];
    }
}

// sub classes can override this method to get notified when a response is received
-(void)gotResponse {
    [self.pagedDataView.templateProvider replaceRowDataProvider];
}

@end
