//
//  DataSingleton.h
//  DishGram
//
//  Created by Satish on 4/29/13.
//
//

#import <Foundation/Foundation.h>

@interface DataSingleton : NSObject
+(NSString*)stringValueForKey:(NSString*)keyVal;
+(BOOL)validateCharacter:(NSString*)stringParam;

@end
