//
//  StringConstant.h
//  DishGram
//
//  Created by Satish on 5/13/13.
//
//

#ifndef DishGram_StringConstant_h
#define DishGram_StringConstant_h


#define DISHGRAM_QUOTES           @"\"DishGram\""


#define ENTER_EMAIL_ID          @"Enter an Email ID"
#define FOLLOW_UR_FRNDS         @"Follow Your Friends"
#define PROMOTE_UR_FRNDS        @"Promote"


#define USER_NAME               @"Username"
#define EMAIL                   @"Email"
#define PASSWORD                @"Password"
#define REGISTER                @"Register"
#define ENTER_REGISTRED_MAIL    @"Enter Registered Email"
#define LOGIN_STR               @"Login"
#define FORGOT_PASSWORD_STR     @"Forgot Password"
#define FOLLOWERS_CAPS          @"Followers"
#define FACEBOOK_CAPS           @"Facebook"
#define TWITTER_CAPS            @"Twitter"
#define TUMBLR_CAPS             @"Tumblr"
#define FOUR_SQUARE_CAPS        @"Foursquare"
#define FRIENDS_CAPS            @"Friends"
#define CONTACTS_CAPS            @"Contacts"




#define LET_UR_FRNDS_KNOW_MSG   @"Let your friends know that you are using"

#define ENTER_AN_EMAILID        @"Enter an Email ID"

#define ENTER_A_USERNAME       @"Enter a Username"

#define ENTER_VALID_USERNAME @"Enter a Valid Username"

#define ENTER_A_VALID_MAILID   @"Enter a Valid Email"

#define ENTER_A_PASSWORD        @"Enter a Password"

#define  PASSWORD_SHOULD_BE_LONG   @"Your password must be at least 6 characters long"

#define ROBOTO_CONDENSED     @"Roboto-Condensed"



//dish detail


#define DISH_NAME @"Dish Name"
#define DISH_CUISINE @"Cuisine"
#define DISH_DESCRIPTION @"Description"



#endif
