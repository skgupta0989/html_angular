//
//  Constant.h
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#ifndef DishGram_Constant_h
#define DishGram_Constant_h


#define REGISTRATIONSTRING   @"{\"status\" : \"SUCCESS\", \"message\": \"SUCCESSFULLY\", \"object\": {\"tokenKey\": \"d645342c3455\"}}"


#define LOGINSTRING    @"{\"status\" : \"SUCCESS\", \"message\": \"SUCCESSFULLY\", \"object\": {\"tokenKey\": \"d645342c3455\"}}"


#define SOCIALNETWORKLOGINSTRING @"{\"status\" : \"SUCCESS\", \"message\": \"SUCCESSFULLY\", \"object\": {\"tokenKey\": \"d645342c3455\"}}"


#define FOLLOWUSERSTRING    @"{\"status\": \"SUCCESS\", \"message\": \"SUCCESS\"}"



#define USERPROFILESTRING   @"{\"status\": \"SUCCESS\",\"message\": \"SUCCESS\",\"object\": {    \"email\": \"sunny1@neev.com\",    \"usernam\": \"SUNNY1\",    \"token\": \"4a25a0652bc5a9c58a90358a77a2a094\",    \"userImages\": [                   {                       \"uid\": 10,                       \"userImageType\": {                           \"uid\": 2,                           \"name\": \"Profile\"                       }                   },                   {                       \"uid\": 8,                       \"userImageType\": {                           \"uid\": 2,                           \"name\": \"Profile\"                       }                   },                   {                       \"uid\": 9,                       \"userImageType\": {                           \"uid\": 2,                           \"name\": \"Profile\"                       }                   },                   {                       \"uid\":                        \"userImageType\": {                           \"uid\": \"followers\": 1,\"following\":              \"uid\":              \"                 \"uid\":                  \"dishName\": \"Beef Pepper                  \"defaultDescription\": null,                 \"dateCreated\": \"2013-04-09T14:25:17Z\"             },             \"dishPlaceDescription\": \"Treat              \"dateCreated\": \"2013-04-16T11:57:44Z\",             \"place\": {                 \"address1\": \"20, New Vasavi Nagar Colony, Karkhana\",                 \"address2\": \"20, New Vasavi Nagar Colony, Karkhana, Secunderabad, Andhra Pradesh, India\",                 \"latitude\": 17.434726,                 \"longitude\": 78.                 \"phone\":                  \"name\": \"Jeet's                  \"description\": \"Default                  \"dateCreated\": \"2013-04-09T14:17:30Z\",                 \"zipCode\": {                     \"zip\": \"560026\",                     \"                         \"cityName\": \"Secunderabad\",                         \"                             \"stateName\": \"Andhra              \"                                \"             \"                               \"uid\":                                \"                                   \"email\": \"sunny1@neev.                                   \"username\": \"SUNNY1\",                                   \"token\": \"4a25a0652bc5a9c58a90358a77a2a094\",                                   \"userImages\": [                                                  {                                                      \"uid\": 10,                                                      \"user                                                      \"uid\":                                                       \"userImageType\": {                                                          \"uid\": 2,                                                          \"                                                  },                                                  {                                                      \"uid\":                                                       \"user                                                      \"uid\": 4,                                                      \"userImageType\": {                                                          \"uid\": 2,                                                          \"         }]}}"






#define GETDISHLISTSTRING @"{\"status\": \"SUCCESS\",\"message\": \"SUCCESS\",\"object\": [{\"id\": 2,\"dishPlaceDescription\": \"McAloo Tikki\",\"dateCreated\": \"2013-04-10T10:08:50Z\",\"dishLovesCount\": 1,\"dishComments\": 1,\"dishImages\": [{\"id\": 2}],\"place\": {\"address1\": \"Beside Aradhana Theatre, Taranka\",\"address2\": \"Beside Aradhana Theatre, Taranka, Secunderabad , Andhra Pradesh, India\",\"latitude\": 17.434825,\"longitude\": 78.476165,\"phone\": null,\"name\": \"Good Lands Restaurant\",\"description\": \"Default description\",\"dateCreated\": \"2013-04-09T14:17:30Z\",\"zipCode\": {\"zip\": \"500017\",\"city\": {\"cityName\": \"Secunderabad\",\"state\": {\"stateName\": \"Andhra Pradesh\",\"country\": {\"countryName\": \"Ireland\"}}}}},\"dish\": {\"id\": 7,\"dishName\": \"Bubble Tea\",\"defaultDescription\": null,\"dateCreated\": \"2013-04-09T14:25:17Z\"},\"user\": {\"id\": 3,\"username\": \"SUNNY3\",\"userImages\": []},\"viewCount\": 5,\"rating\": 5}]}"

#define SAMPLESTRING @"{\"status\": \"SUCCESS\",\"message\": \"SUCCESS\",\"object\": {\"email\": \"sunny1@neev.com\",\"username\": \"SUNNY1\",\"token\": \"4a25a0652bc5a9c58a90358a77a2a094\",\"userImages\": [{\"uid\": 4,\"userImageType\": {\"uid\": 2,\"name\": \"Profile\"}}]}}"



#endif
