//
//  Header.h
//  DishGram
//
//  Created by Rags on 15/04/13.
//
//

#ifndef DishGram_Header_h

#import "iToast.h"
#import "Utilities.h"
#import "GPUImage.h"
#define DishGram_Header_h


#define FACEBOOK_CALL_BACK_URL  @"fb597051696974513"

// Local for development
// #define URL_PREFIX @"http://10.0.17.41:9090/dishgram"

// Public server
// #define URL_PREFIX @"http://dishgram.neevtech.com/dishgram"

// EC2 - 8080
// #define URL_PREFIX @"http://ec2-54-254-134-249.ap-southeast-1.compute.amazonaws.com:8080/dishgram"

// EC2 - 9090
//#define URL_PREFIX @"http://ec2-54-254-134-249.ap-southeast-1.compute.amazonaws.com:9090/dishgram"

// Dishgram- Production
#define URL_PREFIX @"http://app.dishgram.com:8080/dishgram"

#define REGISTRATION_URL                    @"/user/register"
#define LOGIN_URL                           @"/user/login"
#define FORGOT_PASSWORD_URL                 @"/user/forgotPassword"
#define FOLLOW_USER_URL                     @"/user/followUser"
#define GET_FOLLOWUSERS_INFO                @"/user/FollowUpUsers"
#define PLACEBYSUGGESTION                   @"/place/getPlaceBySuggesion"
#define PLACEBYDISTANCE                     @"/place/getPlaceByDistance"
#define UPLOAD_DISH_IMAGE_URL               @"/postsShare/uploadDishImage"
#define UPLOAD_DRAFT_IMAGE_URL              @"/draft/saveImageAsDraft"
#define POST_DRAFT_URL                      @"/draft/postDraft"
#define UPLOAD_DISH_DETAIL_URL              @"/postsShare/postDishDetail"
#define GET_AUTOFILL                        @"/postsShare/getAutofillList"
#define SAVE_DETAIL_AS_DRAFT                @"/draft/saveDetailsAsDraft"
#define REGISTRATION_URL                    @"/user/register"
#define LOGIN_URL                           @"/user/login"
#define FORGOT_PASSWORD_URL                 @"/user/forgotPassword"
#define FOLLOW_USER_URL                     @"/user/followUser"
#define GET_FOLLOWUSERS_INFO                @"/user/FollowUpUsers"
#define USER_PROFILE_URL                    @"/user/getUserProfile"
#define GET_DISH_LIST_URL                   @"/dishPlaces/getDishList"
#define GET_INFO_URL                        @"/dishPlaces/getDishInfo"
#define GET_PROFILE_URL                     @"/user/getProfile"
#define GET_ALL_POST_URL                    @"/user/getAllPosts"
#define GET_ALL_LOVES_URL                   @"/user/getAllLoves"
#define GET_ALL_DRAFT_URL                   @"/draft/getDraftList"
#define LOVE_DISH_POST_URL                  @"/dishLove/loveDish"
#define REPORT_ABUSE_URL                    @"/postFlag/reportAbuse"
#define GET_ALL_DISH_LOVERS                 @"/dishPlaces/getAllDishLovers"
#define GET_ALL_DISH_COMMENTS               @"/dishPlaces/getAllComments"
#define GET_FOLLOW_PLACE_URL                @"/place/followPlace"
#define GET_SUGGESTED_USERS_URL             @"/user/getSuggestedUsers"
#define ADD_COMMENT_POST_URL                @"/dishComment/commentDish"
#define GET_LANDING_IMAGES_URL              @"/place/getLandingImages"
#define GET_USERFOLLOWINGS_COUNT            @"/user/getFollowingsCounts"
#define GET_DISH_PLACE_INFO                 @"/place/getPlaceInfo"
#define GET_ALL_DISHS_BY_PLACE              @"/place/getAllDishesByPlace"
#define GET_FOLLOWING_USER                  @"/user/getFollowings"
#define GET_FOLLOWING_RESTAURANT_URL        @"/place/getFollowingResturants"
#define GET_DISH_BY_LAT_LONG                @"/dish/getExploreDishes"
#define DISH_ADVANCED_SEARCH                @"/dish/dishAdvanceSearch"
#define GET_PLACE_BY_LAT_LONG               @"/place/getExplorePlaces"
#define GET_CUISINE_LIST                    @"/postsShare/getCuisineList"
#define GET_MAP_INFO                        @"/place/getMapInfo"
#define GET_MAP_PLACES                      @"/place/getPlacesForMap"
#define GET_MAP_DISHES                      @"/place/getDishesForMap"
#define GET_USER_FOLLOWERS_URL              @"/user/getUserFollowers"
#define GET_RECOMMEND_DISH_TO_USER_URL      @"/recommendDish/recommendDishToUser"
#define GET_RECOMMEND_DISH_EMAIL_URL        @"/recommendDish/sendRecommendationEmail"
#define PROMOTE_BY_EMAIL_URL                @"/invite/promoteByEmail"
#define INVITE_BY_EMAIL_URL                 @"/user/sendInvitation"
#define SHARE_BY_EMAIL_URL                  @"/postsShare/shareByEmail"
#define GET_LATEST_FEED                     @"/dishPlaces/getLatestFeed"
#define GET_LATEST_MY_FEED                  @"/dishPlaces/getMyLatestFeed"
#define GET_RESETPASSWORD_URL               @"/user/resetPassword"
#define DISCARD_USER_POST                   @"/draft/discardPost"
#define GET_DRAFT_DETAIL                    @"/draft/getDraftById"
#define EDIT_MY_PROFILE_URL                 @"/user/editMyProfile"
#define  SET_NOTIFICATION_EMAIL_URL         @"/user/setNotification"
#define GET_NOTIFICATIONSTATUSFOREMAIL_URL  @"/settings/getNotificationStatus"
#define EDIT_PROFILE_IMAGE_URL              @"/user/editProfileImage"
#define GET_PROFILE_DETAIL_URL              @"/user/getProfileDetails"
#define SEND_TOKEN_URL                      @"/user/saveOrDeleteGcmKey"
#define LOGOUT_URL                          @"/user/logout"
#define REMOVE_POST_URL                     @"/dishPlaces/deletePost"
#define GET_USER_POST_COUNT_URL             @"/user/getUserPostCount"


#define LiveState               true // Declare 0 for Dummy and 1 for Live

#define DISHGRAM_LOGIN          @"Dishgram"
#define FACEBOOK_LOGIN          @"Facebook"
#define DISHGRAM_APP_TOKEN      @"9867852635163"

#define REGISTRATION            1
#define LOGIN                   2
#define SOCIAL_NETWORK_LOGIN    3
#define FORGOT_PASSWORD         4
#define FOLLOW_USER             5
#define USER_PROFILE            6
#define GET_DISH_LIST           7
#define FOLLOW                @"follow"
#define UNFOLLOW              @"Unfollow"
#define FAILURE             @"FAILURE"
#define SUCCESS             @"SUCCESS"
#define HOSTNAME @"www.google.com"
#define NETWORKREACHABILITYALERT @"No Network Available Please connect"
#define TRUE1    @"true"
#define FALSE1 @"false"
#define FOLLOWFRIENDSALERT  @"No friends connected to your facebook account"

#define USER_OATH_ID        @"abcd"

#define VEG @"Veg"
#define NONVEG @"Non-Veg"
#define ALCOHOLIC @"Alcoholic"
#define NONALCOHOLIC @"Non-Alcoholic"

#define TOKEN @"token"
#define USERID     @"uid"
#define TAG_DISH_IMAGE_VIEW 1001
#define TAG_PROFILE_IMAGE_VIEW 1002
#define TAG_EXPLORE_DISH_TABLE_VIEW 1003
#define TAG_EXPLORE_PLACES_TABLE_VIEW 1004
#define TAG_EXPLORE_HEADER_VIEW 1005
#define TAG_SEARCH_LOCATION_VIEW 1006
#define TAG_SEARCH_FOOD_VIEW 1007
#define TAG_ADVANCED_SEARCH_VIEW 1008
#define TAG_DROP_DOWN_VIEW 1009
#define TAG_HISTORY_SECTION_VIEW 1010
#define TAG_REPORT_ABUSE_VIEW 1011
#define TAG_MAP_VIEW 1012
#define TAG_TOP_SHADOW 1013
#define TAG_VP_PAGE_BOTTOM 1014
#define TAG_LOGIN_PROMPT_VIEW 1015
#define TAG_ACTIVITY_FEED_XIB_VIEW 1016
#define TAG_NVP_TEMPLATE_VIEW 1017
#define TAG_FLAG_IMAGE 1018
#define TAG_NO_DATA_FOUND_IMAGE 1019
#define TAG_REMOVE_IMAGE 1020
#define TAG_REMOVE_POST_PROMPT_VIEW 1021
#define TAG_IMAGE_CLIP_VIEW 1022


#define POST_TEMPLATE_XIB_TAG  1111


#define BUTTON_UN_SELECTED_IMAGE [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"post_sml_normal" ofType:@"png"]]
#define BUTTON_SELECTED_IMAGE [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"post_sml_active" ofType:@"png"]]



#define SESSION_PLACE_INFO_RD @"SESSION_PLACE_INFO_RD"
#define SESSION_REST_INFO_DISH_NAME @"SESSION_REST_INFO_DISH_NAME"
#define SESSION_CUR_PLACE @"SESSION_CUR_PLACE"
#define SESSION_CUR_PLACE_TYPE @"SESSION_CUR_PLACE_TYPE"
#define SESSION_CUR_PLACE_TYPE_DEVICE_LOC @"SESSION_CUR_PLACE_TYPE_DEVICE_LOC"
#define SESSION_CUR_PLACE_TYPE_SELECTED @"SESSION_CUR_PLACE_TYPE_SELECTED"

#define GOOGLE_MAP_SEARCH_URL @"http://maps.googleapis.com/maps/api/geocode/json?address=%@&sensor=false"

#define k_BACKVIEW_TAG 123443
#define GOOGLE_MAP_REVERSE_GEOCODE_URL @"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=false"
#define FB_COVER_IMAGE @"FB_CoverImage"
#define FB_EMAIL @"FB_email"
#define FB_USER_NAME @"user_name"
#define FB_UID  @"FB_UID"
#define FB_PROPILE_IMAGE @"FB_ProfileImage"

// settingStatus

#define GET_DISTANCE_STATUS @"GET_DISTANCE_STATUS"
#define GET_NOTIFICATION_STATUS @"GET_NOTIFICATION_STATUS"
#define GET_SOUND_STATUS @"GET_SOUND_STATUS"
#define GET_EMAIL_STATUS @"GET_EMAIL_STATUS"
//device token
#define k_DEVICE_TOKEN @"deviceToken"


#define FRAME_IPHONE_N_5 CGSizeMake(294, 255)
#define FRAME_IPHONE_5  CGSizeMake(294,314)


#endif


#ifdef DEBUG
#   define DLog(fmt, ...) {NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);}
#   define ELog(err) {if(err) DLog(@"%@", err)}
#else
#   define DLog(...)
#   define ELog(err)
#endif

#define IS_PHONE5() ([UIScreen mainScreen].bounds.size.height == 568.0f && [UIScreen mainScreen].scale == 2.f && UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)