//
//  Utilities.m
//  DishGram
//
//  Created by Rags on 23/04/13.
//
//

#import "Utilities.h"
#import "CustomBtnAndLabel.h"

#import "ImageData.h"
#import "QuartzCore/QuartzCore.h"

#import "Token.h"
#import "AppDelegate.h"
#import "KVCObject.h"
#import "DGScrollView.h"

@implementation Utilities

static bool isAlertActive=false;

@synthesize isAlertActive;

- (NSDate *)convertFromStringToDate:(NSString *)dateString{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MMMM-DD-YYYY"];
    NSDate *date = [dateFormatter dateFromString:@"2013-04-09T14:17:30Z"];
//    NSLog(@"date=%@",date);
    return date;
    
}

// email validation
+ (BOOL) validateEmail: (NSString *) candidate
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}

+(void)showAlertMessage:(NSString *)msg andDelegate:(id)delegate{
    
    // UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:msg delegate:delegate cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //[alert show];
    
    
}
#pragma mark-
#pragma mark- common animation 
+(void)movingView:(UIView *)view toFrame:(CGRect)newFrame duration:(float)duration callback:(id)delegate selectore:(SEL)selector{
    [UIView animateWithDuration:duration animations:^{
        
        view.frame=newFrame;
        
    } completion:^(BOOL finished) {
        if (delegate!=nil) {
            [delegate performSelector:selector];
        }
    }];

}
+(BOOL)isAlertActive{
    return isAlertActive;
}
+(void)setIsAlertActive:(BOOL)isAlert{
    isAlertActive=isAlert;
}

 

#pragma mark-
#pragma mark- Bounce animation for  customButtonandLabel(CustomizedButton)
+ (void)BounceLogoButtonAnimationsWithStartFrame:(CGRect)startPosition  endPosition:(CGRect)endPosition WithButton:(CustomBtnAndLabel *)button{
    
    float offsetForBounce = 1.15;
    [UIView animateWithDuration:0.2 animations:^{
        
        float newX = startPosition.origin.x + (endPosition.origin.x - startPosition.origin.x)*(offsetForBounce);
        float newY = startPosition.origin.y + (endPosition.origin.y - startPosition.origin.y)*(offsetForBounce);
        
        button.frame=startPosition;
        
        CGRect newendFrame;
        newendFrame = CGRectMake(newX, newY, endPosition.size.width, endPosition.size.height);
        button.hidden=NO;
        button.frame = newendFrame;
        
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:0.1 animations:^{
            CGRect newendFrame = CGRectMake(endPosition.origin.x, endPosition.origin.y, endPosition.size.width, endPosition.size.height);
            button.frame =newendFrame;
            
            
        }];
        
    }];
    
    
    
}
#pragma mark-
#pragma mark-Bounceanimation  to normalanimation for customButtonandlabel(CustomizedButton)

+ (void)normalLogoButtonAnimationsWithStartFrame:(CGRect)startPosition  endPosition:(CGRect)endPosition WithButton:(CustomBtnAndLabel *)button{
    
    [UIView animateWithDuration:0.3 animations:^{
        
        button.frame=startPosition;
        CGRect newendFrame;
        newendFrame = CGRectMake(endPosition.origin.x, endPosition.origin.y, endPosition.size.width, endPosition.size.height);
        button.frame = newendFrame;
        
        
        
    } completion:^(BOOL finished) {
        button.hidden=YES;
    }];
    
    
}

#pragma mark- creation of customizedbutton with text and Button

+(CustomBtnAndLabel *) prepareButtonWithText:(NSString *) text imageName:(NSString *)imageName tag:(int) tag frame:(CGRect)frame andDelegate:(id)delegate{
    
    CustomBtnAndLabel *button = [[CustomBtnAndLabel alloc] initWithFrame:frame];
    [button.buttons setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [button.buttons setTitle:text forState:UIControlStateNormal];
    [button.buttons setTitle:text forState:UIControlStateSelected];
    [button.buttons.titleLabel setFont:[UIFont fontWithName:@"Roboto-Medium" size:12]];
    button.buttons.titleLabel.text=text;
    button.buttons.titleLabel.lineBreakMode=YES;
    button.buttons.titleLabel.numberOfLines=2;
    button.delegate=delegate;
    button.buttons.tag=tag;
    button.hidden=YES;
    return button;
}

#pragma mark-Normal Animation
+ (void)moveAnimationForButtons:(CGRect)startPosition endPosition:(CGRect)endPosition withButton:(UIButton *)button {
    [UIView animateWithDuration:0.20 animations:^{
        
        button.frame=startPosition;
        CGRect newendFrame;
        newendFrame = CGRectMake(endPosition.origin.x, endPosition.origin.y, endPosition.size.width, endPosition.size.height);
        button.frame = newendFrame;
//        button.hidden=YES;
        
        
    } completion:^(BOOL finished) {
        button.hidden=YES;
    }];
    
    
    
}
#pragma mark-
#pragma mark-Bounce animation
+ (void)bounceAndMoveAnimationForButtons:(CGRect)startPosition endPosition:(CGRect)endPosition withButton:(UIButton *)button{
    
    [UIView animateWithDuration:0.15 animations:^{
        
        button.frame=startPosition;
        CGFloat offset = .4*(endPosition.origin.y - startPosition.origin.y);
        CGFloat offsetX = .4*(endPosition.origin.x - startPosition.origin.x);
        CGRect newendFrame;
        newendFrame = CGRectMake(endPosition.origin.x + offsetX, endPosition.origin.y+offset, endPosition.size.width, endPosition.size.height);
        button.hidden=NO;
        button.frame = newendFrame;
        
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:0.2 animations:^{
            CGRect newendFrame = CGRectMake(endPosition.origin.x, endPosition.origin.y, endPosition.size.width, endPosition.size.height);
            button.frame =newendFrame;
            
            
        }];
        
    }];
    
    
}

+(void)setInUserDefault:(NSObject *)obj key:(NSString *)key {
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:obj forKey:key];
    [userDefault synchronize];
}

+(NSObject *)getFromUserDefault:(NSString *)key {
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    return [userDefault objectForKey:key];
}

+(NSString *)getToken {
    return (NSString *)[Utilities getFromUserDefault:USER_DEFAULT_TOKEN_KEY];
}


+(UIButton *)prepareButton:(NSString *)title image:(UIImage *)image tag:(NSInteger)tag frame:(CGRect)buttonFrame{
//     UIButton   *btnNew=[UIButton buttonWithType:UIButtonTypeCustom];
//    [btnNew setTitle:title forState:UIControlStateNormal];
//    btnNew.titleLabel.font=[UIFont fontWithName:@"Roboto-Condensed" size:11];
//    btnNew.titleLabel.textAlignment=UITextAlignmentLeft;
//    btnNew.backgroundColor=[UIColor brownColor];
//    [btnNew setImage:image forState:UIControlStateNormal];
//    btnNew.tag=tag;
//    btnNew.imageEdgeInsets = UIEdgeInsetsMake(-30, 15, 0, 10);
//    btnNew.titleEdgeInsets = UIEdgeInsetsMake(40,-50, 0, 0);
//    return btnNew;
    
    
     UIButton   *btnNew=[[UIButton alloc]init];
    [btnNew setTitle:title forState:UIControlStateNormal];
    btnNew.titleLabel.font=[UIFont fontWithName:@"Roboto-Condensed" size:11];
    btnNew.titleLabel.textAlignment=UITextAlignmentLeft;
    [btnNew setImage:image forState:UIControlStateNormal];
    btnNew.frame=buttonFrame;
    btnNew.tag=tag;
    btnNew.imageEdgeInsets = UIEdgeInsetsMake(-30, 15, 0, 10);
    btnNew.titleEdgeInsets = UIEdgeInsetsMake(40,-50, 0, 0);
    return btnNew;
}

+(void)setNavigation:(NSString *)title leftButtonInfo:(ImageData *)leftButtonData rightButtonInfo:(ImageData *)rightButtonData on:(UINavigationItem *)navigationItem{
    
    CGRect frame = CGRectMake(0, 0, 180, 44);
    UILabel *nav_label = [[UILabel alloc] initWithFrame:frame];
    nav_label.backgroundColor = [UIColor clearColor];
    [nav_label setFont:[UIFont fontWithName:@"Roboto-Bold" size:18]];
    nav_label.shadowColor = [UIColor whiteColor];
    nav_label.shadowOffset  = CGSizeMake(0.5,0.5);
    nav_label.textAlignment = UITextAlignmentCenter;
    nav_label.textColor = [UIColor blackColor];
    nav_label.text = title;
    [nav_label sizeToFit];
    navigationItem.titleView = nav_label;

    SEL leftButtonSelector=[[leftButtonData.imageInfo valueForKey:@"selector"] pointerValue];
    id target=(id)[leftButtonData.imageInfo valueForKey:@"target"];
    
    UIBarButtonItem *leftButton=[[UIBarButtonItem alloc] initWithTitle:[leftButtonData.imageInfo valueForKey:@"title"] style:UIBarButtonItemStylePlain target:target action:leftButtonSelector];
    leftButton.tag=2001;
    [leftButton setTintColor:[UIColor colorWithRed:145.0/255.0 green:145.0/255.0 blue:145.0/255.0 alpha:.8]];
   // [leftButton setImage:leftButtonData.image];
    
    
    SEL rightButtonSelector=[[rightButtonData.imageInfo valueForKey:@"selector"] pointerValue];
    id rightTarget=(id)[rightButtonData.imageInfo valueForKey:@"target"];
    
    UIBarButtonItem *rightButton=[[UIBarButtonItem alloc] initWithTitle:[rightButtonData.imageInfo valueForKey:@"title"] style:UIBarButtonItemStylePlain target:rightTarget action:rightButtonSelector];
    rightButton.tag=2002;
    
    [rightButton setTintColor:[UIColor colorWithRed:112.0/255.0 green:171.0/255.0 blue:186.0/255.0 alpha:.8]];
    
    [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Roboto-Condensed" size:16],UITextAttributeFont,[UIColor colorWithRed:30.0/255 green:30.0/255 blue:30.0/255 alpha:30.0/255],UITextAttributeTextColor, nil]]  ;
    
    navigationItem.leftBarButtonItem=leftButton;
    navigationItem.rightBarButtonItem=rightButton;

}

+(NSString *)sanitizePhoneNumber:(NSString *)phoneNumber {
    
    if (phoneNumber == nil) return nil;
    
    NSMutableString *retStr = [NSMutableString
                                       stringWithCapacity:phoneNumber.length];
    
    NSScanner *scanner = [NSScanner scannerWithString:phoneNumber];
    NSCharacterSet *numbers = [NSCharacterSet
                               characterSetWithCharactersInString:@"+0123456789"];
    
    while ([scanner isAtEnd] == NO) {
        NSString *buffer;
        if ([scanner scanCharactersFromSet:numbers intoString:&buffer]) {
            [retStr appendString:buffer];
            
        } else {
            [scanner setScanLocation:([scanner scanLocation] + 1)];
        }
    }
    
    return retStr;
    
}
#pragma mark-
+(void)makeTextFieldVisibleForRect:(UITextField *)textField{
    UIView *superView=textField.superview;
    while (YES) {
        if ([superView class ]==[DGScrollView class]) {
            break;
        }else if([superView class ]==[UIScrollView class]){
            break;
        }else{
            superView=superView.superview;
        }

        if ([superView class]==[UIViewController class]|| superView==nil) {
            return;
        }
    }
    AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    UIScrollView *scrollView=(UIScrollView *)superView;
    
    CGRect rect=[textField bounds];
    CGRect mainViewRect = [textField convertRect:rect fromView:appDelegate.window];
    rect = [textField convertRect:rect fromView:scrollView];
    
    

    
    CGFloat windowHeight=appDelegate.winHeight;
    CGFloat keyboardHeight=appDelegate.keyPadHeight;
    
    CGFloat visibleArea=(windowHeight-keyboardHeight);
    CGFloat pos=-(mainViewRect.origin.y);
    if (pos>visibleArea) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.1];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
        [scrollView setContentOffset:CGPointMake(0, (-rect.origin.y))];
        [UIView commitAnimations];
    }
    
}
+(CGRect)frameOfUiKitOnTheGlobalFram:(UIView*)view{
    AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    CGRect rect=[view bounds];
    CGRect mainViewRect = [view convertRect:rect fromView:appDelegate.window.rootViewController.view];

    return CGRectMake(-(mainViewRect.origin.x), -(mainViewRect.origin.y/2), rect.size.width, rect.size.height);

}


+ (void)callNumber:(NSString *)phoneNumber {
    if (phoneNumber != nil && ![@"" isEqualToString:phoneNumber]) {
        NSString *phoneNumberUrl = [@"tel:" stringByAppendingString:phoneNumber];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumberUrl]];
    }
}

// returns the prefix (directory name) where the cached files
// are stored
+(NSString *)getFileNamePrefix:(NSString *)name {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsPath = [paths objectAtIndex:0];
        NSString *documentPathPrefix = [NSString stringWithFormat:@"%@/%@/", documentsPath, name];
        
    return documentPathPrefix;
    
}

+(NSMutableArray*)validateMultipleEmailWithString:(NSString*)emails
{
    if (emails == nil || [emails isEqualToString:@""]) {
        [[[iToast makeText:NSLocalizedString(([NSString stringWithFormat:@"Enter email Id"]), @"")]
          setGravity:iToastGravityCenter] show];
        return nil;
    }
    
    // Removing Initial and Final white spaces
    emails = [emails stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    // Removing mid space as @", "
    while ([emails rangeOfString:@", "].location != NSNotFound) {
        emails = [emails stringByReplacingOccurrencesOfString:@", " withString:@","];
    }
    // Removing mid space as @" ,"
    while ([emails rangeOfString:@" ,"].location != NSNotFound) {
        emails = [emails stringByReplacingOccurrencesOfString:@" ," withString:@","];
    }

    
    NSLog(@"After:%@", emails);
    
    NSMutableArray *validEmails = [[NSMutableArray alloc] init];
    NSArray *emailArray = [emails componentsSeparatedByString:@","];
    for (NSString *email in emailArray)
    {
        NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
        
        NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
        if ([emailTest evaluateWithObject:email]){
            [validEmails addObject:email];
        }else {
            
            [[[iToast makeText:NSLocalizedString(([NSString stringWithFormat:@"%@ is not a valid email Id ",email]), @"")]
              setGravity:iToastGravityCenter] show];
            [validEmails removeAllObjects];
            return validEmails;
        }
    }
    
    return validEmails;
}


+(NSMutableArray*)getPhoneNumbersFromTextField:(NSString *)numbersStr{
    
    NSMutableArray *phoneNumbers = [[NSMutableArray alloc] init];
    NSArray *numberStrArray = [numbersStr componentsSeparatedByString:@","];
    
    for (NSString *numberStr in numberStrArray) {
        if (numberStr !=nil && ![numberStr isEqualToString:@""]) {
            
            for (int i=1; i<numberStr.length-1; i++) {
                
                if ([numberStr characterAtIndex:i]>47 && [numberStr characterAtIndex:0]<58) { // Checking for no. only
                
                    
                }
                else{
                    break;
                }
                [phoneNumbers addObject:numberStr];
            }
        }
    }
    
    return phoneNumbers;
}


+(BOOL)validateCharacters:(NSString*)stringParam withinSet:(NSString*)characterSetStr{
    BOOL validate = YES;
    NSCharacterSet *charSet = [NSCharacterSet characterSetWithCharactersInString:characterSetStr];
    charSet = [charSet invertedSet];
    
    NSRange r = [stringParam rangeOfCharacterFromSet:charSet];
    if (r.location != NSNotFound) {
        NSLog(@"the string contains illegal characters");
        validate = NO;
    }
    return validate;
    
}

/*
 returns a trimmed string
 */
+ (NSString *)trimmedSting:(NSString *)string{
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [string stringByTrimmingCharactersInSet:whitespace];
    return trimmed;
}


// For key value mapping separated for FB and Twitter
+(KVCObject *)makeKVCObject:(Class)objClass data:(NSDictionary *)dictionary {
    KVCObject *obj;
    if ([dictionary class]!= [NSNull class]) {
        obj = [[objClass alloc] init];
        [obj setValuesForKeysWithDictionary:dictionary];
    }
    return obj;
}


// Store facebook cover image

+(void)storeFBCoverImage:(NSString *)coverImageURL{

    
}

+(NSString*)getFBCoverImageURL{
    
    return [[NSUserDefaults standardUserDefaults] objectForKey:FB_COVER_IMAGE];
}

+(NSString*)getFBProfileImageURL{
    
    return [[NSUserDefaults standardUserDefaults] objectForKey:FB_PROPILE_IMAGE];
}

+(void)removeFBCoverImage{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:FB_COVER_IMAGE];
}


// Distance key with User ID
+(NSString*)getDistanceKey{
    NSString *distanceKeyString = [NSString stringWithFormat:@"%@_%@",GET_DISTANCE_STATUS,(NSString*)[Utilities getFromUserDefault:USERID]];
    return distanceKeyString;
}

+(NSString *)getDistanceStatus{
   return  (NSString *)[Utilities getFromUserDefault:[Utilities getDistanceKey]];
}
+(void)setDistanceStatus:(NSString*)status{
    
    [Utilities setInUserDefault:status key:[Utilities getDistanceKey]];
}

+(void)storeFBDetails:(NSString*)userName email:(NSString*)email uid:(NSString*)fbUID cover:(NSString*)coverPic profile:(NSString*)profilePic{
    
     NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    if (userName) {
        [userDefault setObject:userName forKey:FB_USER_NAME];
    }
    
    if (email) {
        [userDefault setObject:email forKey:FB_EMAIL];
    }
    if (fbUID) {
        [userDefault setObject:fbUID forKey:FB_UID];
    }
    if (profilePic) {
        [userDefault setObject:profilePic forKey:FB_PROPILE_IMAGE];
    }
    if (coverPic) {
        [userDefault setObject:coverPic forKey:FB_COVER_IMAGE];
    }
    
    
}

+(void)removeFBDetail{
      NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault removeObjectForKey:FB_USER_NAME];
    [userDefault removeObjectForKey:FB_EMAIL];
    [userDefault removeObjectForKey:FB_UID];
    [userDefault removeObjectForKey:FB_PROPILE_IMAGE];
    [userDefault removeObjectForKey:FB_COVER_IMAGE];
}



@end
