//
//  Utilities.h
//  DishGram
//
//  Created by Rags on 23/04/13.
//
//

#import <Foundation/Foundation.h>


#define USER_DEFAULT_TOKEN_KEY @"token"

@class CustomBtnAndLabel, KVCObject;

@class ImageData;


typedef enum {
    DishGramThumbTypeSelectable,
    DishgramThumbTypeUnSelectable,
    DishGramThumbTypeCell
}DishGramThumbType;

@interface Utilities : NSObject{
    
}



@property(nonatomic,assign)BOOL isAlertActive;
- (NSDate *)convertFromStringToDate:(NSString *)dateString;

+ (BOOL) validateEmail: (NSString *) candidate;

+(void)showAlertMessage:(NSString *)msg andDelegate:(id)delegate;



//common animation controller
+(void)movingView:(UIView *)view toFrame:(CGRect)newFrame duration:(float)duration callback:(id)delegate selectore:(SEL)selector;
+(BOOL)isAlertActive;
+(void)setIsAlertActive:(BOOL)isAlert;

//Bounce animation for custombuttonandlabel(Customized Button)

+ (void)BounceLogoButtonAnimationsWithStartFrame:(CGRect)startPosition  endPosition:(CGRect)endPosition WithButton:(CustomBtnAndLabel *)button;

//normal  animation for custombuttonandlabel(Customized Button)
+ (void)normalLogoButtonAnimationsWithStartFrame:(CGRect)startPosition  endPosition:(CGRect)endPosition WithButton:(CustomBtnAndLabel *)button;

// customized button and label

+(CustomBtnAndLabel *) prepareButtonWithText:(NSString *) text imageName:(NSString *)imageName tag:(int) tag frame:(CGRect)frame andDelegate:(id)delegate;
// normal Animation for normal buttons
+ (void)moveAnimationForButtons:(CGRect)startPosition endPosition:(CGRect)endPosition withButton:(UIButton *)button;
//Bounce Animation for UIButtons

+ (void)bounceAndMoveAnimationForButtons:(CGRect)startPosition endPosition:(CGRect)endPosition withButton:(UIButton *)button;


+(UIButton *)prepareButton:(NSString *)title image:(UIImage *)image tag:(NSInteger)tag frame:(CGRect)buttonFrame;

/*
    get navigation bar of view controller and set the left and right navigation controller
 
    @title : title for view controller
    @leftbutton : ImageData for image and informatin
    @rightButton : ImageData for image and inormation
    @navigationItem : view controller navigation
 */
+(void)setNavigation:(NSString *)title leftButtonInfo:(ImageData *)leftButtonData rightButtonInfo:(ImageData *)rightButtonData on:(UINavigationItem *)navigationItem;


// sets specified key/value in user default
+(void)setInUserDefault:(NSObject *)obj key:(NSString *)key;

// gets specified value from user default
+(NSObject *)getFromUserDefault:(NSString *)key;

// returns token stored in user default
+(NSString *)getToken;

+(NSString *)sanitizePhoneNumber:(NSString *)phoneNumber;

//making a text field visible
+(void)makeTextFieldVisibleForRect:(UITextField *)textField;
+(CGRect)frameOfUiKitOnTheGlobalFram:(UIView*)view;

+(void)callNumber:(NSString *)phoneNumber;

+(NSString *)getFileNamePrefix:(NSString *)name;

// Get array of email Ids from email strings separated by comma
+(NSMutableArray*)validateMultipleEmailWithString:(NSString*)emails;

// Get Array of Phone numbers
+(NSMutableArray*)getPhoneNumbersFromTextField:(NSString *)numbersStr;


// Validate string in setof character
+(BOOL)validateCharacters:(NSString*)stringParam withinSet:(NSString*)characterSetStr;

//return the trimmed string 
+ (NSString *)trimmedSting:(NSString *)string;

// For key value mapping separated for FB and Twitter
+(KVCObject *)makeKVCObject:(Class)objClass data:(NSDictionary *)dictionary;


// Store facebook cover image
+(void)storeFBCoverImage:(NSString *)coverImageURL;
+(NSString*)getFBCoverImageURL;
+(NSString*)getFBProfileImageURL;
+(void)removeFBCoverImage;
+(void)storeFBDetails:(NSString*)userName email:(NSString*)email uid:(NSString*)fbUID cover:(NSString*)coverPic profile:(NSString*)profilePic;
+(void)removeFBDetail;
//
+(NSString*)getDistanceKey;
+(NSString *)getDistanceStatus;
+(void)setDistanceStatus:(NSString*)status;

@end
