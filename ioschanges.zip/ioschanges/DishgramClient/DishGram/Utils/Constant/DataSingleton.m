//
//  DataSingleton.m
//  DishGram
//
//  Created by Satish on 4/29/13.
//
//

#import "DataSingleton.h"


static NSDictionary* stringsDict = nil;

@implementation DataSingleton


+(NSString*)stringValueForKey:(NSString*)keyVal{
    
    
    if (stringsDict == nil) {
        NSString *path = [[[NSBundle mainBundle] bundlePath]stringByAppendingPathComponent:@"Strings.plist"];
        stringsDict = [NSDictionary dictionaryWithContentsOfFile:path];
        
//        NSLog(@"%@", stringsDict);
    }
   return [stringsDict objectForKey:keyVal];
}


+(BOOL)validateCharacter:(NSString*)stringParam{
    BOOL validate = YES;
    NSString *charString = [self stringValueForKey:@"CharacterSet"];
    NSCharacterSet *charSet = [NSCharacterSet characterSetWithCharactersInString:charString];
    charSet = [charSet invertedSet];
    
    NSRange r = [stringParam rangeOfCharacterFromSet:charSet];
    if (r.location != NSNotFound) {
        NSLog(@"the string contains illegal characters");
        validate = NO;
    }
    
//    charString = nil;
//    charSet = nil;    
    return validate;

}

@end
