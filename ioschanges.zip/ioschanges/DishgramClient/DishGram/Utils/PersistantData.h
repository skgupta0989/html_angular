//
//  PersistantData.h
//  DishGram
//
//  Created by Ramesh Varma on 02/07/13.
//
//

#import <Foundation/Foundation.h>

@interface PersistantData : NSObject {
    NSString *name_;
    NSString *documentPathPrefix;
    BOOL dirNotCreated;
}

@property (nonatomic, strong, readonly) NSMutableArray *data;

-(void)addData:(NSObject *)data;
-(void)removeData:(NSObject *)data;

-(id)initWithName:(NSString *)name;

@end
