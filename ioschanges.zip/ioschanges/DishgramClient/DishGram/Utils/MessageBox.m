//
//  MessageBox.m
//  DishGram
//
//  Created by Satish on 4/30/13.
//
//

#import "MessageBox.h"
#import <QuartzCore/QuartzCore.h>

@implementation MessageBox

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        nibView = [[[NSBundle mainBundle] loadNibNamed:@"MessageBox" owner:self options:nil] objectAtIndex:0];
        [self addSubview:nibView];
        
        self.layer.cornerRadius = 20;
        self.layer.masksToBounds = YES;
        self.layer.borderWidth = 3.0f;
    
    }
    return self;
}

-(void)setMessageString:(NSString*)msg{
    
    self.messageLabel.text = msg;
}


- (void)showAndHideAnimationFor:(UIView*)view startPos:(CGRect)startframe endPos:(CGRect)endFrame delayTime:(float)displayTime{
    
    [UIView animateWithDuration:0.2
                     animations:^{
                         view.frame = endFrame; //CGRectMake(55, 210, 210, 80);    // move
                     }
                     completion:^(BOOL finished){
                         // (in this case, another animation:)
                         [UIView animateWithDuration:0.2
                                               delay:displayTime
                                             options: UIViewAnimationOptionTransitionNone
                                          animations:^{
                                              view.frame = startframe;
                                              
                                          }completion:^(BOOL finished){
                                              [view removeFromSuperview];
                                              
                                          }];
                     }];
    
}


@end
