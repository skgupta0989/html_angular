//
//  CacheManager.h
//  DishGram
//
//  Created by User on 5/3/13.
//
//

@protocol CacheCallback <NSObject>

-(void)objDeleted:(id)obj from:(NSString *)name;

@end

// ensures that the total object in the dictionary do not exeed a fixed size
// if the max size is set to 100 and current size is set 100, any addition of
// new object will automatically remove bottom most object in the stack. New
// object is added at the top of the stack. When user accesses an obejct,
// then that object is automatically pulled up on the stack.
// when an object is removed for the stack, a delegate will be called.
@interface CacheManager : NSObject {
    int _maxSize;
    NSMutableDictionary *_objs;
    NSMutableArray *_objPositions;
    NSString *_name;
    id<CacheCallback> __weak _callBackDelegate;
}

// name of this cache.
@property (nonatomic, strong) NSString *name;

// objDeleted method will be called on delegate. This can be used for
// removeing the cached file from disk
@property (nonatomic, weak) id<CacheCallback> callBackDelegate;

// initilaize cache with specified size
-(id)initWithMaxSize:(int)maxSize andName:(NSString *)name;

// add an object to the cache
-(void)addKey:(NSString *)key andVal:(id)value;

// get an object from the cache. nil will returned if no object
// for specified key exists.
-(id)get:(NSString *)key;

@end
