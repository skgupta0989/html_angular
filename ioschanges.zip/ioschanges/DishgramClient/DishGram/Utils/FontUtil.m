//
//  FontUtil.m
//  DishGram
//
//  Created by Satish on 5/28/13.
//
//

#import "FontUtil.h"
#include <objc/runtime.h>
#include "NVLabel.h"


@implementation FontUtil

+(UIFont*)robotoCondensedWithSize:(int)size{
    UIFont *font = [UIFont fontWithName:@"Roboto-Condensed" size:size];
    return font;
}

+(UIFont*)robotoRegularWithSize:(int)size{
    UIFont *font = [UIFont fontWithName:@"Roboto-Regular" size:size];
    return font;
}


+(UIFont*)robotoMediumWithSize:(int)size{
    UIFont *font = [UIFont fontWithName:@"Roboto-Medium" size:size];
    return font;
}

+(UIFont*)robotoItalicWithSize:(int)size{
    UIFont *font = [UIFont fontWithName:@"Roboto-Italic" size:size];
    return font;
}

+(void)decorate:(NVLabel *)label {
    
    NSString *font = label.NVFont;
    
    if (font == nil) {
        return;
    }
    
    // TODO
    // more specifiec conditions must be checed before generic ones.
    // Ex: _af_tile_header_ must be checed before _tile_header_ which inturn must be checked before _header_
    
    
    // 
    
    if ([font hasSuffix:@"_ri_restName_"]){
        label.font = [FontUtil robotoRegularWithSize:16];
        label.textColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
    } else if ([font hasSuffix:@"_explore_followers_text_"] || [font hasSuffix:@"_explore_dishes_text_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_rd_tile_footer_"]){
        label.font = [FontUtil robotoRegularWithSize:12];
        label.textColor = [UIColor colorWithRed:248.0/255 green:111.0/255 blue:98.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_distance_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_number_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:248.0/255 green:111.0/255 blue:98.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_explore_address_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:85.0/255 green:85.0/255 blue:85.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_explore_place_"]){
        label.font = [FontUtil robotoCondensedWithSize:14];
        label.textColor = [UIColor colorWithRed:248.0/255 green:111.0/255 blue:98.0/255 alpha:1.0];
        // [UIColor colorWithRed:85.0/255 green:85.0/255 blue:85.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_dropdown_address_header_"]){
        label.font = [FontUtil robotoCondensedWithSize:16];
        label.textColor = [UIColor colorWithRed:169.0/255 green:169.0/255 blue:169.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_dropdown_address_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor whiteColor];
    } else if ([font hasSuffix:@"_explore_table_title_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor whiteColor];
    } else if ([font hasSuffix:@"_Following_Tile_UserName_"]){
        label.font = [FontUtil robotoCondensedWithSize:16];
        label.textColor = [UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_Following_Tile_UserName_Sub_"]){
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_comment_comment_"] || [font hasSuffix:@"_comment_name_"]){
        label.font = [FontUtil robotoMediumWithSize:12]; // Medium
        label.textColor = [UIColor colorWithRed:121.0/255 green:121.0/255 blue:121.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_pf_userName_"]) {
        label.font = [FontUtil robotoMediumWithSize:16]; // Medium
        label.textColor = [UIColor whiteColor];
    }
    else if ([font hasSuffix:@"_pf_address_"]){
        label.font = [FontUtil robotoMediumWithSize:10];  // Medium
        label.textColor = [UIColor whiteColor];
    }
    else if ([font hasSuffix:@"_pf_followersValue_"]){
        label.font = [FontUtil robotoCondensedWithSize:18];
        label.textColor = [UIColor colorWithRed:75.0/255 green:75.0/255 blue:75.0/255 alpha:1.0];
    }
    else if ([font hasSuffix:@"_pf_followers_"]) {
        label.font = [FontUtil robotoCondensedWithSize:10];
        label.textColor = [UIColor colorWithRed:75.0/255 green:75.0/255 blue:75.0/255 alpha:1.0];
    }
    else if ([font hasSuffix:@"_pf_eventValue_"]){
        label.font = [FontUtil robotoRegularWithSize:13]; // Regular
        label.textColor = [UIColor colorWithRed:244.0/255 green:101.0/255 blue:85.0/255 alpha:1.0];
    }
    else if ([font hasSuffix:@"_pf_event_"]){
        label.font = [FontUtil robotoRegularWithSize:10]; // Regular
        label.textColor = [UIColor colorWithRed:244.0/255 green:101.0/255 blue:85.0/255 alpha:1.0];
    }
    else if ([font hasSuffix:@"_restName_"]){
        label.font = [FontUtil robotoRegularWithSize:14]; // Regular
        label.textColor = [UIColor whiteColor];
    } else if ([font hasSuffix:@"_postDate_"]) {
        label.font = [FontUtil robotoRegularWithSize:12];
        label.textColor = [UIColor colorWithRed:75.0/255 green:75.0/255 blue:75.0/255 alpha:1.0];
    }
    else if ([font hasSuffix:@"_postAddress_"]){
        label.font = [FontUtil robotoCondensedWithSize:10];
        label.textColor = [UIColor colorWithRed:64.0/255 green:64.0/255 blue:64.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_comment_"]) {
        label.font = [FontUtil robotoCondensedWithSize:10];
        label.textColor = [UIColor colorWithRed:121.0/255 green:121.0/255 blue:121.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_username_"]) {
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
    } else if ([font hasSuffix:@"_header_"]) {
        label.font = [FontUtil robotoMediumWithSize:16];
        label.textColor = [UIColor colorWithRed:244.0/255 green:101.0/255 blue:85.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_headerSub_"]) {
        label.font = [FontUtil robotoRegularWithSize:10];
        label.textColor = [UIColor colorWithRed:75.0/255 green:75.0/255 blue:75.0/255 alpha:1.0];
        label.font  = [UIFont italicSystemFontOfSize:10];
    } else if ([font hasSuffix:@"_place_"]) {
        label.font = [FontUtil robotoRegularWithSize:14];
        label.textColor = [UIColor colorWithRed:51.0/255 green:51.0/255 blue:51.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_location_"] || [font hasSuffix:@"_address_"] || [font hasSuffix:@"_phone_"] || [font hasSuffix:@"_views_"]) {
        label.font = [FontUtil robotoRegularWithSize:12];
        label.textColor = [UIColor colorWithRed:51.0/255 green:51.0/255 blue:51.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_description_"]) {
        label.font = [FontUtil robotoRegularWithSize:12];
        label.textColor = [UIColor colorWithRed:121.0/255 green:121.0/255 blue:121.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_footer_"]) {
        label.font = [FontUtil robotoRegularWithSize:12];
        label.textColor = [UIColor colorWithRed:121.0/255 green:121.0/255 blue:121.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_subLabel_"]) {
        label.font = [FontUtil robotoRegularWithSize:12];
        label.textColor = [UIColor colorWithRed:58.0/255 green:58.0/255 blue:58.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_counter_"]) {
        label.font = [FontUtil robotoRegularWithSize:20];
        label.textColor = [UIColor colorWithRed:48.0/255 green:48.0/255 blue:48.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_counterSub_"]) {
        label.font = [FontUtil robotoRegularWithSize:10];
        label.textColor = [UIColor colorWithRed:58.0/255 green:58.0/255 blue:58.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"RecentUpdates_Username_"]){
        label.font = [FontUtil robotoCondensedWithSize:16];
        label.textColor = [UIColor colorWithRed:248.0/255.0 green:111.0/255.0 blue:98.0/255.0 alpha:1.0];
    } else if([font hasSuffix:@"RecentUpdates_Username_sub_"]){ // also for Email Invite label
        label.font = [FontUtil robotoCondensedWithSize:14];
        label.textColor = [UIColor colorWithRed:75.0/255.0 green:75.0/255.0 blue:75.0/255.0 alpha:1.0];
    } else if ([font hasSuffix:@"RecentUpdates_Username_sub1_"]){
        
        label.font = [FontUtil robotoItalicWithSize:12];
        label.textColor = [UIColor colorWithRed:75.0/255.0 green:75.0/255.0 blue:75.0/255.0 alpha:1.0];
    }else if ([font hasSuffix:@"RecentUpdates_Username_sub2_"]){
        
        label.font = [FontUtil robotoCondensedWithSize:12];
        label.textColor = [UIColor colorWithRed:75.0/255.0 green:75.0/255.0 blue:75.0/255.0 alpha:1.0];
    }else if([font hasSuffix:@"settings_headings"])
    {
        label.font = [FontUtil robotoCondensedWithSize:16];
        label.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
    }else if([font hasSuffix:@"settings_sub_headings"]){
        label.font = [FontUtil robotoCondensedWithSize:14];
        label.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
    }else if([font hasSuffix:@"settings_headings_sub"]){
        label.font = [FontUtil robotoCondensedWithSize:13];
        label.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
    }
    else if([font hasSuffix:@"settings_headings_sub1"]){
        label.font = [FontUtil robotoItalicWithSize:13];
        label.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
    }
    else if([font hasSuffix:@"settings_headings_sub2"]){
        label.font = [FontUtil robotoCondensedWithSize:11];
        label.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
    }
    else if ([font hasSuffix:@"_dropdown_address_Custom"]){
        label.font = [FontUtil robotoItalicWithSize:12];
        label.textColor = [UIColor whiteColor];
    } else if ([font hasSuffix:@"_comment_time_"]){
        label.font = [FontUtil robotoItalicWithSize:12]; // Medium
        label.textColor = [UIColor colorWithRed:121.0/255 green:121.0/255 blue:121.0/255 alpha:1.0];
    } else if ([font hasSuffix:@"_dropdown_address_location"]){
        label.font = [FontUtil robotoRegularWithSize:14];
        label.textColor = [UIColor whiteColor];
    }

}



+(void)decorateView:(UIView *)view {
    NSArray *subviews = [view subviews];
    for (int i = 0; i < subviews.count; ++i) {
        UIView *subview = [subviews objectAtIndex:i];
        if ([subview isKindOfClass:[NVLabel class]]) {
            [FontUtil decorate:(NVLabel *)subview];
        } else {
            [FontUtil decorateView:subview];
        }
    }
}


@end
