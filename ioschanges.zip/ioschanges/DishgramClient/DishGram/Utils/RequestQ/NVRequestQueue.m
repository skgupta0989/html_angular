//
//  NVRequestQueue.m
//  DishGram
//
//  Created by User on 5/10/13.
//
//

#import "NVRequestQueue.h"

@implementation NVRequestQueue

@synthesize name;

-(id)initWithSize:(int)size noOfThreads:(int)threadCount andName:(NSString *)queueName {
    self = [super init];
    if (self) {
        _size = size;
        self.name = queueName;
        _requests = [[NSMutableArray alloc] initWithCapacity:size];
        _requestPoolLock = [[NSCondition alloc] init];
        
        // initialize all the threads
        {
            int threadCountLocal = threadCount;

            NSThread *prefetchThread = nil;
            while (threadCountLocal > 0)
            {
                prefetchThread = [[NSThread alloc] initWithTarget:self selector:@selector(requestProcessingLoop)object:nil];
                [prefetchThread start];
                threadCountLocal--;
            }
        }
        
    }
    return self;
}

// loop for processing the requets. threadCount number of threads will enter this method and wait untill _requests hase some requests
-(void)requestProcessingLoop {
    while (true) {
        [_requestPoolLock lock];
        if ([_requests count] == 0) {
            // wait until queue is not empty
            [_requestPoolLock wait];
        }
            
        id request = nil;
        if ([_requests count] != 0) {
            // there are requests pending for processing
            request = [_requests objectAtIndex:0];
            [_requests removeObjectAtIndex:0];
        }
        
        // release the lock before starting the request processing. so that other threads use the queue
        [_requestPoolLock unlock];
        if (request != nil) {
            @autoreleasepool {
                [self processRequest:QUEUE_PROCESS request];
            }
        }

    }
}

// process specified request
-(void)processRequest:QUEUE_PROCESS request {
    @autoreleasepool {
        request(false);
    }
}

-(void)request:QUEUE_PROCESS process {
    // check if processor can get return object quickly
    [_requestPoolLock lock];
 
    [_requests insertObject:process atIndex:0];
        [self trimQueue];
    
    [_requestPoolLock signal];
    [_requestPoolLock unlock];
}

// trims the queue to maximum allowed size so that older requests are removed from the queue
-(void)trimQueue {
    
    while ([_requests count] > _size) {
//        NSLog(@"######## Queue %@ dropping a request object", self.name);
        (QUEUE_PROCESS[_requests lastObject])(true);
        [_requests removeLastObject];
    }
}

-(void)clearQueue {
    [_requestPoolLock lock];
    [_requests removeAllObjects];
    [_requestPoolLock unlock];
    
}

@end
