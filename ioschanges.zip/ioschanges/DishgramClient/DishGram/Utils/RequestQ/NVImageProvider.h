//
//  NVImageProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import <Foundation/Foundation.h>

@interface NVImageProvider : NSObject

+(void)getImage:(NSString *)cacheName url:(NSString *)url prefetch:(NSArray *)prefetch callBack:(void (^)(NSObject *data)) callBack errorCallBack:(void (^)(NSString *errorCode)) errorCallBack;

@end
