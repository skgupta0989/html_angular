//
//  NVImageProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import "NVImageProvider.h"
#import "NVRequestQueue.h"
#import "ImageCacheQueue.h"

#import "CacheFactory.h"

@implementation NVImageProvider

int _reqPriority = 0;

+(void)getImage:(NSString *)cacheName url:(NSString *)url prefetch:(NSArray *)prefetch callBack:(void (^)(NSObject *data)) callBack errorCallBack:(void (^)(NSString *errorCode)) errorCallBack {
    
    ImageCache *processor = [CacheFactory getImageCacheByName:cacheName];
    if ([processor isQuick:url]) {
        // process immediatly
        callBack([processor getImage:url withPrefetch:prefetch withPriority:++_reqPriority]);
    } else {
        
        if ([url rangeOfString:@"/t/"].length != 0) {
            NSString *smallImageUrl = [url stringByReplacingOccurrencesOfString:@"/t/" withString:@"/s/"];
            if ([processor isQuick:smallImageUrl]) {
                callBack([processor getImage:smallImageUrl withPrefetch:prefetch withPriority:++_reqPriority]);
                return;
            }
        }
        
        // process later
        NVRequestQueue *queue = [ImageCacheQueue getImageQueueByName:cacheName];
        [queue request:^(bool drop) {
            if (drop) {
                callBack(nil);
            } else {
                UIImage *image = [processor getImage:url withPrefetch:prefetch withPriority:++_reqPriority];
                callBack(image);
            }
        }];
    }    
}

@end
