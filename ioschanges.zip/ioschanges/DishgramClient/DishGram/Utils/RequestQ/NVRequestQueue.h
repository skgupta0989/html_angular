//
//  NVRequestQueue.h
//  DishGram
//
//  Created by User on 5/10/13.
//
//

#import <Foundation/Foundation.h>

#define QUEUE_PROCESS (void (^)(bool drop))

// LIFO queue with limited queue size. Requests added tot he queue will be processed in LIFO order. queue has a limited size. when request objects are added at faster rate, older requests will be dropped out of the queue.
// request object is notified on a response or when request is dropped from the queue
@interface NVRequestQueue : NSObject {
    
    // list of unprocessed requests in the queue. request that are already procesed or currently in process will not be present in this list. Also dropped requerst will not be present in this list
    NSMutableArray *_requests;
    
    // maximum size of the queue
    int _size;

    // lock used for adding and deleting requests by multiple threads
    NSCondition *_requestPoolLock;
    
}

// name of this queue
@property (nonatomic, strong) NSString *name;


// initializes the queue
// size - maximum size of the queue. when the size exeeds, older unprocessed requests will be dropped. For a screen with 10 images diplayed in the visual field, this value should be between 12 - 15.
// processor - request processor instance. same processor will be used for all the requests ever added to this queue. Processor can be invoked by multiple threads in parallel. So processor must be impleented in thread safe manner.
// threadCount - number of threads that will be processing the requests in parallel. Typically 3 threads should be enough for downloading the images
// queueName - name of this queue. This name must be unique for debugging purposes
-(id)initWithSize:(int)size noOfThreads:(int)threadCount andName:(NSString *)queueName;

// added request to the queue for processing
-(void)request:QUEUE_PROCESS process;

// remove all pending items from the queue. this method must be called when user navigates away from a screen and we dont want to load the remaining images anymore.
-(void)clearQueue;


@end
