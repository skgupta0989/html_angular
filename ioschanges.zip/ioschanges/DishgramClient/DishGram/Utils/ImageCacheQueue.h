//
//  ImageCacheQueue.h
//  DishGram
//
//  Created by User on 5/13/13.
//
//

#import <Foundation/Foundation.h>
#import "NVRequestQueue.h"


#define QUEUE_SIZE_DEFAULT 8
#define QUEUE_SIZE_FB_IMAGE 15
#define QUEUE_SIZE_DISH_IMAGE 8

// helper class for getting instance of a queue
@interface ImageCacheQueue : NSObject

// return a queue by specified name. Allowed names can be found in CacheFactory.h file. look for CACHE_NAME_* definitions
+(NVRequestQueue *)getImageQueueByName:(NSString *)name;

@end
