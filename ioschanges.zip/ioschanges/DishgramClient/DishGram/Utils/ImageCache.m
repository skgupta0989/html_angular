//
//  ImageCache.m
//  DishGram
//
//  Created by User on 5/3/13.
//
//

#import "ImageCache.h"

@implementation ImageCache

@synthesize imageSource = _imageSource;
@synthesize c1Manager = _c1Manager;
@synthesize c2Manager = _c2Manager;
@synthesize name = _name;

-(id)initWithName:(NSString *)name isPersistant:(BOOL)persistant c1Size:(int)c1Size c2Size:(int)c2Size {
    self = [super init];
    if (self) {
        documentPathPrefix = nil;
        dirNotCreated = TRUE;
        
        self.name = name;
        self.imageSource = [[ImageSource alloc] init];
        self.c2Manager = [[CacheManager alloc] initWithMaxSize:c2Size andName:@"C2"];
    
        self.c1Manager = [[CacheManager alloc] initWithMaxSize:c1Size andName:@"C1"];
    
        // need call back on c1 so that the file stored in documents
        // directory can be removed.
        self.c1Manager.callBackDelegate = self;
        
        // we don't need call back on c2.
        
    
        _prefetchPool = [[NSMutableArray alloc] init];
        _fetchLocks = [[NSMutableDictionary alloc] init];
        _lockHelper = [[NSConditionLock alloc] init];
        _prefetchPoolLock = [[NSCondition alloc] init];
        
        
        // if persistant then load the cache data into memory
        if (persistant) {
            [self loadCache];
        } else {
            // if !persistant then cleanup
            [self removeImage:[self getFileNamePrefix]];
        }
    
        // start the prefetch thread.
        NSThread *prefetchThread = [[NSThread alloc] initWithTarget:self selector:@selector(prefetchLoop)object:nil];
        [prefetchThread start];
    }
    
    return self;
}

// checks if the specified images are in cache and adds the prefetch urls
// to _prefetchPool. prefetchLoop fetches images specified in _prefetchPool.
// when this method is called, if there are any pending items in the pool
// then they will be removed and new urls added.
-(void)prefetch:(NSArray *)otherImageUrls {
    [_prefetchPoolLock lock];
    // check if prefetch urls are present
    if (otherImageUrls) {
        _prefetchPool = [[NSMutableArray alloc] init];

        for (NSString *url in otherImageUrls) {
        
            if (![self inCache:[self getFileName:url]]) {
                [_prefetchPool addObject:url];
            }
        }
    }
    [_prefetchPoolLock signal];
    [_prefetchPoolLock unlock];
}

// this loops executes on a separate thread and fetches images for urls
// specified in _prefetchPool. If there are no uls left, then the thread
// waits until there are urls available.
-(void)prefetchLoop {
    while(true) {
        [_prefetchPoolLock lock];
        if ([_prefetchPool count] == 0) {
            [_prefetchPoolLock wait];
        }
        NSString *url = nil;
        if ([_prefetchPool count] != 0) {
             url = [_prefetchPool objectAtIndex:0];
            [_prefetchPool removeObjectAtIndex:0];
        }
        [_prefetchPoolLock unlock];
        if (url != nil) {
            @autoreleasepool {
                [self cacheImage:url memLoad:true];
            }
        
        }
        
    }
}

// return an exisitng lock for url or creates a new one
-(NSConditionLock *)getLock:(NSString *) url {
    [_lockHelper lock];
    NSConditionLock *lock = [_fetchLocks objectForKey:url];
    if (lock == nil) {
        lock = [[NSConditionLock alloc] init];
        [_fetchLocks setObject:lock forKey:url];
    }
    [_lockHelper unlock];
    return lock;
}

// removes lock object. must be called once it is not
// required anymore
-(void) removeLock:(NSString *)url {
    [_lockHelper lock];
    [_fetchLocks removeObjectForKey:url];
    [_lockHelper unlock];
}

// checks if specified url is in cahce
-(bool)inCache:(NSString *)fileName
{
    // return true if image present in either of the caches
    return [self.c2Manager get:fileName] != nil || [self.c1Manager get:fileName] != nil;
}

-(UIImage *)getImage:(NSString *)imageUrl withPrefetch:(NSArray *)otherImageUrls {
    UIImage *retVal = [self getImage:imageUrl];
    [self prefetch:otherImageUrls];
    return retVal;
}

-(UIImage *)getImage:(NSString *)imageUrl {
    @autoreleasepool {
        return [self getImageDo:imageUrl];
    }
}

-(UIImage *)getImageDo:(NSString *)imageUrl {
    NSConditionLock *lock = [self getLock:imageUrl];
    [lock lock];
    NSString *fileName = [self getFileName:imageUrl];
    
    // NSLog(@"%@",imageUrl);
    // NSLog(@"%@",fileName);
    
    UIImage* image = [self.c2Manager get:fileName];
    if (image == nil) {
        NSString *imageName = [self.c1Manager get:fileName];
        if (imageName != nil) {
            // NSLog(@"Returning from c1");
            image = [self loadImage:imageName];
            if (image != nil) {
                // add image to c2 cache
                [self.c2Manager addKey:fileName andVal:image];
            }
        } else {
            image = [self.imageSource getImage:imageUrl];
            if (image != nil) {
                // update caches
                [self persistImage:image fileName:fileName];
                [self.c2Manager addKey:fileName andVal:image];
                [self.c1Manager addKey:fileName andVal:fileName];
            }
        }
        
    } else {
        // image is available in C2 cache. Faster access
        // NSLog(@"Returning from c2");
        // call this method so that cache is refreshed
        [self.c1Manager get:fileName];
    }
    [lock unlock];
    [self removeLock:imageUrl];
    return image;
}

// fetches and caches the image. if memLoad is true, then the image will
// be cahced in C2 for faster access. if memLoad is false, then image
// will not be loaded into C2 from C1. if image is already present in C2
// then it will remain in C2. If image is fetched from server, then memLoad
// parameter is ignored and image is cached in C2.
-(void)cacheImage:(NSString *)imageUrl memLoad:(bool)memLoad {
    // NSLog(@"cacheImage called");
    NSConditionLock *lock = [self getLock:imageUrl];
    [lock lock];
    NSString *fileName = [self getFileName:imageUrl];
    UIImage* image = [self.c2Manager get:fileName];
    if (image == nil) {
        NSString *imageName = [self.c1Manager get:fileName];
        if (imageName != nil) {
            // in disc cache
            if (memLoad) {
                image = [self loadImage:imageName];
                
                if (image != nil) {
                    // add image to c2 cache
                    [self.c2Manager addKey:fileName andVal:image];
                }
            }
        } else {
            // not in cache
            image = [self.imageSource getImage:imageUrl];
            if (image != nil) {
                // update caches
                [self persistImage:image fileName:fileName];
                [self.c2Manager addKey:fileName andVal:image];
                [self.c1Manager addKey:fileName andVal:fileName];
            }
        }
        
    } else {
        // call this method so that cache is refreshed
        [self.c1Manager get:fileName];
    }
    [lock unlock];
    [self removeLock:imageUrl];
}

// persistes image data to disk
-(void)persistImage:(UIImage *)image fileName:(NSString *)fileName {
    
    NSData *jpgData = UIImageJPEGRepresentation(image, 1);
    
    // check if the directory is already created.
    if (dirNotCreated) {
        // create directory
        [[NSFileManager defaultManager] createDirectoryAtPath:[self getFileNamePrefix] withIntermediateDirectories:YES attributes:nil error:nil];
        dirNotCreated = FALSE;
    }
    
    [jpgData writeToFile:fileName atomically:YES];
}

// remove specified file
-(void)removeImage:(NSString *)fileName {
    NSError *error = nil;
    [[NSFileManager defaultManager] removeItemAtPath: fileName error: &error];
}


// loads image from specified filename
-(UIImage *)loadImage:(NSString *)fileName {
    NSData *pngData = [NSData dataWithContentsOfFile:fileName];
    UIImage *image = [UIImage imageWithData:pngData];
    return image;
}

// when application restarts the cache is reconstructed
-(void)loadCache {
    int count;
    
    NSArray *directoryContent = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[self getFileNamePrefix] error:NULL];
    for (count = 0; count < (int)[directoryContent count]; count++)
    {
        NSString *file = [directoryContent objectAtIndex:count];
        NSString *fullFilePath = [NSString stringWithFormat:@"%@%@", [self getFileNamePrefix], file];
        // NSLog(@"Init Cache:%@", fullFilePath);
        [self.c1Manager addKey:fullFilePath andVal:fullFilePath];
    }
}

// returns the prefix (directory name) where the cached files 
// are stored
-(NSString *)getFileNamePrefix {
    if (documentPathPrefix == nil) {
        documentPathPrefix = [Utilities getFileNamePrefix:self.name];
    }
    return documentPathPrefix;

}

// returns unique file name for specified url
-(NSString *)getFileName:(NSString *)url {
    // get image file name
    NSArray* items = [url componentsSeparatedByString:@"/"];
    NSString *fileName =[NSString stringWithFormat:@"%@_%@", [items objectAtIndex:(items.count - 2)], [items lastObject]];
    
    // full directory path
    return [[self getFileNamePrefix] stringByAppendingPathComponent:fileName];
}

-(void)dealloc {
    self.imageSource = nil;
    self.c1Manager.callBackDelegate = nil;
    self.c1Manager = nil;
    self.c2Manager = nil;
    
#if !(__has_feature(objc_arc))
    [super dealloc];
#endif
}

// called by CacheManager when the cache size if full and an
// object need to be removed. This method removes the spefied file
// from documents directory
-(void)objDeleted:(id)obj from:(NSString *)name {
    [self removeImage:obj];
}


#pragma mark NVRequestProcessor methods
-(UIImage *)getImage:(NSString *)imageUrl withPrefetch:(NSArray *)otherImageUrls withPriority:(int)priority {
    
    NSArray *preFetchUrls = nil;
    
    if (priority > _requestPriority) {
        _requestPriority = priority;
        preFetchUrls = otherImageUrls;
    }

    UIImage *image = [self getImage:imageUrl withPrefetch:preFetchUrls];
    return image;
}

-(bool)isQuick:(NSString *)url {
    return [self inCache:[self getFileName:url]];
}

#pragma mark

@end
