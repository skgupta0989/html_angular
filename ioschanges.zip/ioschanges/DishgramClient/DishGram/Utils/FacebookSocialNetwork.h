//
//  FacebookSocialNetwork.h
//  DishGram
//
//  Created by Rags on 29/04/13.
//
//

#import <Foundation/Foundation.h>
#import <FacebookSDK/FacebookSDK.h>
#import "FriendsViewController.h"
#import "RequestBodyGenerator.h"

typedef void (^FBPostHandler)(id result,NSError *error,id<FBGraphUser> user);

@class  AppDelegate;

@protocol facebookUserInformationdelegate <NSObject>

- (void)getFaceBookUserInformationDictionaryForRegisterationToDisgram:(NSDictionary*)FBUserDictionary;
- (void)getFriendsWhoAreUsingTheApp:(NSDictionary*)friendsDictionary;
- (void)errorCallBackForLandingScreen;

@end


@interface FacebookSocialNetwork : NSObject{
    FBSession *fbSessionObject;
    
    NSString *postMessage;
    AppDelegate *appDelegate;

}


@property (nonatomic, weak) id<facebookUserInformationdelegate> delegate;
@property (nonatomic, strong) NSString *emailId;
@property (nonatomic, strong) NSString *token;

- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error;
- (void)openSessionWith:(void (^)(FBSession *session, FBSessionState status, NSError *error))block;
+(id)sharedInstance;
- (void)retrieveFaceBookUserInformationAfterSuccessfulLogin:(void (^)(id result, NSError *error))bolck;
- (void)creatingForRegisteringFacebookWithUserDetails:(NSString *)username email:(NSString *)email userId:(NSString *)userID;
- (void)requestForFriendsWhoAreUsingTheApp:(void(^)(id result, NSError *error))block;


- (void)logout;
-(void)postOnWall:(NSString*)message;

-(BOOL) isSessionValid;

//
-(void)authenticateWithCompletionBlock:(void(^)(FBSession *session,FBSessionState status,NSError *error))callback;
-(void)performPostImageOnUserFBWallWithParams:(NSMutableDictionary *)param callBackHandler:(FBPostHandler)handler;
- (void)postImageOnUserWall:(UIImage *)image caption:(NSString *)message  callBackHandler:(FBPostHandler)handler;


 // Getting FB Friends
-(void)getFacebookFriendsListWithBlock:(void(^)(FBRequestConnection *connection, id result, NSError *error))callback;

- (void)shareOnFacebook:(NSString*)shareMessage;


// Share
-(void)shareWithGraphAndDictionary:(NSMutableDictionary*)paramDict and:(void(^)(id result, NSError *error))block;

@end
