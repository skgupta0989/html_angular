//
//  FacebookSocialNetwork.m
//  DishGram
//
//  Created by Rags on 29/04/13.
//
//

#import "FacebookSocialNetwork.h"
#import "AppDelegate.h"
#import "Utilities.h"
#import "Header.h"
#import <FacebookSDK/FacebookSDK.h>

static FacebookSocialNetwork *facebookSocialNetworkSingleton = nil;


@implementation FacebookSocialNetwork

@synthesize delegate;
@synthesize emailId;
@synthesize token;


-(id)init{
    self = [super init];
    if (self!=nil) {
        appDelegate = [UIApplication sharedApplication].delegate;
    }
    return self;
}

+(id)sharedInstance{
    if(facebookSocialNetworkSingleton == nil){
        facebookSocialNetworkSingleton = [[FacebookSocialNetwork alloc] init];
        
    }
    return facebookSocialNetworkSingleton;
}

// called after facebook login 
- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error{
    
    NSLog(@"sessionStateChanged");
    
    fbSessionObject=session;
    switch (state) {
        case FBSessionStateOpen: {
            
            // After Login retrieving the user information
            
            if (postMessage==nil || [postMessage isEqualToString:@""]) {
//                [self retrieveFaceBookUserInformationAfterSuccessfulLogin];
            }
            else{
                
//                [self postOnFBWall];
                
            }
            
            
            
            break;
        }
        case FBSessionStateClosed: {
            // TODO - on logout
            NSLog(@"Logout Facebook");
             [FBSession.activeSession closeAndClearTokenInformation];
            break;
        }
        case FBSessionStateClosedLoginFailed: {
            // TODO
            [FBSession.activeSession closeAndClearTokenInformation];
            break;
        }
            
            
        default:
            break;
    }
    
}

// called when facebook button clicked

- (void)openSessionWith:(void (^)(FBSession *session, FBSessionState status, NSError *error))block{
    
    NSLog(@"openSession");
    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    NSArray *permissions = [NSArray arrayWithObjects:@"email",nil];
    [FBSession openActiveSessionWithReadPermissions:permissions allowLoginUI:YES completionHandler:block];
}


// retrieve user InformationSuccesfulLogin

- (void)retrieveFaceBookUserInformationAfterSuccessfulLogin:(void (^)(id result,
                                                             NSError *error))bolck{
    
    NSLog(@"Entered in to the friends requests");
    // Query to fetch the active user's friends, limit to 25.
    NSString *query = @"SELECT uid, name,email,pic_square,pic_cover FROM  user where uid=me()";

    
    // Set up the query parameter
    NSDictionary *queryParam =
    [NSDictionary dictionaryWithObjectsAndKeys:query, @"q", nil];
    // Make the API request that uses FQL
    [FBRequestConnection startWithGraphPath:@"/fql"
                                 parameters:queryParam
                                 HTTPMethod:@"GET"
                          completionHandler:^(FBRequestConnection *connection,
                                              id result,
                                              NSError *error) {
                              if (error) {
                                  NSLog(@"Error: %@", [error localizedDescription]);
                            
                                  bolck(nil,error);
                                  
                              } else {
                                  
                                  NSDictionary *userData = (NSDictionary *)result;
                                  NSMutableArray *userInfo = [userData objectForKey:@"data"];
                                  NSLog(@"userInfo=%@",userInfo);
                                  
                                  if (userInfo==nil || userInfo.count ==0) {
                                      return;
                                  }
                                  NSMutableDictionary *dict = [userInfo objectAtIndex:0];
                                  NSString *username = [dict objectForKey:@"name"];
                                  
                                  
                                  
                                  NSString *userID = [dict objectForKey:@"uid"];
                                  NSString *email = [dict objectForKey:@"email"];
                                  NSString *profileImage = dict[@"pic_square"];
                                  NSDictionary *coverPicDict = dict[@"pic_cover"];
                                  
                                  if ([coverPicDict class]!=[NSNull class]) {
                                      NSString *coverPicURL = coverPicDict[@"source"];
                                      [Utilities storeFBDetails:username email:email uid:userID cover:coverPicURL profile:profileImage];
                                  }
                                  else{
                                      [Utilities storeFBDetails:username email:email uid:userID cover:nil profile:profileImage];
                                  }
                                  
                                  emailId = email;
                                  [self creatingForRegisteringFacebookWithUserDetails:username email:email userId:userID];
                                  
                                   bolck(result,nil);
                              }
                          }];

    
}


// form the dictinary using the request body generator and retrieved user information

- (void)creatingForRegisteringFacebookWithUserDetails:(NSString *)username email:(NSString *)email userId:(NSString *)userID {
    
    NSLog(@"creatingForRegisteringFacebookWithUserDetails");
    if(userID == nil){
        userID = @"";
    }
    RequestBodyGenerator *registrationFacebookBody = [[RequestBodyGenerator alloc] init];
    NSDictionary *dict = [registrationFacebookBody postDatawithUserName:username andemailId:email andpassword:@"" andregistrationType:@"Facebook" andappToken:@"11111145" anduserOathId:userID];
    [self.delegate getFaceBookUserInformationDictionaryForRegisterationToDisgram:dict];
    
}


-(void)getFacebookFriendsListWithBlock:(void(^)(FBRequestConnection *connection, id result, NSError *error))callback{
    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    
    //    SELECT uid, name, pic_square,is_app_user FROM user WHERE is_app_user =1 AND uid IN
    //    (SELECT uid2 FROM friend WHERE uid1 = me())

// Query to fetch the active user's friends
    NSString *query = @"SELECT uid, name,pic_square FROM user WHERE uid IN " @"(SELECT uid2 FROM friend WHERE uid1 = me())";
    
    // Set up the query parameter
    NSDictionary *queryParam = [NSDictionary dictionaryWithObjectsAndKeys:query, @"q", nil];
    // Make the API request that uses FQL
    [FBRequestConnection startWithGraphPath:@"/fql" parameters:queryParam HTTPMethod:@"GET" completionHandler:callback];
}

-(void)fbFriends {

/////////    1:
    FBRequest* friendsRequest = [FBRequest requestForGraphPath:@"me/friends"];
    [friendsRequest startWithCompletionHandler: ^(FBRequestConnection *connection,
                                                 NSDictionary* result,
                                                 NSError *error) {
        NSLog(@"%@", result);
        
    }];
    
    
///////////    2:
    [FBRequestConnection startForMyFriendsWithCompletionHandler:
     ^(FBRequestConnection *connection, id<FBGraphUser> friends, NSError *error)
     {
         if(!error){
             NSLog(@"results = %@", friends);
         }
     }];
    
}



- (void)requestForFriendsWhoAreUsingTheApp:(void(^)(id result, NSError *error))block{
    
    NSLog(@"requestForFriendsWhoAreUsingTheApp");
    
    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    
    //    SELECT uid, name, pic_square,is_app_user FROM user WHERE is_app_user =1 AND uid IN
    //    (SELECT uid2 FROM friend WHERE uid1 = me())
    NSLog(@"Entered in to the friends requests");
    // Query to fetch the active user's friends, limit to 25.
    NSString *query =
    @"SELECT uid, name,pic_square,is_app_user FROM user WHERE is_app_user =1 AND uid IN "
    @"(SELECT uid2 FROM friend WHERE uid1 = me())";
    // Set up the query parameter
    NSDictionary *queryParam = [NSDictionary dictionaryWithObjectsAndKeys:query, @"q", nil];
    // Make the API request that uses FQL
    [FBRequestConnection startWithGraphPath:@"/fql"  parameters:queryParam  HTTPMethod:@"GET"  completionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        
        if (error) {
            NSLog(@"Error: %@", [error localizedDescription]);
            block(nil,error);
        }
        else {
            block(result,nil);
        }
    }];
    
}


- (void)logout{
    
    [fbSessionObject closeAndClearTokenInformation];
//    token = nil;
//    emailId = nil;
   
  // [FBSession.activeSession closeAndClearTokenInformation];\
    
    [[FBSession activeSession] closeAndClearTokenInformation];
    
    
}
- (BOOL)isSessionStateEffectivelyLoggedIn:(FBSessionState)state {
    BOOL effectivelyLoggedIn;
    
    switch (state) {
        case FBSessionStateOpen:
            effectivelyLoggedIn = YES;
            break;
        case FBSessionStateCreatedTokenLoaded:

            effectivelyLoggedIn = YES;
            break;
        case FBSessionStateOpenTokenExtended:

            effectivelyLoggedIn = YES;
            break;
        default:

            effectivelyLoggedIn = NO;
            break;
    }
    
    return effectivelyLoggedIn;
}

-(void)postOnWall:(NSString*)message{
    
//    NSArray* permissions =  [NSArray arrayWithObjects:
//                             @"publish_stream", nil];    
//    
//    [FBSession openActiveSessionWithReadPermissions:permissions allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
//        
//        postMessage = message;
//        
//        [self sessionStateChanged:session state:status error:error];
//    }];
   
    if (fbSessionObject.isOpen) {
        
        [FBRequestConnection startForPostStatusUpdate:message
                                    completionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
                                        
                                        NSLog(@"Posted: %@",result);
                                        postMessage = nil;
                                    }];
    }
    else{
        
        if (fbSessionObject.state != FBSessionStateCreated) {
            // Create a new, logged out session.
            fbSessionObject = [[FBSession alloc] init];
        }
        
        // if the session isn't open, let's open it now and present the login UX to the user
        [fbSessionObject openWithCompletionHandler:^(FBSession *session,
                                                         FBSessionState status,
                                                         NSError *error) {
            // and here we make sure to update our UX according to the new session state
            NSLog(@"U can Post");
        }];

    }
}

//-(void)postOnFBWall{
//    
//    
//}


-(BOOL) isSessionValid{
    FBSession *activeSession = [FBSession activeSession];
    FBSessionState state = activeSession.state;
    BOOL isLoggedIn = activeSession && [self isSessionStateEffectivelyLoggedIn:state];
    
    return isLoggedIn;
}

#pragma ----  Posting on Wall

-(void)authenticateWithCompletionBlock:(void(^)(FBSession *session,FBSessionState status,NSError *error))callback{
    NSLog(@"authenticateWithCompletionBlock");
    
    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    NSArray *permission = [NSArray arrayWithObjects:@"publish_actions", @"publish_stream", nil];
    [FBSession openActiveSessionWithPublishPermissions:permission defaultAudience:FBSessionDefaultAudienceFriends allowLoginUI:YES completionHandler:callback];
    
    
}


- (void)performPostImageOnUserFBWallWithParams:(NSMutableDictionary *)param  callBackHandler:(FBPostHandler)handler {
    NSLog(@"performPostImageOnUserFBWallWithParams..");

    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    [FBRequestConnection startWithGraphPath:@"me/photos" parameters:param HTTPMethod:@"POST"
                          completionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
                              
                              handler(result , error, nil);
                          }];
    
}


- (void)postImageOnUserFBWallWithParams:(NSMutableDictionary *)param  callBackHandler:(FBPostHandler)handler {

    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    [FBRequestConnection startWithGraphPath:@"me/photos" parameters:param HTTPMethod:@"POST"
                          completionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
                              
                              handler(result , error, nil);
     }];
}


- (void)postImageOnUserWall:(UIImage *)image caption:(NSString *)message  callBackHandler:(FBPostHandler)handler {
    appDelegate.currentUrlToOpen = FACEBOOK_URL;
    NSData *imgData = UIImageJPEGRepresentation(image, 1.0);
    NSMutableDictionary *postParam = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                      message, @"message",
                                      imgData, @"image",
                                      nil];
    
    if (FBSession.activeSession.isOpen) {
        NSLog(@"Posting through Active Session");
        [self performPostImageOnUserFBWallWithParams:postParam callBackHandler:handler];
    }
    else {
        
            NSArray *permission = [NSArray arrayWithObjects:@"publish_actions", @"publish_stream", nil];
            [FBSession openActiveSessionWithPublishPermissions:permission defaultAudience:FBSessionDefaultAudienceEveryone allowLoginUI:YES completionHandler:^(FBSession *session,FBSessionState status,NSError *error) {
                if (error) {
                    NSLog(@"openActiveSession Error");
                }
                else if (FB_ISSESSIONOPENWITHSTATE(status)) {
                    [self performPostImageOnUserFBWallWithParams:postParam callBackHandler:handler];
                }
            }];
        
           }
}


- (void)publishStoryWithDict:(NSMutableDictionary*)dict andBlock:(void (^)(FBRequestConnection *connection,id result,NSError *error))block
{
    [FBRequestConnection startWithGraphPath:@"me/feed" parameters:dict HTTPMethod:@"POST" completionHandler:block];
}


- (void)shareOnFacebook:(NSString*)shareMessage{
        // Add user message parameter if user filled it in
    NSMutableDictionary *postParams = [[NSMutableDictionary alloc] init];
    if (shareMessage) {
        postParams[@"message"] = shareMessage;
        postParams[@"title"] = @"DishGram";
//        postParams[@"og:url"] = @"http//www.dishgram.com";
//        postParams[@"og:image"] = [UIImage imageNamed:@"dishgram_promote.jpeg"];
    }
    
    // Ask for publish_actions permissions in context
    if ([FBSession.activeSession.permissions
         indexOfObject:@"publish_actions"] == NSNotFound) {
        // Permission hasn't been granted, so ask for publish_actions
        [FBSession openActiveSessionWithPublishPermissions:@[@"publish_actions"]
                                           defaultAudience:FBSessionDefaultAudienceFriends
                                              allowLoginUI:YES
                                         completionHandler:^(FBSession *session, FBSessionState state, NSError *error) {
                                             if (FBSession.activeSession.isOpen && !error) {
                                                 // Publish the story if permission was granted
                                                 [self publishStoryWithDict:postParams andBlock:^(FBRequestConnection *connection, id result, NSError *error) {
                                                     
                                                 }];
                                             }
                                         }];
    } else {
        // If permissions present, publish the story
        [self publishStoryWithDict:postParams andBlock:^(FBRequestConnection *connection, id result, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            }
            else{
                NSLog(@"%@",result);
            }
                        
        }];
        
//        id<FBOpenGraphAction> action = (id<FBOpenGraphAction>)[FBGraphObject graphObject];
//        [action setObject:@"https://example.com/book/Snow-Crash.html" forKey:@"book"];
//        
//        [FBDialogs presentShareDialogWithOpenGraphAction:action
//                                              actionType:@"books.reads"
//                                     previewPropertyName:@"book"
//                                                 handler:^(FBAppCall *call, NSDictionary *results, NSError *error) {
//                                                     if(error) {
//                                                         NSLog(@"Error: %@", error.description);
//                                                     } else {
//                                                         NSLog(@"Success!");
//                                                     }
//                                                 }];
        
    }
}

-(void)shareWithGraphAndDictionary:(NSMutableDictionary*)paramDict and:(void(^)(id result, NSError *error))block
{
    
    paramDict [@"name"] = @"Dishgram";
//    paramDict [@"message"] = @"Via Dishgram";
//    paramDict [@"caption"] = @"DishName";
//    paramDict [@"description"] = @"DishDescription";
//    paramDict [@"picture"] = @"https://raw.github.com/fbsamples/ios-3.x-howtos/master/Images/iossdk_logo.png";
//    paramDict [@"link"] = @"http://www.dishgram.com/";
    
    
//    [[NSMutableDictionary alloc] initWithObjectsAndKeys:
//     @"Facebook SDK for iOS", @"name",
//     @"Build great social apps and get more installs.", @"caption",
//     @"The Facebook SDK for iOS makes it easier and faster to develop Facebook integrated iOS apps.", @"description",
//     @"https://developers.facebook.com/ios", @"link",
//     @"https://raw.github.com/fbsamples/ios-3.x-howtos/master/Images/iossdk_logo.png", @"picture",
//     nil];



    // TO DO: Implement share via Graph API
    [FBRequestConnection startWithGraphPath:@"me/feed" parameters:paramDict
     HTTPMethod:@"POST" completionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
     
         if (error) {
             NSLog(@"Error:%@",error.description);
             return block(nil,error);
         }
         else{
             NSLog(@"Successfully Posted");
             return block(result,nil);
         }
     }];
}


//-(void)getParamForShare{
//    
//    // Ask for publish_actions permissions in context
//    if ([FBSession.activeSession.permissions
//         indexOfObject:@"publish_actions"] == NSNotFound) {
//        // No permissions found in session, ask for it
//        [FBSession.activeSession
//         requestNewPublishPermissions:
//         [NSArray arrayWithObject:@"publish_actions"]
//         defaultAudience:FBSessionDefaultAudienceFriends
//         completionHandler:^(FBSession *session, NSError *error) {
//             if (!error) {
//                 // If permissions granted, publish the story
//                 [self publishWithGraphAPI];
//             }
//         }];
//    } else {
//        // If permissions present, publish the story
//        [self publishWithGraphAPI];
//    }
//}



@end
