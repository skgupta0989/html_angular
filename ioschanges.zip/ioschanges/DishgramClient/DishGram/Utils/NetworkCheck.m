//
//  NetworkCheck.m
//  DishGram
//
//  Created by Rags on 07/05/13.
//
//

#import "NetworkCheck.h"
#import "Constant.h"
static NetworkCheck *network =nil;
@implementation NetworkCheck
@synthesize checkReachability;
@synthesize isnetWorkAvailable;


+(id)sharedInstance{
    if(network == nil){
        network = [[NetworkCheck alloc] init];
        
    }
    return  network;
    
}
//- (BOOL)checkWhetherInternetIsAvailable{
//    
//    
//   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkNetworkStatus:) name:kReachabilityChangedNotification object:nil];
//    checkReachability = [Reachability reachabilityForInternetConnection];
//       NetworkStatus status = [checkReachability currentReachabilityStatus];
//    if(status == NotReachable){
//      
//        isnetWorkAvailable=false;
//    }else if(status == ReachableViaWiFi || status == ReachableViaWWAN ){
//       
//        isnetWorkAvailable=true;
//    }
//    [checkReachability startNotifier];
//
//    return isnetWorkAvailable;
//   
//    
//}
//-(void)checkNetworkStatus:(NSNotification *)notice{
//    NetworkStatus status = [checkReachability currentReachabilityStatus];
//    if(status == NotReachable){
//     
//       // isnetWorkAvailable=false;
//        
//    }else if(status == ReachableViaWiFi || status == ReachableViaWWAN ){
//       
//        isnetWorkAvailable=true;
//    }
//
//}
@end
