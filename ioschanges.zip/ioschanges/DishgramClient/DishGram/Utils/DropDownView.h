//
//  DropDownView.h
//  myPlex
//
//  Created by Owner on 11/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface DropDownView : UIView <UITableViewDataSource,UITableViewDelegate>{
    UITableView *dropDownTable;
    NSArray *itemArray;
    int selectedIndex;
    id __weak delegate;
}
@property(nonatomic,strong)   UITableView *dropDownTable;
@property (weak) id delegate;
@property int selectedIndex;
@property (nonatomic, copy) UIView* (^viewProvider)(int index);

- (id)initWithFrame:(CGRect)frame rowHeight:(int)rowHeight objectArray:(NSArray*)objectArray viewPriovider:(UIView*(^)(int index))viewProvider;
@end

@protocol DropDownViewDelegate
- (BOOL)dropDownView:(DropDownView *)dropDownView selectedIndex:(int)selectedIndex;
@end
