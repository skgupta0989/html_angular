//
//  PersistantDataFactory.h
//  DishGram
//
//  Created by Ramesh Varma on 02/07/13.
//
//

#import <Foundation/Foundation.h>
#import "PersistantData.h"

#define HISTORY_DISH_SEARCH @"HISTORY_DISH_SEARCH"
#define HISTORY_LOCATION_SEARCH @"HISTORY_LOCATION_SEARCH"

@interface PersistantDataFactory : NSObject

+(PersistantData *)get:(NSString *)name;

@end
