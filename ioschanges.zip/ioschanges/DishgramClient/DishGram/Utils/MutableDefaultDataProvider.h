//
//  MutableDefaultDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 04/06/13.
//
//

#import <Foundation/Foundation.h>
#import "MutablePagedDataProvider.h"
#import "NVPagedDataView.h"

#define DATA_FETCH_COMPLETE @"DATA_FETCH_COMPLETE"

@interface MutableDefaultDataProvider : NSObject<MutablePagedDataProvider> {
    
}

@property (nonatomic, strong) NSString *url;
@property (nonatomic, strong) Class respType;
@property (nonatomic, strong) NSString *removeUrl;

@property (nonatomic, weak) NVPagedDataView *pagedDataView;
@property (nonatomic) BOOL isState;

-(id)init:(NSString *)reqUrl respType:(Class)respTypeClass removeUrl:(NSString *)removeUrl;
-(id)init:(NSString *)reqUrl respType:(Class)respTypeClass;

-(NSMutableDictionary *)getRequest;
-(NSMutableDictionary *)getRemoveRequest:(NSObject *)data;
-(NSMutableDictionary *)getRequest:(int)index size:(int)size;

// subclasses must override this method to handle connection errors.
-(void)onError:(NSString *)message;
-(NSObject *)getEntity;

// this method is called when ever the response from server is empty set
-(void)responseIsNil;

// this is called when response from server is empty set and startIndex is 0. Subclass can override this method to display custom messages
-(void)noResultsFound;

-(void)noResultsFoundWithImage:(NSString*)imageName;

// called whenever a response is received. called even if the request fails
-(void)gotResponse;

@end
