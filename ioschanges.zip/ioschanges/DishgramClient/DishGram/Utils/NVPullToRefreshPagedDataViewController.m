//
//  NVPullToRefreshPagedDataViewController.m
//  DishGram
//
//  Created by Ramesh Varma on 18/07/13.
//
//

#import "NVPullToRefreshPagedDataViewController.h"
#import "MutableDefaultDataProvider.h"

@interface NVPullToRefreshPagedDataViewController ()

@end

@implementation NVPullToRefreshPagedDataViewController

@synthesize pagedDataView;

-(void)prepare {
    self.pagedDataView.delegate = self;
    [self addPullToRefreshHeader];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [self.pagedDataView tableView:tableView heightForRowAtIndexPath:indexPath];
}

-(void)scrollViewDidScroll:(UIScrollView *)sender
{
    [self.pagedDataView scrollViewDidScroll:sender];
    [super scrollViewDidScroll:sender];
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    [self.pagedDataView scrollViewDidEndScrollingAnimation:scrollView];
    [super scrollViewDidEndScrollingAnimation:scrollView];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.pagedDataView scrollViewWillBeginDragging:scrollView];
    [super scrollViewWillBeginDragging:scrollView];
}

- (void)stopLoading {
    isLoading = NO;
    
    // Hide the header
    [UIView animateWithDuration:0.3 animations:^{
        self.tableView.contentInset = UIEdgeInsetsZero;
        [refreshArrow layer].transform = CATransform3DMakeRotation(M_PI * 2, 0, 0, 1);
    }
                     completion:^(BOOL finished) {
                         // [self performSelector:@selector(stopLoadingComplete)];
                         [self performSelectorOnMainThread:@selector(stopLoadingComplete) withObject:nil waitUntilDone:NO];
                     }];

}

-(void)dataFetchDone {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DATA_FETCH_COMPLETE object:nil];
    // [self stopLoading];
    [self performSelectorOnMainThread:@selector(stopLoading) withObject:nil waitUntilDone:NO];
}

-(void)dealloc {
    self.pagedDataView.delegate = nil;
    @try {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
    @catch (NSException *exception) {
        //
    }
    @finally {
        //
    }

}
-(void)refresh {
    [self refreshDo];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dataFetchDone) name:DATA_FETCH_COMPLETE object:nil];
}

-(void)refreshDo {
    
}

@end
