//
//  WebComboBoxView.h
//  DishGram
//
//  Created by SumanAmit on 02/07/13.
//
//

#import "ComboboxView.h"

@protocol WebComboBoxViewDelegate <NSObject>

- (NSString*)getDesiredUrl:(ComboboxView *)view;
- (Class)getTargetClass:(ComboboxView *)view;
- (NSString *)getTargetMeamber:(ComboboxView *)view;
- (NSMutableDictionary *)getParamDictionary:(ComboboxView *)view;
- (void)selectedOption:(NSObject *)object;
@end

@interface WebComboBoxView : ComboboxView{
    NSString *desiredMeamberOfClass;
}
@property (weak,nonatomic)id<WebComboBoxViewDelegate>delegate;
-(void)getNewData;
-(void)removeDropDownView;
@end
