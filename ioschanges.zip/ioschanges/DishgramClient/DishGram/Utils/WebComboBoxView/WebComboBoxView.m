//
//  WebComboBoxView.m
//  DishGram
//
//  Created by SumanAmit on 02/07/13.
//
//

#import "WebComboBoxView.h"
#import "PageUtil.h"
#import "DataSourceFactory.h"
@implementation WebComboBoxView
@synthesize delegate;
- (id)initWithFrame:(CGRect)frame data:(NSArray *)data ddSize:(int)ddSize placeHolder:(NSString *)placeHolder{
    return [super initWithFrame:frame data:nil ddSize:ddSize placeHolder:placeHolder];
}
-(void)removeDropDownView{
        [PageUtil removeDropDown];
}
-(NSArray *)getFilteredData{
    return nil;
}
-(void)getNewData{
    
    Class webClass=[delegate getTargetClass:self];
    NSString *desiredMeamber=[delegate getTargetMeamber:self];
    desiredMeamberOfClass=desiredMeamber;
    NSString *desireUrl=[delegate getDesiredUrl:self];
    NSMutableDictionary *desireParam=[delegate getParamDictionary:self];
    [desireParam setObject:textField_.text forKey:@"text"];
    
    
    DataSourceInterface *dataSource = [DataSourceFactory getDataSourceInstance];
    [dataSource requestDataWithURLString:desireUrl params:desireParam modelClass:webClass callBack:^(bool success, NSObject *response){
        
        if (success) {

            NSArray *data = (NSArray *)response;
            data_=data;
            NSMutableArray *arr = [[NSMutableArray alloc] init];
            for (int i = 0; i < data.count; ++i) {
                NSObject *targetObject=(NSObject*)[data objectAtIndex:i];
               NSObject *filter=[targetObject valueForKey:desiredMeamber];
                if (filter!=nil) {
                    [arr addObject:filter];
                }
            }
            if (!programSet_) {
                [PageUtil addDropDownBelow:textField_ size:ddSize_ data:arr delegate:self font:@"_dropdown_address_" numLines:1];
                selected_ = NO;
                self.selectedText = nil;
            } else {
                programSet_ = NO;
            }
            
            
            
        }
//        else {
//            [[[iToast makeText:@"Server conneciton failed"]
//              setGravity:iToastGravityTop] show];
//        }
    }];

    
}
-(void)textChanged:(NSNotification *)notification {
    
    [PageUtil removeDropDown];
    if ([textField_.text isEqualToString:@""]) {
        return;
    }
    if (textField_.text.length>=2) {
    [self getNewData];        
    }

    
}

- (BOOL)dropDownViewSelectedIndex:(int)selectedIndex {
    selected_ = YES;
    NSObject *tempObject=[data_ objectAtIndex:selectedIndex];
    self.selectedText = [tempObject valueForKey:desiredMeamberOfClass];
    textField_.text = self.selectedText;
    [PageUtil removeDropDown];
    [delegate selectedOption:tempObject];
    return YES;
}

@end
