//
//  MessageBox.h
//  DishGram
//
//  Created by Satish on 4/30/13.
//
//

#import <UIKit/UIKit.h>


#define MSGBOX_PADDING_X    50
#define MSGBOX_PADDING_Y    -80
#define MSGBOX_WIDTH        210
#define MSGBOX_HEIGHT       80

@interface MessageBox : UIView{
    
    UIView *nibView;
    
    
}

@property(nonatomic, strong) IBOutlet UILabel *messageLabel;

-(void)setMessageString:(NSString*)msg;
- (void)showAndHideAnimationFor:(UIView*)view startPos:(CGRect)startframe endPos:(CGRect)endFrame delayTime:(float)displayTime;

@end
