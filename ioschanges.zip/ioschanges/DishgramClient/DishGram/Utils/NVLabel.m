//
//  NVLabel.m
//  DishGram
//
//  Created by Ramesh Varma on 30/05/13.
//
//

#import "NVLabel.h"
#import "FontUtil.h"

@implementation NVLabel

@synthesize NVFont;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void) setValue:(id)value forKey:(NSString *)key
{
    if ([key isEqualToString:@"NVFont"])
    {
        self.NVFont = value;
        [FontUtil decorate:self];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
