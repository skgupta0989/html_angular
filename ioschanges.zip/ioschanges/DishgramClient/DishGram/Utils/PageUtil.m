//
//  PageUtil.m
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import "PageUtil.h"
#import <QuartzCore/QuartzCore.h>
#import "UIImage+StreatchableImage.h"
#import "FontUtil.h"
#import "NVImageProvider.h"
#import "CacheFactory.h"
#import "DGOptionSet.h"
#import "JsonResponseParser.h"
#import "PlaceCoords.h"
#import "DropDownView.h"
#import "NVSession.h"
#import "AppDelegate.h"
#import "DGLocationManager.h"
#import "ProfileController.h"
#import "DishgramHomeControllerViewController.h"
#import "DisgramTabBarControllerViewController.h"
#import "LoginPromptView.h"
#import "Utilities.h"
#import "ImageCropView.h"

#import "DGImageUploadSingeloton.h"

#define KEYBOARD_HEIGHT 165

#define  STAR_IMG_HEIGHT 9
#define  STAR_IMG_WIDTH 11
#define  STAR_IMG_GAP 2


@implementation PageUtil

int __defaultProfileImageX = 10;
int __defaultProfileImageY = 5;
int __imageFrameWidth = 4;

// location used for last query
PlaceCoords *lastQueryLocation;


+(UIImageView *)profileImageViewWithX:(int)x Y:(int)y {
    return [PageUtil profileImageView:CGRectMake(x, y, DEFAULT_PROFILE_IMAGE_WIDTH, DEFAULT_PROFILE_IMAGE_HEIGHT)];
}

+(UIImageView *)profileImageView {
    return [PageUtil profileImageView:CGRectMake(__defaultProfileImageX, __defaultProfileImageY, DEFAULT_PROFILE_IMAGE_WIDTH, DEFAULT_PROFILE_IMAGE_HEIGHT)];
}

UIImage *circulatFrameImage = nil;
UIImage *defaultCircularImage = nil;

// returns image view for profile picture. This view will be a circle with white border
+(UIImageView *)profileImageView:(CGRect)frame {
    @autoreleasepool {
        UIImageView *view = [[UIImageView alloc]  initWithFrame:frame];
        view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
        
        if (circulatFrameImage == nil) {
            circulatFrameImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"CircularFrame" ofType:@"png"]];
        }
        view.image = circulatFrameImage;
        [view.layer setCornerRadius:view.frame.size.width/2];
        [view.layer setMasksToBounds:YES];
        
        [PageUtil addCircularImageWithFrame:view image:[PageUtil getCroppedLogo]];
        
        return view;
    }
}

// returns image view for profile picture. This view will be a circle with white border
+(void)profileImageViewWithDefaultProfile:(UIImageView *)profileBGView url:(NSString*)URL addProfileHandler:(NSObject *)addProfileHandler {
    @autoreleasepool {
        
        if (defaultCircularImage == nil) {
            defaultCircularImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"CircularBlank" ofType:@"png"]];
        }
        profileBGView.backgroundColor = [UIColor clearColor];
        profileBGView.image = defaultCircularImage;
        profileBGView.userInteractionEnabled = YES;
        
        if (!URL) {
            if (addProfileHandler != nil) {
                [self addProfileHandler:profileBGView parent:addProfileHandler];
            }
            
            return;
        }
//        [self addProfileHandler:profileBGView parent:addProfileHandler];
//        return;
        
        
        // When Image URL exists
        UIImageView *userImgView = [[UIImageView alloc]  initWithFrame:CGRectMake(2,2, profileBGView.frame.size.width-4, profileBGView.frame.size.height-4)];
        [profileBGView addSubview:userImgView];
       
//        [PageUtil makeImageCircular:userImgView withImage:(UIImage*)defaultCircularImage];
        
       
        if (addProfileHandler != nil) {
            [self addProfileHandler:userImgView parent:addProfileHandler];
        }
        
        
        
        __weak UIImageView *weakUserImgView = userImgView;
        [NVImageProvider getImage:CACHE_NAME_FB_IMAGE
                              url:URL prefetch:nil
                         callBack:^(NSObject *data) {
                             
                             if (data != nil) {
                                 @autoreleasepool {
                                     __weak UIImageView *strongProfileView = weakUserImgView;
                                     
                                     [self performSelectorOnMainThread:@selector(update:)
                                                            withObject:^{
                                                                [PageUtil makeImageCircular:strongProfileView withImage:(UIImage*)data];
                                                                                                                                                                                           }
                                                         waitUntilDone:false];
                                 }
                             }
                             
                         }
                    errorCallBack:nil];

    }
    
}


+(UIImageView *)defaultScalableBorderImage:(int)width height:(int)height {
    @autoreleasepool {
        
        NSString *uKey = [NSString stringWithFormat:@"dsbi_%d_%d", width, height];
        
        UIImage *defaultBg = [self getFromCache:uKey];
        if (defaultBg == nil) {
            defaultBg = [[UIImage imageNamed:@"RectangleFrame"]
                         stretchImageWithCapInsets:UIEdgeInsetsMake(5, 15, 15, 15) toSize:CGSizeMake(width, height)];
            [self addToCache:uKey value:defaultBg];
        }
        
        int __margin = 0;
        UIImageView * view = [[UIImageView alloc] initWithFrame:CGRectMake(__margin,__margin,width - 2*__margin,height - 2*__margin)];
        view.image = defaultBg;
        [PageUtil addImageWithFrame:view image:[PageUtil getDishPlaceHolderImage] frameWidth:4 fitType:FitTypeAspect];
        
        return view;
    }
    
}

UIImage *croppedLogo = nil;
+(UIImage *)getCroppedLogo {
    
    if (croppedLogo == nil) {
        UIImage *logo = [UIImage imageNamed:@"BlackCircular.png"];
        int extraSpacing = 15;
        logo = [logo cutout:CGRectMake(extraSpacing, logo.size.height - logo.size.width + extraSpacing + 4, logo.size.width - 2*extraSpacing, logo.size.width - 2*extraSpacing)];
        croppedLogo = logo;
    }
    return croppedLogo;
}

+(UIView *)restHeaderScalableTile:(int)width height:(int)height {
    int __margin = 2;
    // int __topPart = 30;
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    
    UIImageView *topImage = [PageUtil scalablePageTile:320 height:height - 2*__margin forName:@"rest_bg" withEdges:UIEdgeInsetsMake(50, 15, 15, 150)];
    
    [view addSubview:topImage];
    
    /*
     UIImageView *bottomImage = [PageUtil scalablePageTile:width height:height - __topPart + __margin forName:@"rest_details_bg" withEdges:UIEdgeInsetsMake(15, 15, 15, 150)];
     bottomImage.frame = CGRectMake(bottomImage.frame.origin.x, bottomImage.frame.origin.y + __topPart - 2*__margin, bottomImage.frame.size.width, bottomImage.frame.size.height);
     
     [view addSubview:bottomImage];
     */
    
    view.tag = TAG_DEFAULT_BG;
    return view;
}

+(UIImageView *)defaultScalableExploreTile:(int)width height:(int)height {
    UIImageView * view = [PageUtil scalablePageTile:width height:height forName:@"explore-back" withEdges:UIEdgeInsetsMake(20, 50, 20, 50)];
    view.tag = TAG_DEFAULT_BG;
    return view;
}

UIImage *defaultScalableTileRibon = nil;

+(UIImageView *)defaultScalableTile:(int)width height:(int)height {
    int __margin = 4;
    
    UIImageView * view = [PageUtil scalablePageTile:width height:height forName:@"bg"];
    
    // add bottom ribbon
    {
        if (defaultScalableTileRibon == nil) {
            defaultScalableTileRibon = [[[UIImage imageNamed:@"ribon"] cutout:CGRectMake(0, 0, 8, 5)] stretchImageWithCapInsets:UIEdgeInsetsMake(3, 1, 1, 1) toSize:CGSizeMake(8, 17)];
        }
        UIImageView *tagViewBottom = [[UIImageView alloc] initWithFrame:CGRectMake(30, height - 2*__margin - 10,8,17)];
        tagViewBottom.image = defaultScalableTileRibon;
        
        [view addSubview:tagViewBottom];
        [view sendSubviewToBack:tagViewBottom];
    }
    
    // add top ribbon
    {
        [PageUtil addTopRibon:view];
    }
    
    
    // view.image = defaultBg;
    view.tag = TAG_DEFAULT_BG;
    return view;
}

+(void)addTopRibon:(UIView *)view {
    [PageUtil addTopRibon:(UIView *)view withHeight:20 offSet:-4];
}

NSMutableDictionary *pageUtilImageCache = nil;

+(UIImage *)getFromCache:(id)key {
    if (pageUtilImageCache == nil) {
        pageUtilImageCache = [[NSMutableDictionary alloc] init];
        return nil;
    } else {
        return [pageUtilImageCache objectForKey:key];
    }
}

+(void)addToCache:(id)key value:(UIImage *)cachedObject {
    if (pageUtilImageCache == nil) {
        pageUtilImageCache = [[NSMutableDictionary alloc] init];
    }
    [pageUtilImageCache setObject:cachedObject forKey:key];
}

+(void)addTopRibon:(UIView *)view withHeight:(int)height offSet:(int)offSet {
    NSString *uKey = [NSString stringWithFormat:@"atr_%d_%d", height, offSet ];
    UIImage *tagViewImage = [self getFromCache:uKey];
    
    if (tagViewImage == nil) {
        tagViewImage= [[[UIImage imageNamed:@"ribon"] cutout:CGRectMake(0, 2, 8, 13) ]
                       stretchImageWithCapInsets:UIEdgeInsetsMake(2, 1, 10, 1) toSize:CGSizeMake(8, height)];
        [self addToCache:uKey value:tagViewImage];
    }

    UIImageView *tagViewTop = [[UIImageView alloc] initWithFrame:CGRectMake(30, offSet,8,height)];
    tagViewTop.image = tagViewImage;
    
    [view addSubview:tagViewTop];
}

+(UIImageView *)defaultScalablePageTile:(int)width height:(int)height {
    return [PageUtil scalablePageTile:width height:height forName:@"RectangleFrame"];
}

+(UIImageView *)scalablePageTile:(int)width height:(int)height forName:(NSString *)name {
    return [PageUtil scalablePageTile:width height:height forName:name withEdges:UIEdgeInsetsMake(5, 15, 15, 15)];
}


+(UIImageView *)scalablePageTile:(int)width height:(int)height forName:(NSString *)name withEdges:(UIEdgeInsets)edges {
    int __margin = 4;
    
    
    NSString *uKey = [NSString stringWithFormat:@"spthfw_%d_%d_%@",width, height, name];
    UIImage *defaultBg = [self getFromCache:uKey];
    
    if (defaultBg == nil) {
        defaultBg = [[UIImage imageNamed:name] stretchImageWithCapInsets:edges toSize:CGSizeMake(width, height)];
        [self addToCache:uKey value:defaultBg];
    }
    
    UIImageView * defaultBgview = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,width - 2*__margin,height - 2*__margin)];
    defaultBgview.image = defaultBg;
    
    UIImageView * view = [[UIImageView alloc] initWithFrame:CGRectMake(__margin,__margin,width - 2*__margin,height - 2*__margin)];
    // [view addSubview:tagViewBottom];
    [view addSubview:defaultBgview];
    // view.image = defaultBg;
    
    return view;
}

+(UIImageView *)scalableShadedBGTile:(int)width height:(int)height forName:(NSString *)name {
    return [PageUtil scalableShadedBGTile:width height:height forName:name withEdges:UIEdgeInsetsMake(5, 15, 15, 15)];
}

+(UIImageView *)scalableShadedBGTile:(int)width height:(int)height forName:(NSString *)name withEdges:(UIEdgeInsets)edges {
    int __margin = 4;
    
    NSString *uKey = [NSString stringWithFormat:@"ssbgthfw_%d_%d_%@",width, height, name];
    UIImage *defaultBg = [self getFromCache:uKey];
    
    if (defaultBg == nil) {
        defaultBg = [[UIImage imageNamed:name]
                     stretchImageWithCapInsets:edges toSize:CGSizeMake(width, height)];
        [self addToCache:uKey value:defaultBg];
    }

    UIImageView * defaultBgview = [[UIImageView alloc] initWithFrame:CGRectMake(4,4,width - 2*__margin,height - 2*__margin)];
    defaultBgview.image = defaultBg;
    
    return defaultBgview;
}

+(UIImageView *)hScalablePageTile:(int)width forName:(NSString *)name position:(int)vPosition{
    int __margin = 4;
    
    NSString *uKey = [NSString stringWithFormat:@"hsptfp_%d_%@",width, name];
    UIImage *defaultBg = [self getFromCache:uKey];
    
    if (defaultBg == nil) {
        UIImage *rawImage = [UIImage imageNamed:name];
        defaultBg = [rawImage
                              stretchImageWithCapInsets:UIEdgeInsetsMake(1, 15, 1, 15) toSize:CGSizeMake(width, rawImage.size.height)];
        [self addToCache:uKey value:defaultBg];
    }
    

    UIImageView * defaultBgview = [[UIImageView alloc] initWithFrame:CGRectMake(__margin,vPosition,defaultBg.size.width, defaultBg.size.height)];
    defaultBgview.image = defaultBg;
    return defaultBgview;
}

UIImage *starRating0 = nil;
UIImage *starRating1 = nil;
UIImage *starRating2 = nil;
UIImage *starRating3 = nil;
UIImage *starRating4 = nil;
UIImage *starRating5 = nil;
UIImage *starRed = nil;
UIImage *starGray = nil;

// 61x9
+(UIImage *)starRatingImage:(float)rating {

    int adjustedRating = rating + .5;
    UIImage *retImage = nil;
    
    switch (adjustedRating) {
        case 0:
            retImage = starRating0;
            break;
        case 1:
            retImage = starRating1;
            break;
        case 2:
            retImage = starRating2;
            break;
        case 3:
            retImage = starRating3;
            break;
        case 4:
            retImage = starRating4;
            break;
        default:
            retImage = starRating5;
            break;
    }
    
    if (retImage != nil) return retImage;
    
    if (starRed == nil) {
        starRed = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"star-red" ofType:@"png"]];
        starGray = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"star" ofType:@"png"]];
    }
    
    UIGraphicsBeginImageContext(CGSizeMake(5*STAR_IMG_WIDTH - STAR_IMG_GAP, STAR_IMG_HEIGHT));
    
    // determine howmany active/inactive starts to add
    for (int i = 1; i <= 5; ++i) {
        
        if (adjustedRating < i) {
            CGRect location = CGRectMake(STAR_IMG_WIDTH*(i - 1), 0, STAR_IMG_WIDTH - STAR_IMG_GAP - 1, STAR_IMG_HEIGHT);
            [starGray drawInRect:location];
        } else {
            CGRect location = CGRectMake(STAR_IMG_WIDTH*(i - 1), 0, STAR_IMG_WIDTH - STAR_IMG_GAP, STAR_IMG_HEIGHT);
            [starRed drawInRect:location];
        }
    }
    
    retImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    switch (adjustedRating) {
        case 0:
            starRating0 = retImage;
            break;
        case 1:
            starRating1 = retImage;
            break;
        case 2:
            starRating2 = retImage;
            break;
        case 3:
            starRating3 = retImage;
            break;
        case 4:
            starRating4 = retImage;
            break;
        default:
            starRating5 = retImage;
            break;
    }
    
    return retImage;
}
#pragma mark
#pragma mark single line separator in table view
+(UIView *)createSeparatorLineInTable:(CGRect)frame{
    
    UIView *separatorView = [[UIView alloc] initWithFrame:frame];
    separatorView.backgroundColor = [UIColor colorWithRed:218.0/255 green:218.0/255 blue:218.0/255 alpha:1.0];
    return separatorView;
    
}
#pragma  mark
#pragma mark commom color used in all screens
+(UIColor*)getColor{
    return [UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0];
}

+(void)addImageWithFrame:(UIImageView *)parent image:(id)image {
    [PageUtil addImageWithFrame:parent image:image frameWidth:__imageFrameWidth];
}

+(void)addImageWithFrame:(UIImageView *)parent image:(id)image frameWidth:(int)frameWidth {
    [PageUtil addImageWithFrame:parent image:image frameWidth:frameWidth  fitType:FitTypeStretch];
}

+(void)addImageWithFrame:(UIImageView *)parent image:(id)image frameWidth:(int)frameWidth  fitType:(FitType)fitType {
    
    @autoreleasepool {
        if (image == nil) return;
        
        UIImage *uiImage = (UIImage *)image;
        
        float viewWidth = parent.frame.size.width - frameWidth*2 - 1;
        float viewHeight = parent.frame.size.height - frameWidth*2 - 1;
        
        UIImageView *subView = [[UIImageView alloc] initWithFrame:CGRectMake(frameWidth, frameWidth, viewWidth, viewHeight)];
        
        [subView clipsToBounds];
        
        [subView.layer setBackgroundColor:[UIColor whiteColor].CGColor];
        
        
        switch (fitType) {
                
            case FitTypeAspect:
                subView.contentMode = UIViewContentModeScaleAspectFit;
                break;
            case FitTypeAspectVClip:
                subView.contentMode = UIViewContentModeScaleAspectFill;
                [subView.layer setMasksToBounds:true];
                // [subView clipsToBounds];
                break;
            case FitTypeAspectVExpand: {
                float viewNewHeight = uiImage.size.height*viewWidth/uiImage.size.width;
                subView.frame = CGRectMake(frameWidth, frameWidth, viewWidth, viewNewHeight);
                parent.frame = CGRectMake(parent.frame.origin.x, parent.frame.origin.y, parent.frame.size.width, viewNewHeight + frameWidth*2);
                break;
            }
            case FitTypeStretch:
            default:
                subView.contentMode = UIViewContentModeScaleToFill;
                break;
        }
        
        subView.image = uiImage;
        
        [parent addSubview:subView];
    }
}

+(void)addCircularImageWithFrame:(UIImageView *)parent image:(id)image {
    @autoreleasepool {
        
        UIImage *uiImage = (UIImage *)image;
        
        UIImageView *subView = [[UIImageView alloc] initWithFrame:CGRectMake(__imageFrameWidth, __imageFrameWidth, parent.frame.size.width - __imageFrameWidth*2, parent.frame.size.height - __imageFrameWidth*2)];
        [subView.layer setBackgroundColor:[UIColor whiteColor].CGColor];
        
        subView.image = uiImage;
        [subView.layer setCornerRadius:subView.frame.size.width/2];
        [subView.layer setBackgroundColor:[UIColor whiteColor].CGColor];
        [subView.layer setMasksToBounds:YES];
        [parent addSubview:subView];
    }
}

+(void)makeImageCircular:(UIImageView*)imageView withImage:(UIImage*)dataImage{
    
    [imageView.layer setCornerRadius:imageView.frame.size.width/2];
    [imageView.layer setMasksToBounds:YES];
    imageView.image = dataImage;
}


+(void)makeImageCircular:(UIImageView*)imageView{
    
    [imageView.layer setCornerRadius:imageView.frame.size.width/2];
    [imageView.layer setMasksToBounds:YES];
}

+(UIImageView *)shaedeBackgroundImage:(CGRect)frame{
    UIImageView *view = [[UIImageView alloc]  initWithFrame:frame];
    view.image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"filter_bg" ofType:@"png"]];
    return view;
}

+(NSString *)dateToDays:(NSString *)date {
    
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'Z'"];
    [dateFormat setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    NSDate *dateObj = [dateFormat dateFromString:date];
    NSTimeInterval timeInt = -[dateObj timeIntervalSinceNow];
    
    if (timeInt < 0) timeInt = 0;
    
    if (timeInt < 60) {
        return @"few secs ago";
    } else if (timeInt < 60*60 ) {
        int num = (int)(timeInt/(float)60);
        if (num == 1) {
            return @"1 min ago";
        } else {
            return [NSString stringWithFormat:@"%d mins ago", num];
        }
        
    } else if (timeInt < 60*60*24 ) {
        int num = (int)(timeInt/((float)(60*60)));
        
        if (num == 1) {
            return @"1 hr ago";
        } else {
            return [NSString stringWithFormat:@"%d hrs ago", num];
        }
        
    } else if (timeInt < 60*60*24*30 ) {
        int num = (int)(timeInt/(float)(60*60*24));
        if (num == 1) {
            return @"1 day ago";
        } else {
            return [NSString stringWithFormat:@"%d days ago", num];
        }
    } else if (timeInt < 60*60*24*365 ) {
        unsigned int num = (int)(timeInt/(float)(60*60*24*30));
        if (num == 12) {
            num = 11;
        }
        
        if (num == 1) {
            return @"1 month ago";
        } else {
            return [NSString stringWithFormat:@"%d months ago", num];
        }
        
    } else {
        int num = (int)(timeInt/(60*60*24*365));
        
        if (num == 1) {
            return @"1 year ago";
        } else {
            return [NSString stringWithFormat:@"%d years ago", num];
        }
    }
    
}


+(UIView *)loadDecoratedView:(UIView *)target nibName:(NSString *)nibName {
    @autoreleasepool {
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:nibName owner:target options:nil];
        UIView *view = [array objectAtIndex:0];
        [FontUtil decorateView:view];
        [target addSubview:view];
        return view;
    }
}

+(void)reposition:(UIView *)target below:(UIView *)below {
    return [PageUtil reposition:target below:below withMargin:0];
}

+(void)reposition:(UIView *)target below:(UIView *)below withMargin:(float)margin {
    CGRect originalFrame = target.frame;
    float originY = margin;
    if (below != nil) {
        originY += below.frame.origin.y + below.frame.size.height;
    }
    
    target.frame = CGRectMake(originalFrame.origin.x, originY, originalFrame.size.width, originalFrame.size.height);
}


+(void)resize:(UIView *)target toEnvelop:(UIView *)sub {
    return [PageUtil resize:target toEnvelop:sub withMargin:0];
}
+(void)resize:(UIView *)target toEnvelop:(UIView *)sub withMargin:(int)margin {
    CGRect targetFrame = target.frame;
    target.frame = CGRectMake(targetFrame.origin.x, targetFrame.origin.y, targetFrame.size.width, sub.frame.origin.y + sub.frame.size.height + margin);
}

+(UIImage *)getProfilePlaceHolderImage {
    // return [self getDishPlaceHolderImage];
    
    if (profileCroppedLogo == nil) {
        profileCroppedLogo = [UIImage imageNamed:@"CircularBlank.png"];
    }
    return profileCroppedLogo;
    
}

UIImage *profileCroppedLogo = nil;
UIImage *dishPlaceCroppedImage = nil;

+(UIImage *)getDishPlaceHolderImage {
    if (dishPlaceCroppedImage == nil) {
        dishPlaceCroppedImage = [UIImage imageNamed:@"logo-big-default.png"];
    }
    return dishPlaceCroppedImage;
}


+(void)fetchPofileImageWithoutPlaceHolder:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify {
    if(!url) return;
    
    UIActivityIndicatorView *indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    indicatorView.frame = CGRectMake(profileView.frame.size.width/2-15, profileView.frame.size.height/2-15, 30, 30);
    [profileView addSubview:indicatorView];
    [indicatorView startAnimating];
    
    __weak UIImageView *weakProfileView = profileView;
    [NVImageProvider getImage:CACHE_NAME_FB_IMAGE
                          url:url prefetch:nil
                     callBack:^(NSObject *data) {
                         
                         if (data != nil) {
                             @autoreleasepool {
                                 __weak UIImageView *strongProfileView = weakProfileView;
                                 
                                 [self performSelectorOnMainThread:@selector(update:)
                                                        withObject:^{
                                                            [PageUtil makeImageCircular:strongProfileView withImage:(UIImage*)data];
                                                            if (notify) {
                                                                notify(true);
                                                            }
                                                            [indicatorView stopAnimating];
                                                            [indicatorView removeFromSuperview];
                                                        }
                                                     waitUntilDone:false];
                             }
                             
                         }
                         else{
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [indicatorView stopAnimating];
                                 [indicatorView removeFromSuperview];
                             });
                             
                         }
                     }
                errorCallBack:nil];
}

+(void)fetchCoverImageWithoutPlaceHolder:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify {
    if(!url) return;
    
    UIActivityIndicatorView *indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    indicatorView.frame = CGRectMake(profileView.frame.size.width/2-15, profileView.frame.size.height/2-15, 30, 30);
    [profileView addSubview:indicatorView];
    [indicatorView startAnimating];
    
    __weak UIImageView *weakProfileView = profileView;
    [NVImageProvider getImage:CACHE_NAME_FB_IMAGE
                          url:url prefetch:nil
                     callBack:^(NSObject *data) {
                         
                         if (data != nil) {
                             @autoreleasepool {
                                 __weak UIImageView *strongProfileView = weakProfileView;
                                 
                                 [self performSelectorOnMainThread:@selector(update:)
                                                        withObject:^{
//                                                            [PageUtil makeImageCircular:strongProfileView withImage:(UIImage*)data];
                                                            strongProfileView.image = (UIImage*)data;
                                                            if (notify) {
                                                                notify(true);
                                                            }
                                                            [indicatorView stopAnimating];
                                                            [indicatorView removeFromSuperview];
                                                        }
                                                     waitUntilDone:false];
                             }
                             
                         }
                         else{
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [indicatorView stopAnimating];
                                 [indicatorView removeFromSuperview];
                             });
                             
                         }
                     }
                errorCallBack:nil];
}
+(void)fetchCircularDishImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify {
    [self fetchCircularImage:profileView url:url notify:notify imagePlaceHolder:[PageUtil getDishPlaceHolderImage]];
}

+(void)fetchPofileImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify {
    [self fetchCircularImage:profileView url:url notify:notify imagePlaceHolder:[PageUtil getProfilePlaceHolderImage]];
}

+(void)fetchCircularImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify imagePlaceHolder:(UIImage *)placeHolder {
    [PageUtil addCircularImageWithFrame:profileView image:placeHolder];
    profileView.alpha = 1.0;
    
    if(!url) return;
    __weak UIImageView *weakProfileView = profileView;
    [NVImageProvider getImage:CACHE_NAME_FB_IMAGE
                          url:url prefetch:nil
                     callBack:^(NSObject *data) {
                         
                         if (data != nil) {
                             @autoreleasepool {
                                 __weak UIImageView *strongProfileView = weakProfileView;
                                 
                                 [self performSelectorOnMainThread:@selector(update:)
                                                        withObject:^{

                                                            strongProfileView.alpha = 0.0;
                                                            [PageUtil addCircularImageWithFrame:strongProfileView image:data];
                                                            if (notify) {
                                                                notify(true);
                                                            }
                                                            [UIView animateWithDuration:.1 animations:^{
                                                                strongProfileView.alpha = 1.0;
                                                            }];
                                                        }
                                                     waitUntilDone:false];
                             }
                         
                         }
                     }
                errorCallBack:nil];
}
+(void)fetchSquareDishImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify addProfileHandler:(NSObject *)addProfileHandler{
    [self fetchSquareImage:profileView url:url notify:notify addProfileHandler:addProfileHandler imagePlaceHolder:[PageUtil getDishPlaceHolderImage]];
}
+(void)fetchSquarePofileImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify addProfileHandler:(NSObject *)addProfileHandler{
    [self fetchSquareImage:profileView url:url notify:notify addProfileHandler:addProfileHandler imagePlaceHolder:[PageUtil getProfilePlaceHolderImage]];
}
+(void)fetchSquareImage:(UIImageView *)profileView url:(NSString *)url notify:(void (^)(bool result))notify addProfileHandler:(NSObject *)addProfileHandler imagePlaceHolder:(UIImage *)placeHolder{
    [PageUtil addImageWithFrame:profileView image:placeHolder frameWidth:0];
    profileView.alpha = 1.0;
    if (addProfileHandler != nil) {
        [self addProfileHandler:profileView parent:addProfileHandler];
    }
    
    if(!url) return;
    
    __weak UIImageView *weakProfileView = profileView;
    
    
    [NVImageProvider getImage:CACHE_NAME_FB_IMAGE
                          url:url prefetch:nil
                     callBack:^(NSObject *data) {
                         if (data != nil) {
                             @autoreleasepool {
                                 __weak UIImageView *strongProfileView = weakProfileView;
                                 
                                 [self performSelectorOnMainThread:@selector(update:)
                                                withObject:^{

                                                    strongProfileView.alpha = 0.0;
                                                    [PageUtil addImageWithFrame:strongProfileView image:data frameWidth:0];
                                                    if (notify) {
                                                        notify(true);
                                                    }
                                                    [UIView animateWithDuration:.1 animations:^{
                                                        strongProfileView.alpha = 1.0;
                                                    }];
                                                }
                                             waitUntilDone:false];
                             }
                         }
                     }
                errorCallBack:nil];
}

+(void)addProfileHandler:(UIView *)view parent:(NSObject *)parent {
    view.userInteractionEnabled = YES;
    UITapGestureRecognizer *profileTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:parent action:@selector(profileViewTapped)];
    [view addGestureRecognizer:profileTapGesture];
}


+(void)fetchDishImage:(UIImageView *)dishView url:(NSString *)url notify:(void (^)(bool result))notify  fitType:(FitType)type {
    @autoreleasepool {
        dishView.alpha = 1.0;
        [PageUtil addImageWithFrame:dishView image:[PageUtil getDishPlaceHolderImage]];
    }
    
    if(!url) return;
    
    __weak UIImageView *weakDishView = dishView;
    
        [NVImageProvider getImage:CACHE_NAME_DISH_IMAGE
                              url:url prefetch:nil
                         callBack:^(NSObject *data) {
                             @autoreleasepool {
                             if (data != nil) {
                                 UIImageView *strongDishView = weakDishView;
                                 if (strongDishView != nil) {
                                     [self performSelectorOnMainThread:@selector(update:)
                                                        withObject:^{
                                                            @autoreleasepool {

                                                                strongDishView.alpha = 0.0;
                                                                [PageUtil addImageWithFrame:strongDishView image:data frameWidth:__imageFrameWidth fitType:type];
                                                                if (notify) {
                                                                    notify(true);
                                                                }
                                                                [UIView animateWithDuration:0.2 animations:^{
                                                                    strongDishView.alpha = 1.0;
                                                                }];
                                                            }
                                                            
                                                        }
                                                     waitUntilDone:false];
                                 }
                             }
                             }
                         }
                    errorCallBack:nil];

}

+(void)update:(void (^)(void))updateDo {
    updateDo();
}

+(void)shrinkForKeyboard:(UIView *)view {
    CGRect viewFrame = view.frame;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:.2];
        view.frame = CGRectMake(viewFrame.origin.x, viewFrame.origin.y, viewFrame.size.width, viewFrame.size.height - KEYBOARD_HEIGHT);
    [UIView commitAnimations];

}

+(void)expandAfterKeyboard:(UIView *)view {
    CGRect viewFrame = view.frame;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:.2];
        view.frame = CGRectMake(viewFrame.origin.x, viewFrame.origin.y, viewFrame.size.width, viewFrame.size.height + KEYBOARD_HEIGHT);
    [UIView commitAnimations];
 
}

+(void)decorate:(UIView *)view decorationName:(DecorationType)decoration {
    
    NSString *uniqueDecKey = [NSString stringWithFormat:@"dec_%d_%f_%f",decoration,view.frame.size.width,view.frame.size.height];
    UIImage *cachedImage = [self getFromCache:uniqueDecKey];
    
    if (cachedImage == nil) {
        UIColor *sideLineColor = [UIColor colorWithRed:.8 green:.8 blue:.8 alpha:1];
        UIColor *bottomLine1Color = [UIColor colorWithRed:.7 green:.7 blue:.7 alpha:1];
        UIColor *bottomLine2Color = [UIColor colorWithRed:1 green:1 blue:1 alpha:1];
        UIColor *bottomLine1ColorForList = [UIColor colorWithRed:.8 green:.8 blue:.8 alpha:1];
        
        UIGraphicsBeginImageContext(view.frame.size);
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        switch (decoration) {
            case DecorationTypeList:
            case DecorationTypeLoves:
                // draw bottom grey
                [PageUtil addHLine:view.frame.size.height - 1 start:5 end:view.frame.size.width - 8 context:context color:bottomLine1ColorForList];
                
                // draw left line
                [PageUtil addVLine:0 start:0 end:view.frame.size.height context:context color:sideLineColor];
                
                // draw right line
                [PageUtil addVLine:view.frame.size.width - 1 start:0 end:view.frame.size.height context:context color:sideLineColor];
                break;
            case DecorationTypeComment: {
                
                // draw bottom grey
                [PageUtil addHLine:view.frame.size.height - 2 start:2 end:view.frame.size.width - 3 context:context color:bottomLine1Color];
                
                // draw bottom white
                [PageUtil addHLine:view.frame.size.height - 1 start:2 end:view.frame.size.width - 3 context:context color:bottomLine2Color];
                
                
                // draw mid line
                [PageUtil addVLine:(decoration ==  DecorationTypeList)?52:47 start:10 end:view.frame.size.height - 13 context:context color:sideLineColor];
                
            }
            case DecorationTypeAddComment:
                // draw left line
                [PageUtil addVLine:0 start:0 end:view.frame.size.height - 1 context:context color:sideLineColor];
                
                // draw right line
                [PageUtil addVLine:view.frame.size.width - 1 start:0 end:view.frame.size.height - 1 context:context color:sideLineColor];
                
            default: {
                
            }
        }
        
        // Create new image
        cachedImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        [self addToCache:uniqueDecKey value:cachedImage];
    }
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:view.frame];
    imageView.image = cachedImage;
    
    [view addSubview:imageView];

}

+(void)decorateAddCommentBox:(UITextField *)textField {
    // UIColor *bottomLine1Color = [UIColor colorWithRed:.5 green:.5 blue:.5 alpha:1];
    
    UIGraphicsBeginImageContext(CGSizeMake(textField.frame.size.width + 10, textField.frame.size.height));
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    textField.clipsToBounds = NO;
    
    {
        // add bottom line
        CGRect triangleArea = CGRectMake(3, 0, 8, 10);
        
        // draw triangle
        CGContextBeginPath(context);
        CGContextMoveToPoint   (context, CGRectGetMinX(triangleArea), CGRectGetMaxY(triangleArea));  // top left
        CGContextAddLineToPoint(context, CGRectGetMaxX(triangleArea), CGRectGetMaxY(triangleArea));  // mid right
        CGContextAddLineToPoint(context, CGRectGetMaxX(triangleArea), CGRectGetMinY(triangleArea));  // bottom left
        CGContextClosePath(context);
        
        CGContextSetRGBFillColor(context, 1, 1, 1, 1);
        CGContextFillPath(context);
    }
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(-10, 0, textField.frame.size.width, textField.frame.size.height)];
    imageView.image = newImage;
    [textField addSubview:imageView];
    UIGraphicsEndImageContext();
}

+(void)addHLine:(int)hPosition start:(int)start end:(int)end context:(CGContextRef)context color:(UIColor *)color {
    CGContextSetStrokeColorWithColor(context, [color CGColor]);
    CGContextSetLineWidth(context, 1.0);
    CGContextMoveToPoint(context, 0.5 + start, 0.5 + hPosition);
    CGContextAddLineToPoint(context, 0.5 + end, 0.5 + hPosition);
    CGContextStrokePath(context);
}

+(void)addVLine:(int)vPosition start:(int)start end:(int)end context:(CGContextRef)context color:(UIColor *)color {
    CGContextSetStrokeColorWithColor(context, [color CGColor]);
    CGContextSetLineWidth(context, 1.0);
    CGContextMoveToPoint(context, 0.5 + vPosition, 0.5 + start);
    CGContextAddLineToPoint(context, 0.5 + vPosition, 0.5 + end);
    CGContextStrokePath(context);
}

+(void)addDashedHLine:(int)hPosition start:(int)start end:(int)end context:(CGContextRef)context color:(UIColor *)color {
    
    CGFloat dashPattern[]= {2.0, 1};
    CGContextSetStrokeColorWithColor(context, [color CGColor]);
    CGContextSetLineWidth(context, 1.0);
    
    CGContextMoveToPoint(context, 0.5 + start, 0.5 + hPosition);
    CGContextAddLineToPoint(context, 0.5 + end, 0.5 + hPosition);
    
    CGContextSetLineDash(context, 0.0, dashPattern, 2);
    CGContextDrawPath(context, kCGPathFillStroke);
    
}

+(UIImageView *)addDashedHLine:(int)hPosition start:(int)start end:(int)end  color:(UIColor *)color ofView:(UIView *)view{
    
    UIGraphicsBeginImageContext(view.frame.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    [PageUtil addDashedHLine:hPosition start:start end:end context:context color:color];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIImageView * imageView = [[UIImageView alloc] initWithImage:newImage];
    
    UIGraphicsEndImageContext();
    
    return imageView;
    
}
+(void)pageBottomWithTag:(UIView *)view {
    
    // add bottom page
    
    UIView *bottomPage = [PageUtil defaultScalablePageTile:320 height:300];
    bottomPage.frame = CGRectMake(bottomPage.frame.origin.x, 10, bottomPage.frame.size.width, bottomPage.frame.size.height);
    
    [view addSubview:bottomPage];
    
    // add top ribbon
    [PageUtil addTopRibon:view withHeight:30 offSet:-4];
    
    [self addTopGrayShadow:view];
}

+(void)addTopGrayShadow:(UIView *)view {
    // add top gray shadow
    UIView *topShadow = [PageUtil hScalablePageTile:view.frame.size.width forName:@"shadow" position:-4];
    topShadow.tag = TAG_TOP_SHADOW;
    [view addSubview:topShadow];
}

+(CGSize)calculateLabelWidthFromString:(NSString*)str andFont:(UIFont*)font{
    
    CGSize textSize = [str sizeWithFont:font];
    
    return textSize;
}

+(void)trimField:(UITextField *)view {
    view.text = [view.text stringByTrimmingCharactersInSet:
                 [NSCharacterSet whitespaceCharacterSet]];
}

+(DGOptionSet *)foodBeverageOptionSet:(NSObject *)tagert width:(float)width height:(float)height action:(SEL)action context:(NSMutableDictionary *)userContext {
    NSMutableDictionary *context=nil;;
    if (userContext==nil) {
        context = [[NSMutableDictionary alloc] init];
        [context setObject:[UIImage imageNamed:@"radiobtn-active.png"] forKey:OPTION_SELECTED_IMAGE];
        [context setObject:[UIColor colorWithRed:169.0/255 green:169.0/255 blue:169.0/255 alpha:1.0] forKey:OPTION_SELECTED_TEXT_COLOR];
        
        [context setObject:[UIImage imageNamed:@"radiobtn.png"] forKey:OPTION_UNSELECTED_IMAGE];
        [context setObject:[UIColor colorWithRed:80.0/255 green:80.0/255 blue:80.0/255 alpha:1.0] forKey:OPTION_UNSELECTED_TEXT_COLOR];
        [context setObject:[FontUtil robotoCondensedWithSize:16] forKey:OPTION_SELECTED_TEXT_FONT];
    } else {
        // context = userContext;
    }
    DGOptionSet *dgOptionSet=[[DGOptionSet alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [dgOptionSet addOptionButtons:[NSArray arrayWithObjects:@"Food",@"Beverage", nil] selectedButton:1 withContext:context spacing:70];
    [dgOptionSet addTarget:tagert action:action];
    dgOptionSet.frame = CGRectMake(-5,0,dgOptionSet.frame.size.width, dgOptionSet.frame.size.height);
    return dgOptionSet;
}

UIImage *decorateExploreRootViewImage = nil;

+(void)decorateExploreRootView:(UIView *)view {
    
    if (decorateExploreRootViewImage == nil) {
        UIColor *borderColor = [UIColor colorWithRed:.8 green:.8 blue:.8 alpha:1];
        
        UIGraphicsBeginImageContext(CGSizeMake(view.frame.size.width, view.frame.size.height));
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        view.clipsToBounds = NO;
        
        {
            [PageUtil addHLine:view.frame.size.height - 1 start:0 end:view.frame.size.width - 1 context:context color:borderColor];
            [PageUtil addVLine:0 start:0 end:view.frame.size.height - 1 context:context color:borderColor];
            [PageUtil addVLine:view.frame.size.width - 1 start:0 end:view.frame.size.height - 1 context:context color:borderColor];
        }
        decorateExploreRootViewImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();

    }
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    imageView.image = decorateExploreRootViewImage;

    [view addSubview:imageView];
}

// return nil if error. return empty array if no resutls found
// type PlaceCoords
+(NSArray *)addressLocation:(NSString *)address {
    NSString *urlString = [NSString stringWithFormat:GOOGLE_MAP_SEARCH_URL,
                           [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSError *err=nil;
    NSString *locationString=[NSString stringWithContentsOfURL:[NSURL URLWithString:urlString] encoding:NSASCIIStringEncoding error:&err];
    NSDictionary *dataDic = [JsonResponseParser getParserData:locationString];
    
    NSMutableArray *retResults = [[NSMutableArray alloc] init];
    
    if([[dataDic objectForKey:@"status"] isEqualToString:@"OK"]){
        NSArray *results = [dataDic objectForKey:@"results"];
        for (int i = 0; i < results.count; ++i) {
            NSDictionary *locationDic = [[[results objectAtIndex:i] objectForKey:@"geometry"] objectForKey:@"location"];
            
            PlaceCoords *place = [[PlaceCoords alloc] init];
            place.longitude = [[locationDic objectForKey:@"lng"] doubleValue];
            place.latitude = [[locationDic objectForKey:@"lat"] doubleValue];
            place.address = [[results objectAtIndex:i] objectForKey:@"formatted_address"];
            
            [retResults addObject:place];
        }
    } else {
        return nil;
    }
    return retResults;
}

+(NSString *)locationAddress:(double)lat lng:(double)lng {
    NSString *urlString = [NSString stringWithFormat:GOOGLE_MAP_REVERSE_GEOCODE_URL,
                           lat, lng];
    NSError *err=nil;
    NSString *locationString=[NSString stringWithContentsOfURL:[NSURL URLWithString:urlString] encoding:NSASCIIStringEncoding error:&err];
    NSDictionary *dataDic = [JsonResponseParser getParserData:locationString];
    
    NSLog(@"..................................... %f,%f", lat, lng);
    NSLog(@"............................ %@", dataDic);
    
    if([[dataDic objectForKey:@"status"] isEqualToString:@"OK"]){
        NSArray *results = [dataDic objectForKey:@"results"];
        for (int i = 0; i < results.count; ++i) {
            NSString *address = [[results objectAtIndex:i] objectForKey:@"formatted_address"];
            NSLog(@"..................................... address = %@", address);
            return address;
        }
    } else {
        return nil;
    }
    return nil;
}

+(void)addDropDownBelow:(UIView *)view size:(int)size data:(NSArray *)data delegate:(id)delegate font:(NSString *)font numLines:(int)numLines ddTypeCode:(int)ddType {
    
    int ddType_ = ddType;
    
    NSMutableArray *dummyArray = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < data.count; ++i) {
        [dummyArray addObject:@""];
    }
    
    int cellHeight = numLines*16 + 16;
    
    DropDownView *dropDown = [[DropDownView alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, size+10)
                                                       rowHeight:cellHeight
                                                     objectArray:dummyArray
                                                   viewPriovider:^UIView *(int index) {
                                                       UIView *cell = [[UIView alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, cellHeight)];
                                                       /*if (ddType_ == 1 || ddType_ == 2) {
                                                           cell.backgroundColor = [UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0];
                                                       }else{                                                           
                                                           cell.backgroundColor = [UIColor clearColor];
                                                       }*/
                                                       cell.backgroundColor = [UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0];
                                                       //cell.backgroundColor = [UIColor clearColor];
                                                       
                                                       NVLabel *label = [[NVLabel alloc] initWithFrame:CGRectMake(7, -1, view.frame.size.width - 12, cellHeight)];
                                                       label.NVFont = font;
                                                       [label setNumberOfLines:numLines];
                                                       label.text = [data objectAtIndex:index];
                                                       
                                                       
                                                       [FontUtil decorate:label];
                                                      /* if (ddType_ == 1 || ddType_ == 2) {
                                                           [label setBackgroundColor:[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0]];
                                                       }else{                                                          
                                                           [label setBackgroundColor:[UIColor clearColor]];
                                                       }*/
                                                       [label setBackgroundColor:[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0]];
                                                       //[label setBackgroundColor:[UIColor clearColor]];
                                                       
                                                       [cell addSubview:label];
                                                       
                                                       if (index < data.count - 1) {
                                                           [PageUtil decorateDropDownCellView:cell ddTypeCode:ddType_];
                                                       }
                                                       return cell;
                                                   }];
    dropDown.delegate = delegate;
    dropDown.backgroundColor=[UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0];
    dropDown.layer.borderWidth = 1.0;
    if (ddType_ == 1) {
        //[dropDown setBackgroundColor:[UIColor redColor]];
        dropDown.layer.borderColor = [UIColor blackColor].CGColor;
       
    }else if (ddType_ == 2){        
        dropDown.layer.borderColor = [UIColor clearColor].CGColor;
    }else{
        //[dropDown setBackgroundColor:[UIColor colorWithRed:.2 green:.2 blue:.2 alpha:1]];
        //dropDown.backgroundColor=[UIColor grayColor];
        
        dropDown.layer.borderColor = [UIColor grayColor].CGColor;
    }
    //[dropDown setBackgroundColor:[UIColor colorWithRed:.2 green:.2 blue:.2 alpha:1]];
        
    AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    CGRect viewAbsRect = [view convertRect:[view bounds] fromView:appDelegate.window];
    
    CGRect dropDownPosition = CGRectMake(-viewAbsRect.origin.x, -viewAbsRect.origin.y + viewAbsRect.size.height, dropDown.frame.size.width, dropDown.frame.size.height);
    
    dropDown.frame = dropDownPosition;
    // [view.superview addSubview:dropDown];
    dropDown.tag = TAG_DROP_DOWN_VIEW;
    // [PageUtil reposition:dropDown below:view];
    //dropDown.backgroundColor=[UIColor grayColor];
    [[self class] removeDropDown];
    [appDelegate.window addSubview:dropDown];
    [appDelegate.window bringSubviewToFront:dropDown];
}

+(void)removeDropDown {
    AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    [[appDelegate.window viewWithTag:TAG_DROP_DOWN_VIEW] removeFromSuperview];
}


+(void)addHistorySection:(CGRect)frame inView:(UIView *)inView data:(NSArray *)data delegate:(id)delegate font:(NSString *)font headerFont:(NSString *)headerFont numLines:(int)numLines {
    NSMutableArray *dummyArray = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < data.count; ++i) {
        [dummyArray addObject:@""];
    }
    
    DropDownView *dropDown = [[DropDownView alloc] initWithFrame:frame
                                                       rowHeight:32
                                                     objectArray:dummyArray
                                                   viewPriovider:^UIView *(int index) {
                                                       UIView *cell = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 32)];
                                                       cell.backgroundColor = [UIColor clearColor];
                                                       
                                                       NVLabel *label = [[NVLabel alloc] initWithFrame:CGRectMake(5, -2, frame.size.width - 10, 32)];
                                                       
                                                       if (headerFont != nil && index == 0) {
                                                           label.NVFont = headerFont;
                                                       } else {
                                                           label.NVFont = font;
                                                       }
                                                       
                                                       [label setNumberOfLines:numLines];
                                                       label.text = [data objectAtIndex:index];
                                                       
                                                       [FontUtil decorate:label];
                                                       [label setBackgroundColor:[UIColor clearColor]];
                                                       
                                                       [cell addSubview:label];
                                                       
                                                       if (index < data.count - 1) {
                                                           [PageUtil decorateDropDownCellView:cell ddTypeCode:0];
                                                       }
                                                       return cell;
                                                   }];
    dropDown.delegate = delegate;
    [dropDown setBackgroundColor:[UIColor clearColor]];
    
    dropDown.tag = TAG_HISTORY_SECTION_VIEW;
    [inView addSubview:dropDown];
}

+(void)removeHistorySection:(UIView *)parentView {
    DropDownView *dropDown = (DropDownView *)[parentView viewWithTag:TAG_DROP_DOWN_VIEW];
    dropDown.delegate = nil;
    [dropDown removeFromSuperview];
}

+(void)addHDent:(UIView *)view position:(int)position {
    UIColor *borderColor1 = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:1];
    UIColor *borderColor2 = [UIColor blackColor];
    
    UIGraphicsBeginImageContext(CGSizeMake(view.frame.size.width, view.frame.size.height));
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    view.clipsToBounds = NO;
    
    {
        [PageUtil addHLine:position - 1 start:3 end:view.frame.size.width - 4 context:context color:borderColor1];
        [PageUtil addHLine:position - 2 start:3 end:view.frame.size.width - 4 context:context color:borderColor2];
        
    }
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    imageView.image = newImage;
    [view addSubview:imageView];
    UIGraphicsEndImageContext();
}

+(void)decorateDropDownCellView:(UIView *)view ddTypeCode:(int)ddType {
   // int ddType_ = ddType;
   // UIColor *borderColor1;
    UIColor *borderColor2;
   /* if (ddType_ == 1 || ddType_ == 2) {
        borderColor1 = [UIColor clearColor];
        borderColor2 = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
    }else{
        borderColor1 = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:1];
        borderColor2 = [UIColor blackColor];
    }*/
    //borderColor1 = [UIColor clearColor];
    borderColor2 = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];

    UIGraphicsBeginImageContext(CGSizeMake(view.frame.size.width, view.frame.size.height));
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    view.clipsToBounds = NO;
    
    {
       
            [PageUtil addHLine:view.frame.size.height - 2 start:3 end:view.frame.size.width - 4 context:context color:borderColor2];
            
           // [PageUtil addDashedHLine:view.frame.size.height - 1 start:3 end:view.frame.size.width - 4 context:context color:borderColor1];
       
        
        
    }
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    imageView.image = newImage;
    
    [view addSubview:imageView];
    
    UIGraphicsEndImageContext();
    
}

+(void)fillLocation:(NSMutableDictionary *)request {

    [self getCurrentLocation];

    PlaceCoords *place = [self getCurrentLocation]; //(PlaceCoords *)[NVSession getFromSession:SESSION_CUR_PLACE];
    
    [request setObject:[NSString stringWithFormat:@"%f", place.latitude] forKey:@"latitude"];
    [request setObject:[NSString stringWithFormat:@"%f", place.longitude] forKey:@"longitude"];
}


+(PlaceCoords *)getCurrentLocation {
    PlaceCoords *place = nil;
    if ([PageUtil isSelectedLocationDeviceLocation]) {
        place = [PageUtil getDeviceLocation];
        if (place == nil) {
            place = [self getDefaultLocation];
        }
    } else {
        place = [PageUtil getSelectedLocation];
    }
    return place;
}

+(PlaceCoords *)getDeviceLocation {
    return [PageUtil locationToPlaceCoords:[PageUtil getLastknownDeviceLocation]];
}

+(PlaceCoords *)getSelectedLocation {
    return (PlaceCoords *)[NVSession getFromSession:SESSION_CUR_PLACE];
}

+(PlaceCoords *)getDefaultLocation {
    PlaceCoords *place = [[PlaceCoords alloc] init];
    place.latitude = 12.987686;
    place.longitude = 77.58035;
    place.address = @"Default location";
    return place;
}

+(void)setLocation:(PlaceCoords *)place {
    if (place == nil) {
        [NVSession setInSession:SESSION_CUR_PLACE_TYPE value:SESSION_CUR_PLACE_TYPE_DEVICE_LOC];
    } else {
        [NVSession setInSession:SESSION_CUR_PLACE value:place];
        [NVSession setInSession:SESSION_CUR_PLACE_TYPE value:SESSION_CUR_PLACE_TYPE_SELECTED];
    }
}

+(NSString *)distanceFromCurLock:(PlaceCoords *)place {
    return [PageUtil distanceFromCurLock:place forceDeviceLoc:NO];
}

+(NSString *)distanceFromCurDeviceLock:(PlaceCoords *)place {
    return [PageUtil distanceFromCurLock:place forceDeviceLoc:YES];
}

+(NSString *)distanceFromCurLock:(PlaceCoords *)place forceDeviceLoc:(bool)forceDeviceLoc {
    
    if (forceDeviceLoc && [PageUtil getLastknownDeviceLocation] == nil) {
        return @"NA";
    } else {
        NSNumber *dist = [DGLocationManager
                          getDistanceInMeterFrom:[PageUtil placeCoordsToLocation:place]
                          to:forceDeviceLoc?[PageUtil getLastknownDeviceLocation]:[PageUtil placeCoordsToLocation:[PageUtil getCurrentLocation]]];
        int distInMeters = dist.intValue;
        
        NSString *disInKm = [Utilities getDistanceStatus];
        
        if (disInKm == nil || [@"false" isEqualToString:disInKm]) {
            //if (distInMeters < 1000) {
                // mtrs in multiples of 100
             //   return [NSString stringWithFormat:@"%dmt", ((int)(distInMeters/100)) *100 ];
            //} else {
                // kms in 1 decimal place precision
                return [NSString stringWithFormat:@"%.2fkm", ((float)((int)(distInMeters/100)))/10.0];
            //}
        } else {
            int distInFt = (int)(3.28084*distInMeters);
            //if (distInFt < 5280) {
                // fts in multiples of 100
              //  return [NSString stringWithFormat:@"%dft", ((int)(distInFt/100)) *100 ];
            //} else {
                // miles in 1 decimal place precision
                return [NSString stringWithFormat:@"%.2fmi", ((float)((int)(distInFt*10/5280)))/10.0];
            //}
        }
    }
    
}

+(CLLocation *)getLastknownDeviceLocation {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    return appDelegate.locations;
}

+(void)push:(UIViewController *)vc {
    UINavigationController *navController = [self getCurNavController];
    
    NSArray *controllers = [navController viewControllers];
    for (int i = 0; i < controllers.count; ++i) {
        UIViewController *controller = [controllers objectAtIndex:i];
        if ([controller isMemberOfClass:[vc class]]) {
            [navController popToViewController:controller animated:NO];
            [navController popViewControllerAnimated:NO];
            break;
        }
    }
    
    [navController pushViewController:vc animated:YES];
}

// returns the instnace for current navigation controller
+(UINavigationController *)getCurNavController {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    UINavigationController *navController;
    
    NSLog(@"%@", [appDelegate.window.rootViewController class]);
    
    if ([appDelegate.window.rootViewController class] == [DisgramTabBarControllerViewController class]) {
        UITabBarController *root =(UITabBarController *)appDelegate.window.rootViewController;
        navController = (UINavigationController *)root.selectedViewController;
    }
    else{
        navController = appDelegate.window.rootViewController.navigationController;
    }
    return navController;
}

+(void)popVC {
    UINavigationController *navController = [self getCurNavController];
    [navController popViewControllerAnimated:YES];
}


/*
void (^locationCallBack_)();
DGLocationManager *puLocationManager;
bool locationReqInProgress = NO;


+(void (^)()) getLocationCallBack {
    return locationCallBack_;
}

+(void)clearLocationChangeListener {
    locationCallBack_ = nil;
}

PlaceCoords *lastKnownDeviceLocation = nil;

+(void)setLocationChangeListener:(void (^)()) locationCallBack {
    locationCallBack_ = locationCallBack;
    
    lastKnownDeviceLocation = [PageUtil getDefaultLocation];
    
    if (!locationReqInProgress) {
        locationReqInProgress = YES;
        
        if (puLocationManager == nil) {
            puLocationManager = [[DGLocationManager alloc] init];
        }
        
        [puLocationManager getDeviceCurrentLocation:^(CLLocation *response, DGLocationManager *locationManager) {
            [puLocationManager stopLocationFinder];
            
            if (response != nil) {
                AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
                appDelegate.locations = response;
                
                
                if (lastKnownDeviceLocation != nil && ![[PageUtil locationToPlaceCoords:response] similar:lastKnownDeviceLocation]) {
                    if ([PageUtil getLocationCallBack] != nil && [PageUtil isSelectedLocationDeviceLocation]) {
                        [PageUtil getLocationCallBack]();
                    }
                } else {
                    // current location is very close to old location. so ignore
                }
            }
            locationReqInProgress = NO;
        }];
    }
}
*/


+(PlaceCoords *)locationToPlaceCoords:(CLLocation *)location {
    PlaceCoords *coords = [[PlaceCoords alloc] init];
    coords.longitude = location.coordinate.longitude;
    coords.latitude = location.coordinate.latitude;
    AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    coords.address = appDelegate.locationAddress; // @"Device current location";
    return coords;
}

+(CLLocation *)placeCoordsToLocation:(PlaceCoords *)place {
    return [[CLLocation alloc] initWithLatitude:place.latitude longitude:place.longitude];
}

+(bool)isSelectedLocationDeviceLocation {
    NSString *placeType = (NSString *)[NVSession getFromSession:SESSION_CUR_PLACE_TYPE];
    return (placeType == nil || [placeType isEqualToString:SESSION_CUR_PLACE_TYPE_DEVICE_LOC]);
}

+(void)setTextFieldBorder:(UITextField*)textField{
    [textField.layer setBorderWidth:1.0];
    [[textField layer] setBorderColor:[[UIColor colorWithRed:227.0/255.0 green:227.0/255.0 blue:227.0/255.0 alpha:1.0] CGColor]];    
    
}

+(NSString *)trim:(NSString *)str {
    return [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

int windowHeight_ = 0;
int heightDiff_ = 0;

+(int)getAdjustedHeight:(int)baseHeight {
    if (windowHeight_ == 0) {
        AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
        windowHeight_ = appDelegate.winHeight;
        heightDiff_ = windowHeight_ - 460;
    }
    return baseHeight + heightDiff_;
}

+(void)moveDownIfRequired:(UIView *)view {
    view.frame = CGRectMake(view.frame.origin.x, [self getAdjustedHeight:view.frame.origin.y], view.frame.size.width, view.frame.size.height);
}

bool scrollHidden = false;

+(void)hideTabBar:(UIView *)stretch {
    if (scrollHidden) {
        return;
    }
    scrollHidden = YES;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.2];
    
    
    for(UIView *view in [PageUtil rootController].view.subviews)
    {
        if([view isKindOfClass:[UITabBar class]] || [view isKindOfClass:[UIButton class]])
        {
            view.userInteractionEnabled=NO;
            [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y + 45, view.frame.size.width, view.frame.size.height)];
        }
        else
        {
            [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, view.frame.size.height + 50)];
        }
    }
    
    stretch.frame = CGRectMake(stretch.frame.origin.x, stretch.frame.origin.y, stretch.frame.size.width, stretch.frame.size.height + 50);
    
    [UIView commitAnimations];
}

+(void)showTabBar:(UIView *)stretch {
    
    if (!scrollHidden) return;
    scrollHidden = NO;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:.2];
    
    for(UIView *view in [PageUtil rootController].view.subviews)
    {
        if([view isKindOfClass:[UITabBar class]] || [view isKindOfClass:[UIButton class]])
        {
                        view.userInteractionEnabled=YES;
            [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y - 45, view.frame.size.width, view.frame.size.height)];
        }
        else
        {
            [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, view.frame.size.height - 50)];
        }
    }
    
    stretch.frame = CGRectMake(stretch.frame.origin.x, stretch.frame.origin.y, stretch.frame.size.width, stretch.frame.size.height - 50);
    
    [UIView commitAnimations];
}

+(UITabBarController *)rootController {
    AppDelegate *appDelegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    //[appDelegate.dgHomeController.daily hideDisgramButton];
    return (UITabBarController *)appDelegate.window.rootViewController;
}

+(UIView *)getWindow {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    return appDelegate.window;
}

+(void)place:(UIView *)target nextTo:(UIView *)nextTo withMarging:(int)margin {
    target.frame = CGRectMake(nextTo.frame.origin.x + nextTo.frame.size.width + margin, target.frame.origin.y, target.frame.size.width, target.frame.size.height);
}

+(void)place:(UIView *)target infrontOf:(UIView *)infrontOf withMarging:(int)margin {
    target.frame = CGRectMake(infrontOf.frame.origin.x - target.frame.size.width - margin, target.frame.origin.y, target.frame.size.width, target.frame.size.height);
}

+(void)padTextField:(UITextField *)textField {
    UIView *leftPaddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    textField.leftView = leftPaddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
    /*
    UIView *rightPaddingView = [[UIView alloc] initWithFrame:CGRectMake(textField.frame.size.width - 5, 0, 5, 20)];
    textField.rightView = rightPaddingView;
    textField.rightViewMode = UITextFieldViewModeAlways;
     */
}

+(void)setAttributedText:(UILabel *)label string:(NSString *)string {
    if (string == nil) {
        string = @"";
    }
    NSMutableAttributedString *attrStr = label.attributedText.mutableCopy;
    attrStr.mutableString.string = string;
    label.attributedText = attrStr;
}

+(void)centerLabel:(UILabel *)label {
    CGRect originalFrame = label.frame;
    
    [label sizeToFit];
    label.frame = CGRectMake(originalFrame.origin.x, originalFrame.origin.y + originalFrame.size.height/2 - label.frame.size.height/2, label.frame.size.width, label.frame.size.height);
    // originalFrame = label.frame;
}


+(UILabel*)navBarTitleWith:(NSString*)titleStr{
    
    CGRect frame = CGRectMake(0, 0, 180, 44);
    UILabel *nav_label = [[UILabel alloc] initWithFrame:frame];
    
    nav_label.backgroundColor = [UIColor clearColor];
    [nav_label setFont:[UIFont fontWithName:@"Roboto-Bold" size:18]];
    nav_label.shadowColor = [UIColor whiteColor];
    nav_label.shadowOffset  = CGSizeMake(0.5,0.5);
    nav_label.textAlignment = UITextAlignmentCenter;
    nav_label.textColor = [UIColor blackColor];
    nav_label.text = titleStr;
    [nav_label sizeToFit];
    
    return nav_label;
}

+(void)requiresLogin {
    // [[[iToast makeText:@"LOGIN REQUIRED"] setGravity:iToastGravityTop] show];
    [self loadSearchLocationView];
}

+(void)showAlertView:(NSString *)message{
    if ([[PageUtil getWindow]viewWithTag:TAG_LOGIN_PROMPT_VIEW]==nil) {
        LoginPromptView *loginPromptView = [[LoginPromptView alloc] initWithFrame:CGRectMake(0, 0, 320, 600)];
        [loginPromptView.cancelButton setHidden:YES];
        [loginPromptView.loginButton setFrame:CGRectMake(73, 39, 132, 44)];
        loginPromptView.promptLbl.text=message;
        loginPromptView.tag = TAG_LOGIN_PROMPT_VIEW;
        [loginPromptView slideIn];
        [[PageUtil getWindow] addSubview:loginPromptView];
        
    }
}

+(void)showRemovePostAlertViewWithDelegate:(id<RemovePostPromptDelegate>)delegate {
    if ([[PageUtil getWindow]viewWithTag:TAG_REMOVE_POST_PROMPT_VIEW]==nil) {
        RemovePostPromptView *removePostPromtpView = [[RemovePostPromptView alloc] initWithFrame:CGRectMake(0, 0, 320, 600)];
        removePostPromtpView.delegate = delegate;
        removePostPromtpView.tag = TAG_REMOVE_POST_PROMPT_VIEW;
        [removePostPromtpView slideIn];
        [[PageUtil getWindow] addSubview:removePostPromtpView];
        
    }
}

+(UIView *)showImageCropView:(UIImage *)image heightRatio:(float)heightRatio minHeight:(float)minHeight maxHeight:(float)maxHeight delegate:(id<CropDelegate>)delegate {
    if ([[PageUtil getWindow] viewWithTag:TAG_IMAGE_CLIP_VIEW]==nil) {
        ImageCropView *cropView = [[ImageCropView alloc] initWithFrame:CGRectMake(0, 0, 320, 600) heightRatio:heightRatio minHeight:minHeight maxHeight:maxHeight image:image delegate:delegate];
        cropView.tag = TAG_IMAGE_CLIP_VIEW;
        [[PageUtil getWindow] addSubview:cropView];
    }
    return [[PageUtil getWindow] viewWithTag:TAG_IMAGE_CLIP_VIEW];
}


+(void)loadSearchLocationView {
    if ([[PageUtil getWindow]viewWithTag:TAG_LOGIN_PROMPT_VIEW]==nil) {
        LoginPromptView *loginPromptView = [[LoginPromptView alloc] initWithFrame:CGRectMake(0, 0, 320, 600)];
        loginPromptView.tag = TAG_LOGIN_PROMPT_VIEW;
        [loginPromptView slideIn];
        [[PageUtil getWindow] addSubview:loginPromptView];
        
    }
}

BOOL USER_LOGGED_IN = NO;

+(BOOL)isLoggedin {
    return USER_LOGGED_IN;
}

+(void)setLoggedin:(BOOL)loggedin {
    USER_LOGGED_IN = loggedin;
}
// Send device token to server
+ (void)sendDeviceTokenToServer{
    if([[NSUserDefaults standardUserDefaults] objectForKey:k_DEVICE_TOKEN]){
    DataSourceInterface *dataSourceObj = [DataSourceFactory getDataSourceInstance];
    NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
    [param setObject:[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN] forKey:@"token"];
    [param setObject:[[NSUserDefaults standardUserDefaults] objectForKey:k_DEVICE_TOKEN] forKey:@"gcmKey"];
    
    [dataSourceObj requestDataWithURLString:SEND_TOKEN_URL params:param  modelClass:nil callBack:^(bool success, NSObject *response) {
        if (success) {
            
        }else{
        }
        
    }];
    }
}


+(void)addNoDataFoundImageOnView:(UIView *)view image:(UIImage *)noDataFoundImage{
    UIView *ndfViewGlass = [[UIView alloc] initWithFrame:CGRectMake(0, -500, 320, 501)];
    UIImageView *ndfView = [[UIImageView alloc] initWithFrame:CGRectMake(12, 240, 297, 251)];
    
    ndfView.image = noDataFoundImage;
    ndfViewGlass.tag = TAG_NO_DATA_FOUND_IMAGE;
        // [ndfView setCenter:CGPointMake(160, 200)];
        // [ndfViewGlass setTransform:CGAffineTransformMakeRotation(M_PI / 20)];
    
    [ndfViewGlass addSubview:ndfView];
    [view addSubview:ndfViewGlass];
    
    [UIView animateWithDuration:0.3 animations:^{
        ndfViewGlass.frame = CGRectMake(0, -220, 320, 501);
    } completion:^(BOOL finished) {
        
        int variance = (int)arc4random_uniform(100);
        int direction = (int)arc4random_uniform(2);
        if (direction < 1) direction = -1;
        
            // [ndfViewGlass setCenter:CGPointMake(160, 0)];
        [UIView animateWithDuration:0.2 animations:^{
            [ndfViewGlass setTransform:CGAffineTransformMakeRotation(direction * M_PI / (30 + variance))];
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3 animations:^{
                [ndfViewGlass setTransform:CGAffineTransformMakeRotation(- direction * M_PI / (40 + variance*2))];
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.3 animations:^{
                    [ndfViewGlass setTransform:CGAffineTransformMakeRotation(0)];
                } completion:^(BOOL finished) {
                        //
                }];
            }];
        }];
    }];
    
}
+(void)addNoDataFoundImage:(UIView* )view imageName:(NSString *)imageName{
    UIImage  *noDataFoundImage;
    if (imageName==nil) {
        noDataFoundImage = [UIImage imageNamed:@"notfound"];
        
    }else{
        noDataFoundImage=[UIImage imageNamed:imageName];
        
    }
    [[self class] addNoDataFoundImageOnView:view image:noDataFoundImage];
    
}
+(void)addNoDataFoundImage:(UIView *)view {
    UIImage  * noDataFoundImage = [UIImage imageNamed:@"notfound"];
    [[self class] addNoDataFoundImageOnView:view image:noDataFoundImage];
}

+(void)removeNoDataFoundImage:(UIView *)view {
    UIView *noDataView = [view viewWithTag:TAG_NO_DATA_FOUND_IMAGE];
    if (noDataView != nil) {
        [UIView animateWithDuration:1 animations:^{
            noDataView.frame = CGRectMake(0, 600, noDataView.frame.size.width, noDataView.frame.size.height);
        } completion:^(BOOL finished) {
            [noDataView removeFromSuperview];
        }];
    }
}
+ (CGFloat) radians:(int)degrees {
    return (degrees/180)*(22/7);
}

+ (UIImage*) rotateImage:(UIImage* )src {
    UIImageOrientation orientation = src.imageOrientation;
    UIGraphicsBeginImageContext(src.size);
    
    [src drawAtPoint:CGPointMake(0, 0)];
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if (orientation == UIImageOrientationRight) {
        CGContextRotateCTM (context, [[self class] radians:90]);
    } else if (orientation == UIImageOrientationLeft) {
        CGContextRotateCTM (context, [[self class] radians:90]);
    } else if (orientation == UIImageOrientationDown) {
        
    } else if (orientation == UIImageOrientationUp) {
        CGContextRotateCTM (context, [[self class] radians:0]);
    }
    UIImage *tImage=UIGraphicsGetImageFromCurrentImageContext();
    return tImage;
}

+(NSString *)removePostEventName:(NSString *)postId {
    return [NSString stringWithFormat:@"EVENT_REMOVE_POST_DPID_%@", postId];
}

+ (UIImage *)rotateImage:(UIImage*)src degrees:(CGFloat)degrees
{
    // calculate the size of the rotated view's containing box for our drawing space
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,src.size.width, src.size.height)];
    CGAffineTransform t = CGAffineTransformMakeRotation(degrees * M_PI / 180);
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;
    
    // Create the bitmap context
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    // Move the origin to the middle of the image so we will rotate and scale around the center.
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
    //   // Rotate the image context
    CGContextRotateCTM(bitmap, degrees * M_PI / 180);
    
    // Now, draw the rotated/scaled image into the context
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-src.size.width / 2, -src.size.height / 2, src.size.width, src.size.height), [src CGImage]);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+(UIImage *)cropImage:(UIImage *)image toRect:(CGRect)rect {
    return [image cutout:rect];
}
+(void)bufferRestaurantNearToLocation{
    NSMutableDictionary *param=[[NSMutableDictionary alloc] init];
    AppDelegate *app=(AppDelegate *)[UIApplication sharedApplication].delegate;
    CLLocation *locaiton=app.locations;
    [param setObject:[NSNumber numberWithFloat:locaiton.coordinate.latitude] forKey:@"latitude"];
    [param setObject:[NSNumber numberWithFloat:locaiton.coordinate.longitude] forKey:@"longitude"];
    [param setObject:[NSNumber numberWithInt:0] forKey:@"offset"];
    [param setObject:[NSNumber numberWithInt:10] forKey:@"max"];
    
    DataSourceInterface *dataSourceObj = [DataSourceFactory getDataSourceInstance];
    
    [dataSourceObj requestDataWithURLString:PLACEBYDISTANCE params: param modelClass:[Place class] callBack:^(bool success, NSObject *response) {
        
        
    }];
}


+(DishDraft *)newDishDraft{
    DishDraft *dishDraft=[[DishDraft alloc] init];
    dishDraft.userImageUploadKey=[NSString stringWithFormat:@"%@%f",@"123",[NSDate timeIntervalSinceReferenceDate]];
    return dishDraft;
}

+(void)setImageForDishDraft:(DishDraft *)dishDraft image:(UIImage *)image{
    dishDraft.image=image;
}

+(BOOL)uploadDishImageForPost:(DishDraft *)dishDraft{
    @try {
        DGImageUploadSingeloton *dgImageUpload=[DGImageUploadSingeloton singelton];
        dishDraft.delegate=dgImageUpload;
        
        [NSThread detachNewThreadSelector:@selector(postNewDish:) toTarget:dgImageUpload withObject:dishDraft];
        return YES;
    }
    @catch (NSException *exception) {
        return NO;
    }
    @finally {
        return NO;
    }
}

+(BOOL)uploadDishImageForDraft:(DishDraft *)dishDraft{
    @try {
        DGImageUploadSingeloton *dgImageUpload=[DGImageUploadSingeloton singelton];
        dishDraft.delegate=dgImageUpload;
        [NSThread detachNewThreadSelector:@selector(uploadDraftImageInSecoundryThread:) toTarget:dgImageUpload withObject:dishDraft];
        return YES;
    }
    @catch (NSException *exception) {
        return NO;
    }
    @finally {
        return NO;
    }
}
@end
