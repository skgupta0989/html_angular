//
//  ReusableUIView.h
//  DishGram
//
//  Created by Ramesh Varma on 01/08/13.
//
//

#import <UIKit/UIKit.h>

// class for assisting cell reusability
@interface ReusableUIView : UIView

@property (nonatomic) int reservedForIndex;
@property (nonatomic) BOOL updateInProgress;

@end
