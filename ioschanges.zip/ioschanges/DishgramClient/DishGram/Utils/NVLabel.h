//
//  NVLabel.h
//  DishGram
//
//  Created by Ramesh Varma on 30/05/13.
//
//

#import <UIKit/UIKit.h>

@interface NVLabel : UILabel


// NV font is used for automatically setting font and other look and feel
// properties of UILabels
// Usage: in XIB add a keyValue with key "NVFont" and value "_tile_headerSub_"
// refer to util class for more details on values.
@property (nonatomic, strong) NSString *NVFont;

@end
