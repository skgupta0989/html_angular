//
//  ImageSource.m
//  DishGram
//
//  Created by User on 5/3/13.
//
//

#import "ImageSource.h"

// #define URL_PREFIX1 @"http://google.com/"
#define URL_PREFIX1 @""

@implementation ImageSource

int index1 = 0;


-(UIImage *)getImage:(NSString *)url {
    UIImage *image = nil;
    if ([url hasPrefix:@"test://"]) {
        url = [NSString stringWithFormat:@"http://cdn4.1stwebdesigner.com/wp-content/uploads/2009/07/free-twitter-icons/designreviver-free-twitter-social-icon.jpg?index=%d", ++index1];
    }
    
    image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[URL_PREFIX1 stringByAppendingString:url]]]];
    
    
    return image;
}

@end
