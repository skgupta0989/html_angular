//
//  ImageCache.h
//  DishGram
//
//  Created by User on 5/3/13.
//
//
#import "ImageSource.h"
#import "CacheManager.h"

// implements a cache for images.
@interface ImageCache : NSObject<CacheCallback> {
    ImageSource *_imageSource;
    CacheManager *_c1Manager;
    CacheManager *_c2Manager;
    NSString *_name;
    
    // list of images that need to be prefetched
    // when ever the next request is comes, thi slist
    // is reset
    NSMutableArray *_prefetchPool;
    
    /**
     * locks for fetching images. This helps in avoiding 
     * duplicate requests for fetching same image
     */
    NSMutableDictionary *_fetchLocks;
    NSConditionLock *_lockHelper;
    NSCondition *_prefetchPoolLock;
    
    @private
    // directory where the cached files will be stored
    NSString *documentPathPrefix;
    // true indicates that the cache dir is not yet created.
    bool dirNotCreated;
    
    // stores the current request priority
    int _requestPriority;
}

// helper for getting image from a URL
@property (nonatomic, strong) ImageSource *imageSource;

// c1 cache (disc)
@property (nonatomic, strong) CacheManager *c1Manager;

// c2 cache (ram)
@property (nonatomic, strong) CacheManager *c2Manager;

// name of this cache. This name must be unique across all
// caches. name will be used in cosntruction a directory name
// where cached files will be stored. User must ensure that
// the name doest any special characters which can cause
// problems in creating directory
@property (nonatomic, strong) NSString *name;

// ititializes the cache with specified name. if persistant is set to
// true, then data cahced on the disc will be available even after
// restarting the application. c1size corresponds to number of images
// on the disk. c2size corresponds to number of images in RAM
-(id)initWithName:(NSString *)name isPersistant:(BOOL)persistant c1Size:(int)c1Size c2Size:(int)c2Size;


// returns an image fetched from C2, or C1 or from server
-(UIImage *)getImage:(NSString *)imageUrl;

// returns specified image and prefetches the rest of the urls
// with preferences must have image urls in the order of priority
// first 2 image will be loaded into memory. rest of the images will
// be stored on the disk
-(UIImage *)getImage:(NSString *)imageUrl withPrefetch:(NSArray *)otherImageUrls;

-(UIImage *)getImage:(NSString *)imageUrl withPrefetch:(NSArray *)otherImageUrls withPriority:(int)priority;

-(bool)isQuick:(NSString *)url;

@end
