//
//  NetworkCheck.h
//  DishGram
//
//  Created by Rags on 07/05/13.
//
//

#import <Foundation/Foundation.h>
#import "Reachability.h"


@interface NetworkCheck : NSObject{
    
}
@property (nonatomic, strong) Reachability *checkReachability;
@property (nonatomic, assign) BOOL isnetWorkAvailable;


- (BOOL)checkWhetherInternetIsAvailable;
+ (id)sharedInstance;


@end
