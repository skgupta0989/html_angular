//
//  ImageCacheQueue.m
//  DishGram
//
//  Created by User on 5/13/13.
//
//

#import "ImageCacheQueue.h"
#import "CacheFactory.h"
#import "NVRequestQueue.h"

@implementation ImageCacheQueue


// list of all the queues which can be accessed by name
NSMutableDictionary *__queuesDictionary = nil;

+(NVRequestQueue *)getImageQueueByName:(NSString *)name {
    
    // check if queues are laready created. if not, create them first
    if (__queuesDictionary == nil) {
        __queuesDictionary = [[NSMutableDictionary alloc] init];
        [ImageCacheQueue startQueue:CACHE_NAME_DEFAULT size:QUEUE_SIZE_DEFAULT noOfThreads:2];
        
        [ImageCacheQueue startQueue:CACHE_NAME_FB_IMAGE size:QUEUE_SIZE_FB_IMAGE noOfThreads:3];
        
        [ImageCacheQueue startQueue:CACHE_NAME_DISH_IMAGE size:QUEUE_SIZE_DISH_IMAGE noOfThreads:3];
    }
    return [__queuesDictionary objectForKey:name];
}

// creates a queue with specified parameters. instances of ImageCache will be used as RequestProcessor
// name - unique name of the queue/imageQueue
// size - max size of the queue
// threadCount - numbers of threads for paralellely executing the requests
+(void)startQueue:(NSString *)name size:(int)size noOfThreads:(int)threadCount{
    
    NVRequestQueue *queue = [[NVRequestQueue alloc] initWithSize:size noOfThreads:threadCount andName:name];

    [__queuesDictionary setObject:queue forKey:name];
}

@end
