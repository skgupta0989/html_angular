//
//  UIImage+StreatchableImage.h
//  DishGram
//
//  Created by Ramesh Varma on 22/05/13.
//
//

#import <UIKit/UIKit.h>

@interface UIImage (StreatchableImage)
//extract a portion of an UIImage instance
-(UIImage *) cutout: (CGRect) coords;
//create a stretchable rendition of an UIImage instance, protecting edges as specified in cornerCaps
-(UIImage *) stretchImageWithCapInsets: (UIEdgeInsets) cornerCaps toSize: (CGSize) size;
@end
