//
//  CacheFactory.m
//  DishGram
//
//  Created by User on 5/7/13.
//
//

#import "CacheFactory.h"
// factory class for getting ImageCaches by name

@implementation CacheFactory

bool CACHE_NOT_INITED = true;
NSMutableDictionary *__cachesDictionary = nil;

+(ImageCache *)getImageCache {
    return [CacheFactory getImageCacheByName:CACHE_NAME_DEFAULT];
}

+(ImageCache *)getImageCacheByName:(NSString *)name {
    if (__cachesDictionary == nil) {
        __cachesDictionary = [[NSMutableDictionary alloc] init];
        [CacheFactory startCache:CACHE_NAME_DEFAULT c1size:DEFAULT_CACHE_C1_SIZE c2size:DEFAULT_CACHE_C2_SIZE isPersistant:DEFAULT_CACHE_IS_PERSISTANT];
        
        [CacheFactory startCache:CACHE_NAME_FB_IMAGE c1size:FB_IMAGE_CACHE_C1_SIZE c2size:FB_IMAGE_CACHE_C2_SIZE isPersistant:FB_IMAGE_CACHE_IS_PERSISTANT];
        
        [CacheFactory startCache:CACHE_NAME_DISH_IMAGE c1size:DISH_IMAGE_CACHE_C1_SIZE c2size:DISH_IMAGE_CACHE_C2_SIZE isPersistant:DISH_IMAGE_CACHE_IS_PERSISTANT];
    }
    return [__cachesDictionary objectForKey:name];
}

// initializes and stores tha cache instances
+(void)startCache:(NSString *)name c1size:(int)c1size c2size:(int)c2size isPersistant:(bool)isPersistant {
    ImageCache *cache = [[ImageCache alloc] initWithName:name isPersistant:isPersistant c1Size:c1size c2Size:c2size];
    [__cachesDictionary setObject:cache forKey:name];
    
}

@end
