//
//  RowDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 16/05/13.
//
//

#import <Foundation/Foundation.h>
#import "PagedDataProvider.h"
#import "CacheManager.h"


@interface RowDataProvider : NSObject {
    int _trigger;
    int _pageSize;
    int _cacheSize;
    CacheManager *_cache;
    NSCondition *_requestLock;
    NSMutableArray *_requestList;
    NSMutableDictionary *_pageLocks;
    
    // this helps in quickly determinig if the reuqired page is already available
    int _lastCheckedPageNumber;
    NSOperationQueue *_dataReqQueue;
    
}

// data provider for displaying paginated data.
@property (nonatomic, strong) NSObject<PagedDataProvider> *pagedDataProviderInst;
@property (nonatomic, strong) void (^_sizeChangedCallBack)(int);

// returns row data at specified index. row number is absolute row number in the entire tables (as opposed to row number in a page).
-(NSObject *)getRow:(int)index;

// initializes with specified pageSize (maximum number of rows in a page). this value will be increased by 4 times after first page is loaded. This reduces number of request to server but at the same time maintains better user experiance.
// cacheSize - maximum number of pages to be cached. Older ones will be automatically deleted
// pagedDataProvider - data provider
// trigger - trigger for loading next/previous page. to types of trigger are supported:
// NEXT_PAGE_TRIGGER_80_PERCENT - triggers next page load when user is at 80% of the page. and triggers previous page load
// at 20% of the page. Ex: if each page has 100 rows (pageSize) then next page is loaded when user reached 80th row and previous page is loaded when user reaches 20th row.
// NEXT_PAGE_TRIGGER_LAST_ROW - next page is loaded when user reaches last row in a page. previous page is loaded when user reaches first row in a page
-(id)initWithPageSize:(int)pageSize numberOfPagesToCache:(int)cacheSize pagedDataProvider:(NSObject<PagedDataProvider> *)pagedDataProvider nextPageTrigger:(int)trigger;

// fetches row data and calls back with row data
-(void)getRow:(int)index withCallBack:(void (^)(NSObject *data))callBack;

// returns row data if it is already present
-(NSObject *)getLocalRow:(int)index;


@end
