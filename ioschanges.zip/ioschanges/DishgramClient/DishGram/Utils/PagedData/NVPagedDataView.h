//
//  NVPagedDataView.h
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import <UIKit/UIKit.h>
#import "NVTemplateProvider.h"
#import "PagedDataProvider.h"

@interface NVPagedDataView : UITableView<UITableViewDataSource, UITableViewDelegate> {
    int scrollUp;
    BOOL disableTabHiding_;
}

@property (nonatomic, strong) NSObject<NVTemplateProvider> *templateProvider;

// call back methof for notifying that no data is found
-(void)noDataFound;

-(void)noDataFoundImage:(NSString *)imageName;

// init method. if disableTabHiding is set to YES, tab bar will not be hidden when user scrolls
// default init method sets this option to YES as it was requested to remove tab bar hiding feature.
- (id)initWithFrame:(CGRect)frame disableTabHiding:(BOOL)disableTabHiding;

// refreshes all teh currelty visible cells in the table view
-(void)refreshVisibleRows;

@end
