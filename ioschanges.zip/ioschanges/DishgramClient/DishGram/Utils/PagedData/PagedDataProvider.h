//
//  PagedDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 16/05/13.
//
//

#import <Foundation/Foundation.h>

// data provider for displaying paged data. data must be returned in NSArray where each element
// corresponds to different row. Elements in array must be ordered in display order.
@protocol PagedDataProvider <NSObject>

// returns specified page. Must never return null. Must return empty array when there are no rows to return
-(NSArray *)getPage:(int)pageNumber pageSize:(int)pageSize;

-(NSInteger)size;

@end
