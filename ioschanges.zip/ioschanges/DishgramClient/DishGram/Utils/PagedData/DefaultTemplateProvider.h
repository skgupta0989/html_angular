//
//  DefaultTemplateProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 30/07/13.
//
//

#import <UIKit/UIKit.h>
#import "NVTemplateProvider.h"
#import "MutableRowDataProvider.h"

@interface DefaultTemplateProvider : NSObject<NVTemplateProvider> {
    MutableRowDataProvider *_rowDataProvider;
    MutableRowDataProvider *_nRowDataProvider;
    
}

// currently used row data provider
@property (nonatomic, strong)MutableRowDataProvider *rowDataProvider;

// new row data provider. once data is received from server, rowDataProvider will be replaced by this. And value of this property is set to nil.
@property (nonatomic, strong)MutableRowDataProvider *nRowDataProvider;

// sets approrpaite size changes call back method on rowDataProvider
-(void)setSizeChangedCallBack;

-(void)update:(void (^)(void))updateDo;

// calling this method ensures that the any existing rowDataproviders will not interfear with
// table view. This is needed when ever the table view needs to be refreshed and old rows displaed until new data is fetched
-(void)markOldDataProvidersStale;

// manages row data provides 
-(void)handleRowDataProviders;

// subclassed should override this method if they call handleRowDataProviders method
-(MutableRowDataProvider *)createRowDataProvider;



@end
