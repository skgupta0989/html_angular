//
//  NVPagedDataView.m
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import "NVPagedDataView.h"
#import "PageUtil.h"

@implementation NVPagedDataView

@synthesize templateProvider;

#pragma mark - init
- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame disableTabHiding:YES];
}

- (id)initWithFrame:(CGRect)frame disableTabHiding:(BOOL)disableTabHiding
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        disableTabHiding_ = disableTabHiding;
        self.delegate = self;
        self.dataSource = self;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        scrollUp = 0;

        [self setShowsVerticalScrollIndicator:NO];
    }
    return self;
}

#pragma mark - UITableViewDataSource method

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return templateProvider.numRows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @autoreleasepool {
        static NSString *cellType = @"default";
        UIView *template = nil;
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellType];
        [cell removeFromSuperview];
        
        // UITableViewCell *cell = nil;
        
        if (cell == nil || ![templateProvider respondsToSelector:@selector(getTemplate:reuseView:)]) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellType];
            template = [templateProvider getTemplate:indexPath.row];
            template.tag = TAG_NVP_TEMPLATE_VIEW;
            [cell addSubview:template];
            [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        } else {
            UIView *oldTemplate = [cell viewWithTag:TAG_NVP_TEMPLATE_VIEW]; // [[cell subviews] objectAtIndex:0];
            template = [templateProvider getTemplate:indexPath.row reuseView:oldTemplate];
            if (oldTemplate != template) {
                [oldTemplate removeFromSuperview];
                [cell addSubview:template];
                template.tag = TAG_NVP_TEMPLATE_VIEW;
            }
        }
        
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([templateProvider respondsToSelector:@selector(getCellHeight:)]) {
        return [templateProvider getCellHeight:indexPath.row];
    } else {
        return [templateProvider getCellHeight];
    }
}

#pragma mark - hiding-tab-bar mechanism

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    if (!disableTabHiding_) {
        [PageUtil hideTabBar:self];
        contentOffSetStart = self.contentOffset.y;
        scrollUp = 0;
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)sender
{
    if (!disableTabHiding_) {
        if (scrollUp == 0) {
            scrollUp = contentOffSetStart - self.contentOffset.y;
        }
        
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
        //ensure that the end of scroll is fired.
        [self performSelector:@selector(scrollViewDidEndScrollingAnimation:) withObject:nil afterDelay:0.5];
    }
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    if (!disableTabHiding_) {
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
        [PageUtil showTabBar:self];
        [self performSelector:@selector(scrollIfNeeded) withObject:nil afterDelay:0.21];
    }
}

-(void)scrollIfNeeded {
    
    if(!disableTabHiding_) {
        
        float contentOffset = self.contentOffset.y;
        
        if (scrollUp < 0) {
            [UIView animateWithDuration:.1 animations:^{
                id<UITableViewDelegate> del = self.delegate;
                self.delegate = nil;
                self.contentOffset = CGPointMake(self.contentOffset.x, contentOffset + 50);
                self.delegate = del;
            } completion:^(BOOL finished) {
                
            }];
        }
    }
}

float contentOffSetStart = 0;

#pragma mark -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(void)noDataFound {
    // remove any old no-data-found image
    [PageUtil removeNoDataFoundImage:self];
    
    // add new no-data-found image
    [PageUtil addNoDataFoundImage:self];
    
    // reload data to remove any old cells.
    [self reloadData];
}

-(void)noDataFoundImage:(NSString *)imageName{
        // remove any old no-data-found image
    [PageUtil removeNoDataFoundImage:self];
    
        // add new no-data-found image
    [PageUtil addNoDataFoundImage:self imageName:imageName];
    
        // reload data to remove any old cells.
    [self reloadData];
}
-(void)refreshVisibleRows {
    [self reloadRowsAtIndexPaths:[self indexPathsForVisibleRows]
                withRowAnimation:UITableViewRowAnimationNone];
}

-(void)dealloc {
    self.delegate = nil;
}

@end
