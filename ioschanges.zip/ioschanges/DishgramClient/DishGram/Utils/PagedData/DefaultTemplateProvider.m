//
//  DefaultTemplateProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 30/07/13.
//
//

#import "DefaultTemplateProvider.h"
#import "MutableRowDataProvider.h"
#import "NVPagedDataView.h"
#import "MutableDefaultDataProvider.h"

@implementation DefaultTemplateProvider

@synthesize numRows;
@synthesize owner;
@synthesize rowDataProvider = _rowDataProvider;
@synthesize nRowDataProvider = _nRowDataProvider;


// call this method after setting _rowDataProvider value
-(void)setSizeChangedCallBack {
    __weak typeof(self) weakSelf = self;
    
    MutableRowDataProvider *rdp = nil;
    if (_nRowDataProvider!=nil) {
        rdp = _nRowDataProvider;
    } else {
        rdp = _rowDataProvider;
    }
    
    rdp.sizeChangedCallBack = ^(int newSize) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf.owner != nil) {
            //            NSLog(@"newSize = %d", newSize);
            
            if (newSize > strongSelf.numRows && strongSelf.numRows != 0) {
                int oldSize = strongSelf.numRows;
                strongSelf.numRows = newSize;
                
                NSMutableArray *newIndexes = [[NSMutableArray alloc] init];
                for (int i = oldSize; i < newSize; ++i) {
                    [newIndexes addObject:[NSIndexPath indexPathForRow:i inSection:0]];
                }
                
                [strongSelf performSelectorOnMainThread:@selector(update:)
                                             withObject:^{
                                                 [strongSelf.owner insertRowsAtIndexPaths:newIndexes withRowAnimation:UITableViewRowAnimationFade];
                                             } waitUntilDone:false];
                
            } else {
                strongSelf.numRows = newSize;
                [strongSelf performSelectorOnMainThread:@selector(update:)
                                             withObject:^{
                                                 [strongSelf.owner reloadData];
                                             } waitUntilDone:false];
            }
        }
        
    };
    
}

-(void)markOldDataProvidersStale {
    
    if (_rowDataProvider != nil) {
        ((MutableDefaultDataProvider *)_rowDataProvider.pagedDataProviderInst).isState = YES;
    }
    
    if (_nRowDataProvider != nil) {
        ((MutableDefaultDataProvider *)_nRowDataProvider.pagedDataProviderInst).isState = YES;
    }
}


-(void)handleRowDataProviders {
    @autoreleasepool {
        MutableRowDataProvider *rdp = [self createRowDataProvider];
        [self markOldDataProvidersStale];
        if (_rowDataProvider == nil) {
            _rowDataProvider = rdp;
        } else {
            _nRowDataProvider = rdp;
            ((MutableDefaultDataProvider *)rdp.pagedDataProviderInst).pagedDataView = ((MutableDefaultDataProvider *)_rowDataProvider.pagedDataProviderInst).pagedDataView;
        }
        [self setSizeChangedCallBack];
    }
}

-(MutableRowDataProvider *)createRowDataProvider {
    return nil;
}


// override this method
-(UIView *)getTemplate:(int)index {
    return nil;
}

// override this method
-(float)getCellHeight {
    return 100;
}


-(void)update:(void (^)(void))updateDo {

    @try {
        updateDo();
    }
    @catch (NSException *exception) {
        NSLog(@"%@", exception.reason);
    }
    @finally {
        //
    }
    
}

// trigger for loading data from server
-(void)trigger {
    [self getTemplate:0];
}

// replace old row data provide with the new one (if new rowDataprovider is available)
-(void)replaceRowDataProvider {
    if (self.nRowDataProvider != nil) {
        self.rowDataProvider = self.nRowDataProvider;
        self.nRowDataProvider = nil;
        [((MutableDefaultDataProvider *)self.rowDataProvider.pagedDataProviderInst).pagedDataView refreshVisibleRows];
    }
}

@end
