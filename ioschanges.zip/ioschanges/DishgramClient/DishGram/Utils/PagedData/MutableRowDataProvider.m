//
//  MutableRowDataProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 04/06/13.
//
//

#import "MutableRowDataProvider.h"

@implementation MutableRowDataProvider

@synthesize sizeChangedCallBack;
@synthesize pagedDataProviderInst;

-(void)preload:(int)index {
    
    if (!_pageSizeIncreased) {
        _pageSizeIncreased = YES;
        _pageSize = _pageSize*4;
    }
    
    // check if preload required for next
    bool preLoadNext = ((_endIndex - index) <= _pageSize*(100 - _trigger)/100);
    bool preLoadPrev = ((index - _startIndex) <= _pageSize*(100 - _trigger)/100);
    
    if (preLoadNext) {
        [self load:(_endIndex + 1)];
    }
    
    if (preLoadPrev && _startIndex > 0) {
        [self load:(_startIndex - _pageSize)];
    }
    
}

// checkes if required page is already loaded and loades it if needed
-(void)load:(int)index {
    
    if (index < _startIndex || index > _endIndex) {
        // [self getPageAndAddToCache:pageNumber];
        [self performSelectorInBackground:@selector(getPageAndAddToCacheWithNSNumber:) withObject:[NSNumber numberWithInt:index]];
    }
}

-(void)getPageAndAddToCacheWithNSNumber:(NSNumber *)pageNumber {
    [self getPageAndAddToCache:pageNumber.intValue];
}

-(void)getPageAndAddToCache:(int)index {
    [_requestLock lock];
    
    if (index < 0) index = 0;
    int size = 0;
    
    // check this condition to ensure no other thread loaded the page
    if (index < _startIndex) {
        size = _startIndex - index;
        NSArray *page = [self getPage:index size:size];
        
        [self addToCache:page atEnd:NO];
    } else if (index > _endIndex) {
        if (_endReached) {
            [_requestLock unlock];
            return;
        }
        size = _pageSize;
        
        NSArray *page = [self getPage:index size:size];
        
        if (size > page.count) {
            _endReached = true;
        }
        
        [self addToCache:page atEnd:YES];
    }
    
    [_requestLock unlock];
}

-(void)addToCache:(NSArray *)entries atEnd:(BOOL)end {
    
    [_cacheLock lock];
    if (end) {
        [_cache addObjectsFromArray:entries];
        _endIndex += entries.count;
        while ((_endIndex - _startIndex + 1) > _pageSize*_cacheSize) {
            [_cache removeObjectAtIndex:0];
            ++_startIndex;
        }
    } else {
        // add objects at the begining
        for (int i = 0; i < entries.count; ++i) {
            [_cache insertObject:[entries objectAtIndex:i] atIndex:i];
        }
        
        _startIndex -= entries.count;
        if ((_endIndex - _startIndex + 1) > _pageSize*_cacheSize) {
            _endReached = false;
            while ((_endIndex - _startIndex + 1) > _pageSize*_cacheSize) {
                [_cache removeLastObject];
                --_endIndex;
            }
        }
    }
    [_cacheLock unlock];
    if (entries.count != 0 && sizeChangedCallBack != nil) {
        sizeChangedCallBack([self getCurrentSize]);
    }
}

-(NSObject *)getLocalRow:(int)index {
    return [self getRowDo:index local:true];
}

-(NSObject *)getRow:(int)index {
    return [self getRowDo:index local:false];
}

-(NSObject *)getRowDo:(int)index local:(bool)local {
    NSObject *data = nil;
    
    [_cacheLock lock];
    if (index >= _startIndex && index <= _endIndex) {
        data = [_cache objectAtIndex:(index - _startIndex)];
    }
    [_cacheLock unlock];
    
    if (data == nil) {
        if (local) {
            return nil;
        } else {
            [self getPageAndAddToCache:index];
            [_cacheLock lock];
            if (index >= _startIndex && index <= _endIndex) {
                data = [_cache objectAtIndex:(index - _startIndex)];
            }
            [_cacheLock unlock];
        }
        
    } else {
        if (!local) {
            [self preload:index];
        }
    }
    return data;
}

-(NSArray *)getPage:(int)index size:(int)size {
    return [self.pagedDataProviderInst getPage:index size:size];
}

-(id)initWithPageSize:(int)pageSize numberOfPagesToCache:(int)cacheSize pagedDataProvider:(NSObject<MutablePagedDataProvider> *)pagedDataProvider nextPageTrigger:(int)trigger {
    self = [super init];
    if (self) {
        _pageSizeIncreased = NO;
        _pageSize = pageSize;
        _cacheSize = cacheSize;
        _trigger = trigger;
        self.pagedDataProviderInst = pagedDataProvider;
        _cache = [[NSMutableArray alloc] init];
        _requestLock = [[NSCondition alloc] init];
        _cacheLock = [[NSCondition alloc] init];
        _pageLocks = [[NSMutableDictionary alloc] init];
        _dataReqQueue = [[NSOperationQueue alloc] init];
        
        _startIndex = 0;
        _endIndex = -1;
        _endReached = false;
    }
    return self;
}

-(void)dealloc {
    _cache = nil;
    self.pagedDataProviderInst = nil;
    _pageLocks = nil;
    _requestLock = nil;
    sizeChangedCallBack = nil;
    
#if !(__has_feature(objc_arc))
    [super dealloc];
#endif
}

-(void)getRow:(int)index withCallBack:(void (^)(NSObject *data))callBack {
    
    NSLog(@"Get row called index = %d", index);
    
    __weak typeof(self) weakSelf = self;
    [_dataReqQueue addOperationWithBlock:^{
        @autoreleasepool {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf != nil && callBack) {
                NSObject *retData = [strongSelf getRow:index];
                callBack(retData);
            }
        }
    }];
}


-(void)deleteRow:(NSObject *)data {
    [_cacheLock lock];
    if ([_cache containsObject:data]) {
        [_cache removeObject:data];
        --_endIndex;
        if (sizeChangedCallBack != nil) {
            sizeChangedCallBack([self getCurrentSize]);
        }
        [self.pagedDataProviderInst remove:data];
        
        // if no more data us left then show no data found
        if ([self getEndSize] == 0 && [self.pagedDataProviderInst respondsToSelector:@selector(noResultsFound)]) {
            [self.pagedDataProviderInst performSelectorOnMainThread:@selector(noResultsFound) withObject:nil waitUntilDone:NO];
        }
    }
    [_cacheLock unlock];
}

-(int)getEndSize {
    return _endReached?_endIndex + 1 : -1;
}

-(int)getCurrentSize {
    return _endIndex + 1;
}

@end
