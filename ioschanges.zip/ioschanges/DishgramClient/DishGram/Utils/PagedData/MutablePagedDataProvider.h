//
//  MutablePagedDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 04/06/13.
//
//

#import <Foundation/Foundation.h>

// class for fetching paginated data from server
@protocol MutablePagedDataProvider <NSObject>

// returns an array of data fetched form server (eash element usually corresponsds to one cell in the table)
// startIndex - start index (staring element in next page. previous page if user is scrolling in reverse)
// size - numger of elements to be fetched from server
-(NSArray *)getPage:(int)startIndex size:(int)size;

// removes specified data from array
-(void)remove:(NSObject *)data;

// resutls a block which will be called when a row is removed
-(void (^)(bool success, NSObject *response))getRemoveCallback;

@end
