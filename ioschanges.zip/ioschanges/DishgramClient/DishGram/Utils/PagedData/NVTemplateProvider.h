//
//  NVTemplateProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 21/05/13.
//
//

#import <Foundation/Foundation.h>

@class NVPagedDataView, MutableRowDataProvider;

@protocol NVTemplateProvider <NSObject>

-(UIView *)getTemplate:(int)index;
-(float)getCellHeight;

@optional
-(UIView *)getTemplate:(int)index reuseView:(UIView *)reuseView;
-(float)getCellHeight:(int)index;

@property (nonatomic, weak) NVPagedDataView *owner;
@property (nonatomic, assign) int numRows;
-(void)trigger;
-(void)replaceRowDataProvider;

@end
