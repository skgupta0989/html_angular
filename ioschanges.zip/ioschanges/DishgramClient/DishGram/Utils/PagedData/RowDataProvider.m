//
//  RowDataProvider.m
//  DishGram
//
//  Created by Ramesh Varma on 16/05/13.
//
//

#import "RowDataProvider.h"

// This class provides requested row data and automatically calls PagedDataProvider when needed
@implementation RowDataProvider

@synthesize _sizeChangedCallBack;
@synthesize pagedDataProviderInst;

-(id)initWithPageSize:(int)pageSize numberOfPagesToCache:(int)cacheSize pagedDataProvider:(NSObject<PagedDataProvider> *)pagedDataProvider nextPageTrigger:(int)trigger {
    self = [super init];
    if (self) {
        _pageSize = pageSize;
        _cacheSize = cacheSize;
        _trigger = trigger;
        self.pagedDataProviderInst = pagedDataProvider;
        _cache = [[CacheManager alloc] initWithMaxSize:_cacheSize andName:@""];
        _requestLock = [[NSCondition alloc] init];
        _pageLocks = [[NSMutableDictionary alloc] init];
        _lastCheckedPageNumber = -1;
        _dataReqQueue = [[NSOperationQueue alloc] init];
    }
    return self;
}

-(void)preload:(int)pageNumber curRow:(int)curRow {

    // check if preload required for next
    bool preLoadNext = (curRow >= _pageSize*_trigger/100);
    bool preLoadPrev = (curRow <= _pageSize*(100 - _trigger)/100);
    
    if (preLoadNext) {
        [self load:(pageNumber + 1)];
    }
    
    if (preLoadPrev && pageNumber > 0) {
        [self load:(pageNumber - 1)];
    }
    
}

// checkes if required page is already loaded and loades it if needed
-(void)load:(int)pageNumber {
    
    if (_lastCheckedPageNumber == pageNumber) {
        return;
    }
    
    NSString *pageNumberStr = [NSString stringWithFormat:@"%d", pageNumber];
    if ([_cache get:pageNumberStr] == nil) {
        // [self getPageAndAddToCache:pageNumber];
        [self performSelectorInBackground:@selector(getPageAndAddToCacheWithNSNumber:) withObject:[NSNumber numberWithInt:pageNumber]];
    } else {
        // page already present in cache
        _lastCheckedPageNumber = pageNumber;
    }
}

-(void)getPageAndAddToCacheWithNSNumber:(NSNumber *)pageNumber {
    [self getPageAndAddToCache:pageNumber.intValue];
}

-(void)getPageAndAddToCache:(int)pageNumber {
    NSString *pageNumberStr = [NSString stringWithFormat:@"%d", pageNumber];
    
    [_requestLock lock];
    NSCondition *lock = [_pageLocks objectForKey:pageNumberStr];
    if (lock == nil) {
        lock = [[NSCondition alloc] init];
        [_pageLocks setObject:lock forKey:pageNumberStr];
    }
    [_requestLock unlock];
    
    [lock lock];
    
    // check this condition to ensure no other thread loaded the page 
    if ([_cache get:pageNumberStr] == nil) {
        NSArray *page = [self getPage:pageNumber];
        [_cache addKey:pageNumberStr andVal:page];
        _sizeChangedCallBack(pageNumber*_pageSize + page.count);
    }
    [lock unlock];
    [_pageLocks removeObjectForKey:pageNumberStr];
    _lastCheckedPageNumber = pageNumber;
}

-(NSObject *)getLocalRow:(int)index {
    return [self getRowDo:index local:true];
}

-(NSObject *)getRow:(int)index {
    return [self getRowDo:index local:false];
}

-(NSObject *)getRowDo:(int)index local:(bool)local {
    int pageNumber = index/_pageSize;
    int pageRow = index % _pageSize;
    
    NSString *pageNumberStr = [NSString stringWithFormat:@"%d", pageNumber];
    NSArray *page = [_cache get:pageNumberStr];
    if (page == nil) {
        if (local) {
            return nil;
        }
        [self getPageAndAddToCache:pageNumber];
        page = [_cache get:pageNumberStr];
    } else {
        [self preload:pageNumber curRow:pageRow];
    }
    
    if (pageRow < [page count]) {
        return [page objectAtIndex:pageRow];
    } else {
        return nil;
    }
}

-(NSArray *)getPage:(int)pageNum {
    return [self.pagedDataProviderInst getPage:pageNum pageSize:_pageSize];
}

-(void)getRow:(int)index withCallBack:(void (^)(NSObject *data))callBack {
    [_dataReqQueue addOperationWithBlock:^{
        NSObject *retData = [self getRow:index];
        callBack(retData);
    }];
}

-(void)dealloc {
    _cache = nil;
    self.pagedDataProviderInst = nil;
    _pageLocks = nil;
    _requestLock = nil;
    
#if !(__has_feature(objc_arc))
    [super dealloc];
#endif
}

@end
