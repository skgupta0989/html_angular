//
//  MutableRowDataProvider.h
//  DishGram
//
//  Created by Ramesh Varma on 04/06/13.
//
//

#import <Foundation/Foundation.h>
#import "CacheManager.h"
#import "MutablePagedDataProvider.h"

@interface MutableRowDataProvider : NSObject {
    
    int _trigger;
    int _pageSize;
    int _cacheSize;
    
    int _startIndex;
    int _endIndex;
    bool _endReached;
    
    NSMutableArray *_cache;
    NSCondition *_requestLock;
    NSCondition *_cacheLock;
    NSMutableArray *_requestList;
    NSMutableDictionary *_pageLocks;
    
    NSOperationQueue *_dataReqQueue;
    
    BOOL _pageSizeIncreased;
    
}

// data provider for displaying paginated data.
@property (nonatomic, strong) NSObject<MutablePagedDataProvider> *pagedDataProviderInst;
@property (nonatomic, strong) void (^sizeChangedCallBack)(int);

// returns row data at specified index. row number is absolute row number in the entire tables (as opposed to row number in a page).
-(NSObject *)getRow:(int)index;

-(id)initWithPageSize:(int)pageSize numberOfPagesToCache:(int)cacheSize pagedDataProvider:(NSObject<MutablePagedDataProvider> *)pagedDataProvider nextPageTrigger:(int)trigger;

// fetches row data and calls back with row data
-(void)getRow:(int)index withCallBack:(void (^)(NSObject *data))callBack;

// returns row data if it is already present
-(NSObject *)getLocalRow:(int)index;

-(void)deleteRow:(NSObject *)data;

// returns final size if available. else returns -1
-(int)getEndSize;

// returns current know size
-(int)getCurrentSize;

@end
