//
//  DGToggel.h
//  TabPOC
//
//  Created by SumanAmit on 31/05/13.
//  Copyright (c) 2013 NEEV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DGButton :UIButton{
    
    
}
@property (nonatomic,strong) UIColor *buttonSelectionColor,*buttonUnSelectionColor;
@property (nonatomic,strong) UIColor *textSelectionColor,*textUnSelectionColor;

@end


@interface DGToggel : UIView{
    
}
@property (nonatomic,weak)DGButton *leftButton,*rightButton;
@property (nonatomic,assign)NSInteger selectedToggel;
@property (nonatomic,weak) id targetSender;
@property (nonatomic,assign) SEL targetAction;

- (id) initWithItems:(NSArray *)items;
- (void) addTarget:(id)target action:(SEL)selector;
- (void) setSelectedIndex:(NSInteger)index;
- (void) setLeftButtonSelectdColor:(UIColor *)selctedColor unslectedColor:(UIColor *)color;
- (void) setRightButtonSelectdColor:(UIColor *)selctedColor unslectedColor:(UIColor *)color;
- (void) setTextColorSelected:(UIColor *)selectedColor unSelectColor:(UIColor *)color;
- (void) setFont:(UIFont *)font;
@end
