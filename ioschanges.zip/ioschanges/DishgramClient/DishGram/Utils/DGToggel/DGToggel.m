//
//  DGToggel.m
//  TabPOC
//
//  Created by SumanAmit on 31/05/13.
//  Copyright (c) 2013 NEEV. All rights reserved.
//

#import "DGToggel.h"


@implementation DGButton


@synthesize textSelectionColor,textUnSelectionColor;
@synthesize buttonSelectionColor,buttonUnSelectionColor;

@end


@implementation DGToggel
@synthesize leftButton,rightButton,targetSender,targetAction,selectedToggel;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)setFrameOfButton:(CGRect)frame{
    CGFloat widthOfKit=frame.size.width;
    CGFloat heightOfKit=frame.size.height;
    
    self.leftButton.frame=CGRectMake(0, 0, widthOfKit/2, heightOfKit);
    
    self.rightButton.frame=CGRectMake(widthOfKit/2, 0, widthOfKit/2, heightOfKit);
    
}
-(void)setFrame:(CGRect)frame{
    [super setFrame:frame];
    [self setFrameOfButton:frame];
}
-(id)initWithItems:(NSArray *)items{
    if (items.count<2 || items.count>2) {
        return nil;
    }
    self= [super init];
    if (self) {
        self.leftButton=[DGButton buttonWithType:UIButtonTypeCustom];
        self.rightButton=[DGButton buttonWithType:UIButtonTypeCustom];
        
        [self.leftButton setTitle:(NSString *)[items objectAtIndex:0] forState:UIControlStateNormal];
        self.leftButton.autoresizesSubviews=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin;
        self.leftButton.tag=1;
        self.leftButton.textSelectionColor=[UIColor whiteColor];
        self.leftButton.textUnSelectionColor=[UIColor blackColor];
        self.leftButton.buttonSelectionColor=[UIColor colorWithRed:243.0/255.0 green:107.0/255.0 blue:100.0/255.0 alpha:1.0];
        self.leftButton.buttonUnSelectionColor=[UIColor whiteColor];
        [self addSubview:self.leftButton];
        
        
        [self.rightButton setTitle:(NSString *)[items objectAtIndex:1] forState:UIControlStateNormal];
        self.rightButton.autoresizesSubviews=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin;
        self.rightButton.textSelectionColor=[UIColor whiteColor];
        self.rightButton.textUnSelectionColor=[UIColor blackColor];
        self.rightButton.buttonSelectionColor=[UIColor colorWithRed:243.0/255.0 green:107.0/255.0 blue:100.0/255.0 alpha:1.0];
        self.rightButton.buttonUnSelectionColor=[UIColor whiteColor];
        
        [self addSubview:self.rightButton];
        
        self.rightButton.tag=2;
        
    }
    return self;
}

#pragma mark - background image with color
- (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    [color setFill];
    UIRectFill(rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

#pragma mark - Button selection/unselection
- (void)setButtonSelected:(DGButton *)btn{
    [btn setBackgroundImage:[self imageWithColor:btn.buttonSelectionColor] forState:UIControlStateNormal];
    [btn setTitleColor:btn.textSelectionColor forState:UIControlStateNormal];
}
- (void)setButtonUnSelected:(DGButton *)btn{
    [btn setBackgroundImage:[self imageWithColor:btn.buttonUnSelectionColor] forState:UIControlStateNormal];
    [btn setTitleColor:btn.textUnSelectionColor forState:UIControlStateNormal];
}

- (void)setButtonSelectionAndUnselection:(DGButton *)btn{
    if (btn==self.leftButton) {
        [self setButtonSelected:self.leftButton];
        [self setButtonUnSelected:self.rightButton];
    }
    if (btn==self.rightButton) {
        [self setButtonSelected:self.rightButton];
        [self setButtonUnSelected:self.leftButton];
    }
}

- (void)setSelectedIndex:(NSInteger)index{
    self.selectedToggel=index;
    DGButton *btn=(DGButton *)[self viewWithTag:index];
    [self setButtonSelectionAndUnselection:btn];
}
#pragma mark - target button selection and un selection
-(void)action:(id)sender{
    DGButton *btn=(DGButton *)sender;
    [self setButtonSelectionAndUnselection:btn];
    self.selectedToggel=btn.tag;
    
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
    [self.targetSender performSelector:self.targetAction withObject:self];
#pragma clang diagnostic pop

    
}
-(void) addTarget:(id)target action:(SEL)selector{
    self.targetSender=target;
    self.targetAction=selector;
    [self.leftButton addTarget:self  action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self.rightButton addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
}

- (void) setLeftButtonSelectdColor:(UIColor *)selctedColor unslectedColor:(UIColor *)color{
    self.leftButton.buttonSelectionColor=selctedColor;
    self.leftButton.buttonUnSelectionColor=color;
}
- (void) setRightButtonSelectdColor:(UIColor *)selctedColor unslectedColor:(UIColor *)color{
    self.rightButton.buttonSelectionColor=selctedColor;
    self.rightButton.buttonUnSelectionColor=color;
}
- (void) setTextColorSelected:(UIColor *)selectedColor unSelectColor:(UIColor *)color{
    self.rightButton.textUnSelectionColor=color;
    self.rightButton.textSelectionColor=selectedColor;
    self.leftButton.textUnSelectionColor=color;
    self.leftButton.textSelectionColor=selectedColor;
    
}
-(void)setFont:(UIFont *)font{
    [self.leftButton.titleLabel setFont:font];
    [self.rightButton.titleLabel setFont:font];
}

-(void)dealloc{
    self.leftButton=nil;
    self.rightButton=nil;
    self.targetSender=nil;
    DLog(@"%s",__PRETTY_FUNCTION__);
}

@end
