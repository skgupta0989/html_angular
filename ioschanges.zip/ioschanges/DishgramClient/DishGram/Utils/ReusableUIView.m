//
//  ReusableUIView.m
//  DishGram
//
//  Created by Ramesh Varma on 01/08/13.
//
//

#import "ReusableUIView.h"

@implementation ReusableUIView

@synthesize reservedForIndex;
@synthesize updateInProgress;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


@end
