//
//  NVSession.h
//  DishGram
//
//  Created by Ramesh Varma on 18/06/13.
//
//

#import <Foundation/Foundation.h>

@interface NVSession : NSObject

+(void)setInSession:(NSString *)key value:(NSObject *)val;

+(void)removeFromSession:(NSString *)key;

+(NSObject *)getFromSession:(NSString *)key;

@end
