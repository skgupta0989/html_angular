//
//  DropDownView.m
//  myPlex
//
//  Created by Owner on 11/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DropDownView.h"
#import <QuartzCore/QuartzCore.h>
@implementation DropDownView
@synthesize dropDownTable;
@synthesize selectedIndex;
@synthesize delegate;
@synthesize viewProvider=_viewProvider;

- (id)initWithFrame:(CGRect)frame rowHeight:(int)rowHeight objectArray:(NSArray*)objectArray viewPriovider:(UIView*(^)(int index))viewProvider {
    
    // resize frame for smaller set of results
    frame = [self adjustFrameSize:frame rowHeight:rowHeight objectArray:objectArray];
    
    self = [super initWithFrame:frame];
    if (self){
        self.frame = frame;
        //self.backgroundColor = [UIColor blueColor];
        self.backgroundColor = [UIColor yellowColor];
        itemArray = objectArray;
        CGRect tableFrame = frame;
        tableFrame.origin = CGPointMake(0, 0);
        UITableView *tempTableView = [[UITableView alloc] initWithFrame:tableFrame style:UITableViewStylePlain];
        tempTableView.backgroundColor = [UIColor clearColor];
        self.dropDownTable = tempTableView;
        self.dropDownTable.rowHeight = rowHeight;
        self.dropDownTable.delegate = self;
        self.dropDownTable.dataSource = self;
        self.dropDownTable.scrollEnabled = YES;
        [self.dropDownTable setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
        [self addSubview:self.dropDownTable];
        self.viewProvider = viewProvider;
        self.dropDownTable.separatorStyle = UITableViewCellSeparatorStyleNone;

        [self setAutoresizesSubviews:YES];
    }
    return self;
}

-(CGRect)adjustFrameSize:(CGRect)frame rowHeight:(int)rowHeight objectArray:(NSArray*)objectArray {

    if (frame.size.height > rowHeight*objectArray.count) {
        return CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, rowHeight*objectArray.count);
    }
    return frame;
}

#pragma mark -
#pragma mark Table view data source/delegate.
// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {	
    return [itemArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {	
	
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];		
	}
    cell.backgroundView = (self.viewProvider)(indexPath.row);
    cell.textLabel.font=[UIFont fontWithName:@"Arial" size:14];
	cell.textLabel.text=[itemArray objectAtIndex:indexPath.row];
    [cell.textLabel setBackgroundColor:[UIColor clearColor]];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [delegate dropDownView:self selectedIndex:indexPath.row];
}
-(void)dealloc{
    self.dropDownTable.delegate = nil;
    delegate=nil;
    DLog();
}

@end
