//
//  ComboboxView.h
//  DishGram
//
//  Created by Ramesh Varma on 02/07/13.
//
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
@protocol ComboBoxViewDelegate;
@interface ComboboxView : UIView<UITextFieldDelegate, DropDownViewDelegate> {
    UITextField *textField_;
    NSArray *data_;
    NSArray *filteredData_;
    bool selected_;
    bool programSet_;
    int ddSize_;
    int ddType_;
}

@property (nonatomic, strong) NSString *selectedText;
@property (nonatomic, strong, readonly)    UITextField *textField_;
@property (weak,nonatomic)id<ComboBoxViewDelegate>delegate;
- (id)initWithFrame:(CGRect)frame data:(NSArray *)data ddSize:(int)ddSize placeHolder:(NSString *)placeHolder ddSize:(int)ddType;

-(NSArray *)getFilteredData;


/*
 making text field become first responder and resign from first responder
 
 if action is performed from super view text fields
 */

- (void)textFieldBeginEditing;

@end


@protocol ComboBoxViewDelegate <NSObject>
@optional
- (NSString*)getDesiredUrl:(ComboboxView *)view;
- (Class)getTargetClass:(ComboboxView *)view;
- (NSString *)getTargetMeamber:(ComboboxView *)view;
- (NSMutableDictionary *)getParamDictionary:(ComboboxView *)view;
- (void)selectedOption:(NSObject *)object ofView:(ComboboxView *)view;
- (void)textFieldReturn:(ComboboxView *)view;
- (void)textFieldBeginEditing:(ComboboxView *)view;

@end

