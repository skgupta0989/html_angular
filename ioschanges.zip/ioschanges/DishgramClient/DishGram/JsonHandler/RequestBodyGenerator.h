//
//  RequestBodyGenerator.h
//  DishGram
//
//  Created by Rags on 19/04/13.
//
//

#import <Foundation/Foundation.h>

@interface RequestBodyGenerator : NSObject


- (NSMutableDictionary *)postDatawithUserName :(NSString *)userName
                                    andemailId:(NSString *)emailId
                                   andpassword:(NSString *)password
                           andregistrationType:(NSString *)registrationType
                                   andappToken:(NSString *)appToken
                                 anduserOathId:(NSString *)userOathId;
                         
    


- (NSMutableDictionary *)postdataForLoginWithEmail:(NSString *)email andPassword:(NSString *)password loginType:(NSString*)loginType;

- (NSMutableDictionary *)postDataforFollowUser:(NSString *)token
                                     andUserID:(NSString *)userID
                             andFollowingValue:(NSString *)followingValue;

- (NSMutableDictionary *)postDataforGetUserProfileWithToken :(NSString *)token
                                                   andUserID:(NSString *)userId;

- (NSMutableDictionary *)postDataForGetDishList:(NSString *)token;

- (NSMutableDictionary *)postDataForLandingPageWithLocation:(NSString *)location
                                                andLatitude:(NSString *)latitude
                                               andLongitude:(NSString *)longitude;

- (NSMutableDictionary *)postDataToRetrieveImageByID:(NSString *)token
                                               andId:(NSString *)id
                                             andType:(NSString *)type;

- (NSMutableDictionary *)postDataForForgotpassword:(NSString *)emailId;

- (NSMutableDictionary *)postDataforLoveDish:(NSString *)token
                              andDishPlaceId:(NSString *)dishPlaceId;

- (NSMutableDictionary *)postDataforDishComment:(NSString *)token
                                 andDishPlaceId:(NSString *)dishPlaceId
                                     andComment:(NSString *)comment;

- (NSMutableDictionary *)postDataForGetPlaceByDistance:(NSString *)token
                                           andLatitude:(NSString *)latitude
                                          andLongitude:(NSString *)longitude;

@end
