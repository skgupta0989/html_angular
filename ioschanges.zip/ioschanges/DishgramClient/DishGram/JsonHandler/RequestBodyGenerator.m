//
//  RequestBodyGenerator.m
//  DishGram
//
//  Created by Rags on 19/04/13.
//
//

#import "RequestBodyGenerator.h"
#import "AppDelegate.h"


@implementation RequestBodyGenerator

// Post parameters for the registration

- (NSMutableDictionary *)postDatawithUserName :(NSString *)userName
                                    andemailId:(NSString *)emailId
                                   andpassword:(NSString *)password
                           andregistrationType:(NSString *)registrationType
                                   andappToken:(NSString *)appToken
                               anduserOathId:(NSString *)userOathId{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    
    NSMutableDictionary *registerUserInfoDict = [[NSMutableDictionary alloc]init];
    [registerUserInfoDict setValue:userName forKey:@"username"];
    [registerUserInfoDict setValue:emailId forKey:@"email"];
    [registerUserInfoDict setValue:password forKey:@"password"];
    [registerUserInfoDict setValue:registrationType forKey:@"registrationType"];
    [registerUserInfoDict setValue:appToken forKey:@"appToken"];
    [registerUserInfoDict setValue:userOathId forKey:@"userOathId"];
    [registerUserInfoDict setValue:@"1.0" forKey:@"appVersion"];
    [registerUserInfoDict setValue:@"iPhone" forKey:@"deviceType"];
    [registerUserInfoDict setValue:[[UIDevice currentDevice] systemVersion] forKey:@"osVersion"];
    [registerUserInfoDict setValue:[NSNumber numberWithFloat:appDelegate.locations.coordinate.latitude] forKey:@"latitude"];
    [registerUserInfoDict setValue:[NSNumber numberWithFloat:appDelegate.locations.coordinate.longitude] forKey:@"longitude"];
    return registerUserInfoDict;
  
    
}



// post parameters for the login 

- (NSMutableDictionary *)postdataForLoginWithEmail:(NSString *)email
                                          andPassword:(NSString *)password loginType:(NSString*)loginType{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    NSMutableDictionary *loginuserInfoDict = [[NSMutableDictionary alloc]init];
    [loginuserInfoDict setValue:email forKey:@"email"];
    [loginuserInfoDict setValue:password forKey:@"password"];
    [loginuserInfoDict setValue:loginType forKey:@"loginType"];
    [loginuserInfoDict setValue:@"1.0" forKey:@"appVersion"];
    [loginuserInfoDict setValue:@"iPhone" forKey:@"deviceType"];
    [loginuserInfoDict setValue:[[UIDevice currentDevice] systemVersion] forKey:@"osVersion"];
    [loginuserInfoDict setValue:[NSNumber numberWithFloat:appDelegate.locations.coordinate.latitude] forKey:@"latitude"];
    [loginuserInfoDict setValue:[NSNumber numberWithFloat:appDelegate.locations.coordinate.longitude] forKey:@"longitude"];
    return loginuserInfoDict;
    
}

// post parameters for the follow users

- (NSMutableDictionary *)postDataforFollowUser:(NSString *)token
                                     andUserID:(NSString *)userID
                             andFollowingValue:(NSString *)followingValue{
    
    
    NSMutableString *followUserParamatersString  = [[NSMutableString alloc] init];
    [followUserParamatersString appendFormat:@"{token:%@,", token];
    [followUserParamatersString appendFormat:@"userList:[{"];
    [followUserParamatersString appendFormat:@"userId:%@",userID];
    [followUserParamatersString appendFormat:@"followingValue:%@}]}",followingValue];
    
    NSMutableDictionary *followUserDict = [[NSMutableDictionary alloc] init];
    [followUserDict setValue:followUserParamatersString forKey:@"followUserParamatersString"];
    
    return followUserDict;
    
}
//parameters for the getuserlist

- (NSMutableDictionary *)postDataforGetUserProfileWithToken :(NSString *)token
                                                   andUserID:(NSString *)userId{
    
    NSMutableDictionary *userProfileDict = [[NSMutableDictionary alloc] init];
    [userProfileDict setValue:token forKey:@"token"];
    [userProfileDict setValue:userId forKey:@"userId"];
    return userProfileDict;
    
    
}

// parameters for the get dish list

- (NSMutableDictionary *)postDataForGetDishList:(NSString *)token{
    
    NSMutableDictionary *getDishListDict = [[NSMutableDictionary alloc] init];
    [getDishListDict setValue:token forKey:@"token"];
    return getDishListDict;
    
    
}

// parameters for landing page

- (NSMutableDictionary *)postDataForLandingPageWithLocation:(NSString *)location
                                                andLatitude:(NSString *)latitude
                                               andLongitude:(NSString *)longitude{
    
    
    NSMutableDictionary *landingPageDict = [[NSMutableDictionary alloc] init];
    [landingPageDict setValue:location forKey:@"location"];
    [landingPageDict setValue:latitude forKey:@"latitude"];
    [landingPageDict setValue:longitude forKey:@"longitude"];
    return landingPageDict;
    
    
    
}

// parameters retrieve image by ID


- (NSMutableDictionary *)postDataToRetrieveImageByID:(NSString *)token
                                                andId:(NSString *)id
                                                andType:(NSString *)type{
                                                    
        NSMutableDictionary *retrieveImageDict = [[NSMutableDictionary alloc] init];
        [retrieveImageDict setValue:token forKey:@"token"];
        [retrieveImageDict setValue:id forKey:@"imageId"];
        [retrieveImageDict setValue:type forKey:@"type"];
        return retrieveImageDict;
                                                    
                                                
}
// parameters for the forgot password

- (NSMutableDictionary *)postDataForForgotpassword:(NSString *)emailId{
    NSMutableDictionary *forgotPasswordDict = [[NSMutableDictionary alloc] init];
    [forgotPasswordDict setValue:emailId forKey:@"email"];
    return forgotPasswordDict;
    
}
// parameters to get the dish love

- (NSMutableDictionary *)postDataforLoveDish:(NSString *)token
                              andDishPlaceId:(NSString *)dishPlaceId{
    NSMutableDictionary *dishLoveDict = [[NSMutableDictionary alloc] init];
    [dishLoveDict setValue:token forKey:@"token"];
    [dishLoveDict setValue:dishPlaceId forKey:@"dishPlaceId"];
    return dishLoveDict;
    
    
}
// Parameters for the dish Comment

- (NSMutableDictionary *)postDataforDishComment:(NSString *)token
                              andDishPlaceId:(NSString *)dishPlaceId
                                     andComment:(NSString *)comment{
    
    NSMutableDictionary *dishCommentDict = [[NSMutableDictionary alloc] init];
    [dishCommentDict setValue:token forKey:@"token"];
    [dishCommentDict setValue:dishPlaceId forKey:@"dishPlaceId"];
    [dishCommentDict setValue:comment forKey:@"comment"];
    return dishCommentDict;
    
    
}

// post data for the explores get place by distance

- (NSMutableDictionary *)postDataForGetPlaceByDistance:(NSString *)token
                                                andLatitude:(NSString *)latitude
                                               andLongitude:(NSString *)longitude{
    
    
    NSMutableDictionary *getPlaceDict = [[NSMutableDictionary alloc] init];
    [getPlaceDict setValue:token forKey:@"location"];
    [getPlaceDict setValue:latitude forKey:@"latitude"];
    [getPlaceDict setValue:longitude forKey:@"longitude"];
    return getPlaceDict;
    
    
    
}



                
@end
