//
//  AppDelegate.h
//  DishGram
//
//  Created by Rags on 08/04/13.
//
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import "Reachability.h"
#import "DishgramHomeControllerViewController.h"
#import "DGLocationManager.h"

#define FACEBOOK_URL 10
#define TUMBLR_URL  1


@class LandingScreen, FourSquareHandler, TwitterHandler, FacebookSocialNetwork, TumblrHandler;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    UIViewController *landingScreenVC;
    DishgramHomeControllerViewController *view;
}

@property (assign, nonatomic) BOOL isFirstTimeLoaded;

// height of the keypad
@property (assign, nonatomic) float keyPadHeight;

// window width
@property (assign, nonatomic) float winWidth;

// window height
@property (assign, nonatomic) float winHeight;

// window singleton
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) Reachability *checkRechability;

// current location
@property (strong, nonatomic) CLLocation *locations;

// address string of current location
@property (strong, nonatomic) NSString *locationAddress;
@property (strong, nonatomic)    DishgramHomeControllerViewController *dgHomeController;
@property (assign, nonatomic) int followingCount;
@property (assign, nonatomic) int restaurantFollowingCount;
@property (strong, nonatomic) FourSquareHandler *fsHandler;
@property (strong, nonatomic) TwitterHandler *twitterHandler;
@property (strong, nonatomic) FacebookSocialNetwork *facebookHandler;
@property (strong, nonatomic) TumblrHandler *tumblrHandler;

@property (nonatomic, assign) int currentUrlToOpen;
@property  BOOL isNetWorkAvailable;

// location manager for periodically updating current location
@property (strong, nonatomic) DGLocationManager *locationManager;

@property (nonatomic, strong) NSDictionary *apnsPayloadDict;
@property (nonatomic, strong) NSBlockOperation *blockOperation;

- (BOOL)checkWhetherInternetIsAvailable;

// changes selected tab index to specified index (selection)
- (void)setSelectedTab:(NSInteger)selection;
-(void)loadLandingPage;

// loads home tab (Activity feed screen)
- (void)loadDishGramHomeTab;

// loads explore tab (used when user is not logged in and clicks of explore button at the bottom) 
- (void)loadDishGramExploreTab;


- (void)sendRequest;

@end
