//
//  LiveInvoker.m
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#import "LiveInvoker.h"





@implementation LiveInvoker

-(void)invoke:(NSString *)url andParams:(NSMutableDictionary *)params withCallBack:(void (^)(bool success, NSString* response))callBack {
    _serviceInvoker = [[WebServiceInvoker alloc] init];
    [_serviceInvoker sendUrlandParameters:url
                            andParameters:params
                             withCallBack:callBack];
}


@end
