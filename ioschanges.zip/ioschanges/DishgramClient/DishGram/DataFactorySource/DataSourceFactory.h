//
//  DataSourceFactory.h
//  DishGram
//
//  Created by Satish on 4/18/13.
//
//

#import <Foundation/Foundation.h>
#import "DataSourceInterface.h"



@interface DataSourceFactory : NSObject


+(id)getDataSourceInstance;


@end
