//
//  DataCache.m
//  DishGram
//
//  Created by Ramesh Varma on 27/06/13.
//
//

#import "DataCache.h"

@implementation DataCache

-(id)init {
    self = [super init];
    if(self) {
        dirNotCreated = YES;
    }
    return self;
}

-(NSString *)getFromCache:(NSString *)url {
    NSString *data = [NSString stringWithContentsOfFile:[self getFileName:url] encoding:NSUTF8StringEncoding error:nil];
    if (data.length==0) {
        return nil;
    }
    return data;
}

// persistes string data to disk
-(void)storeInCache:(NSString *)url value:(NSString *)value {
    
    // check if the directory is already created.
    if (dirNotCreated) {
        // create directory
        [[NSFileManager defaultManager] createDirectoryAtPath:[self getFileNamePrefix] withIntermediateDirectories:YES attributes:nil error:nil];
        dirNotCreated = FALSE;
    }

    // BOOL result =
    [value writeToFile:[self getFileName:url] atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

-(NSString *)getFileNamePrefix {
    if (documentPathPrefix == nil) {
        documentPathPrefix = [Utilities getFileNamePrefix:@"DGDataCache"];
    }
    return documentPathPrefix;
    
}

// returns unique file name for specified url
-(NSString *)getFileName:(NSString *)url {
    // get image file name
    NSArray* items = [url componentsSeparatedByString:@"/"];
    NSString *fileName =[items lastObject];
    
    // full directory path
    return [[self getFileNamePrefix] stringByAppendingPathComponent:fileName];
}

@end
