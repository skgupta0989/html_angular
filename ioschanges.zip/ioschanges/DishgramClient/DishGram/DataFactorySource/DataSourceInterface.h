//
//  DataSourceInterface.h
//  DishGram
//
//  Created by Satish on 4/18/13.
//
//

#import <Foundation/Foundation.h>
#import "KVCObject.h"
#import "JsonResponseParser.h"
#import "DataCache.h"
#import "WebServiceInvoker.h"

#define TOKEN_DOES_NOT_EXIST @"TOKEN DOES NOT EXIST"

#define RESP_KEY_STATUS @"status"
#define RESP_KEY_STATUS_SUCCESS @"SUCCESS"
#define RESP_KEY_STATUS_FAILURE @"FAILURE"

#define RESP_KEY_MESSAGE @"message"
#define RESP_KEY_OBJECT @"object"

#define DATA_SOURCE_CALLBACK void (^)(bool success, NSObject* response)

@interface DataSourceInterface : NSObject{

}

@property (nonatomic, strong) DataCache *dataCache;

-(void)requestDataWithURLString:(NSString*)urlString params:(NSMutableDictionary*)paramDict modelClass:(Class)modelClass callBack:(DATA_SOURCE_CALLBACK)callBack;

-(void)invoke:(NSString *)url andParams:(NSMutableDictionary *)params withCallBack:(void (^)(bool success, NSString* response))callBack;

+(KVCObject *)makeKVCObject:(Class)objClass data:(NSDictionary *)dictionary;

@end
