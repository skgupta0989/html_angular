//
//  DummyInvoker.h
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#import "DataSourceInterface.h"

@interface DummyInvoker : DataSourceInterface{
    
    
}

@end
