//
//  LiveInvoker.h
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#import "DataSourceInterface.h"
#import "WebServiceInvoker.h"


@interface LiveInvoker : DataSourceInterface {
    WebServiceInvoker *_serviceInvoker;
}

@end
