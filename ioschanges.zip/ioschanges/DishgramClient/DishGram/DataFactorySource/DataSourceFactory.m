//
//  DataSourceFactory.m
//  DishGram
//
//  Created by Satish on 4/18/13.
//
//

#import "DataSourceFactory.h"
#import "Header.h"
#import "DataSourceInterface.h"
#import "LiveInvoker.h"
#import "DummyInvoker.h"

@implementation DataSourceFactory



+(id)getDataSourceInstance{
    DataSourceInterface *dataSouceInstance;
    if (LiveState) {
        dataSouceInstance = [[LiveInvoker alloc] init];
    }
    else{
         dataSouceInstance = [[DummyInvoker alloc] init];
    }
    return dataSouceInstance;  
}

@end
