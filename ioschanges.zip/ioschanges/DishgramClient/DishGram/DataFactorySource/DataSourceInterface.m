//
//  DataSourceInterface.m
//  DishGram
//
//  Created by Satish on 4/18/13.
//
//

#import "DataSourceInterface.h"
#import "Header.h"

#import "WebServiceInvoker.h"
#import "KVCObject.h"
#import "ResponseDict.h"

#import "PageUtil.h"
#import "AppDelegate.h"
#import "AlertViewBlocks.h"

#import "DGImageUploadSingeloton.h"

@implementation DataSourceInterface

@synthesize dataCache = dataCache_;

-(id)init {
    self = [super init];
    if(self) {
        self.dataCache = [[DataCache alloc] init];
    }
    return self;
}


-(void)invoke:(NSString *)url andParams:(NSMutableDictionary *)params withCallBack:(void (^)(bool success, NSString* response))callBack {
    // Dummy impl. sub classes must override this
}

-(bool)isCachable:(NSString *)url param:(NSMutableDictionary *)paramDict {
    if ([url isEqualToString:GET_CUISINE_LIST]) {
        return YES;
    }else if([url isEqualToString:PLACEBYDISTANCE]){
        int pageNumber=[[paramDict valueForKey:@"offset"] integerValue];
        if (pageNumber==0) {
            if ([[DGImageUploadSingeloton singelton] dataLocation]==nil) {
                [self.dataCache storeInCache:url value:@""];
                [DGImageUploadSingeloton singelton].dataLocation=[DGLocationManager getCLLocationOf:[[paramDict valueForKey:@"latitude"] floatValue]longitude:[[paramDict valueForKey:@"longitude"] floatValue]];
        
            }else{
                CLLocation *newLocation=[DGLocationManager getCLLocationOf:[[paramDict valueForKey:@"latitude"] floatValue]longitude:[[paramDict valueForKey:@"longitude"] floatValue]];
                CLLocation *oldLocation=[DGImageUploadSingeloton singelton].dataLocation;
                if ((newLocation.coordinate.latitude!=oldLocation.coordinate.latitude)||(newLocation.coordinate.longitude!=oldLocation.coordinate.longitude)) {
                    [self.dataCache storeInCache:url value:@""];
                    [DGImageUploadSingeloton singelton].dataLocation=newLocation;

                }
            }
            return YES;
        }
    }
    return NO;
}

-(void)requestDataWithURLString:(NSString*)urlString params:(NSMutableDictionary*)paramDict modelClass:(Class)modelClass callBack:(DATA_SOURCE_CALLBACK)callBack {
    
    bool cachable = [self isCachable:urlString param:paramDict];
    
    if (cachable) {
        NSString *data = [self.dataCache getFromCache:urlString];
        if (data != nil) {
            [self getCallBackMethodWithModelClass:modelClass callBack:callBack cachable:false url:urlString](YES, data);
            return;
        }
    }
    
    [self    invoke:urlString
          andParams:paramDict
       withCallBack:[self getCallBackMethodWithModelClass:modelClass
                                                 callBack:callBack
                                                 cachable:cachable
                                                      url:urlString]];
}

- (void (^)(bool success, NSString* response)) getCallBackMethodWithModelClass:(Class)modelClass callBack:(DATA_SOURCE_CALLBACK)callBack cachable:(bool)cachable url:(NSString *)urlString {
    
    return ^(bool success, NSString* response) {
        @autoreleasepool {
            if (!callBack) return;
            
            if (success) {
                if (cachable) {
                    [self.dataCache storeInCache:urlString value:response];
                }
                
                NSDictionary *dataDict = [JsonResponseParser getParserData:response];
                NSString *status = [dataDict objectForKey:RESP_KEY_STATUS];
                DLog(@".................\n%@",dataDict);
                if ([status isEqualToString:RESP_KEY_STATUS_SUCCESS]) {
                    // parse response
                    NSObject *returnVal = nil;
                    NSObject *respValue = [dataDict objectForKey:RESP_KEY_OBJECT];
                    
                    if (!modelClass) {
                        returnVal = [dataDict objectForKey:RESP_KEY_MESSAGE];
                    } else {
                        if ([respValue isKindOfClass:[NSArray class]]) {
                            // parse obj array
                            NSArray *values = [dataDict objectForKey:RESP_KEY_OBJECT];
                            NSMutableArray *retArray = [[NSMutableArray alloc] init];
                            if ([values class]!=[NSNull class] && values != NULL) {
                                for (int i = 0; i < values.count; ++i) {
                                    [retArray addObject:[DataSourceInterface makeKVCObject:modelClass data:[values objectAtIndex:i]]];
                                }
                            }
                            
                            returnVal = retArray;
                        } else {
                            // For USER PROFILE
                            if ([modelClass isSubclassOfClass:[ResponseDict class]]) {
                                returnVal = [DataSourceInterface makeKVCObject:modelClass data:dataDict];
                            }
                            else{
                                // parse obj
                                returnVal = [DataSourceInterface makeKVCObject:modelClass data:[dataDict objectForKey:RESP_KEY_OBJECT]];
                            }
                        }
                    }
                    
                    callBack(success, returnVal);
                } else {
                    NSString *responseKey=[dataDict objectForKey:RESP_KEY_MESSAGE];
                    callBack(false, responseKey);
                    if ([responseKey isEqualToString:TOKEN_DOES_NOT_EXIST]) {
                        [PageUtil showAlertView:@"Please Login to connect with DishGram"];
                    }
                }
                
            } else {
                callBack(success, response);
            }
        }
    };
}


+(KVCObject *)makeKVCObject:(Class)objClass data:(NSDictionary *)dictionary {
    KVCObject *obj;
    if ([dictionary class]!= [NSNull class]) {
        obj = [[objClass alloc] init];
        [obj setValuesForKeysWithDictionary:dictionary];
    }
    return obj;
}

@end
