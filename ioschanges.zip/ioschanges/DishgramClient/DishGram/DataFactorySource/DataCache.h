//
//  DataCache.h
//  DishGram
//
//  Created by Ramesh Varma on 27/06/13.
//
//

#import <Foundation/Foundation.h>

@interface DataCache : NSObject {
    NSString *documentPathPrefix;
    bool dirNotCreated;
}



-(NSString *)getFromCache:(NSString *)key;
-(void)storeInCache:(NSString *)key value:(NSString *)value;

@end
