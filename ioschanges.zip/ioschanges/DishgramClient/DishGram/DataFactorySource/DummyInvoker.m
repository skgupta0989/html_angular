//
//  DummyInvoker.m
//  DishGram
//
//  Created by Satish on 4/19/13.
//
//

#import "DummyInvoker.h"
#import "Header.h"
#import "Constant.h"

@implementation DummyInvoker

-(void)reuestDataWithURLString:(NSString *)urlString params:(NSMutableDictionary *)paramDict{
    

    NSLog(@"No Live Data in Dummy implementation");
    
    
}


/*
-(void)requestDummyDataFor:(int)event{
    NSString *responseString;
    switch (event) {
        case REGISTRATION:
            
            // Return Registration Json String
            
            responseString = REGISTRATIONSTRING;
            
            [self.dataSourceDelegate dataSourceCallBack:responseString];
            
            break;
            
        case LOGIN:
            
             // Return Login Json String
            responseString = LOGINSTRING;
            
            [self.dataSourceDelegate dataSourceCallBack:responseString];
            break;
            
        case SOCIAL_NETWORK_LOGIN:
            
             // Return Login Json String
            responseString = SOCIALNETWORKLOGINSTRING;
            [self.dataSourceDelegate dataSourceCallBack:responseString];
            
            break;
        case FOLLOW_USER:
            
            // Return Login Json String
            responseString = FOLLOWUSERSTRING;
            [self.dataSourceDelegate dataSourceCallBack:responseString];
            break;
        case USER_PROFILE:
            
            // Return Login Json String
            responseString = USERPROFILESTRING;
            [self.dataSourceDelegate dataSourceCallBack:responseString];
            
            break;

        case GET_DISH_LIST:
            
            // Return Login Json String
            responseString = GETDISHLISTSTRING;
            [self.dataSourceDelegate dataSourceCallBack:responseString];
            break;
            
        default:
            
            NSLog(@" Requested data is not available");
            break;
    }
    
}
 */




@end
