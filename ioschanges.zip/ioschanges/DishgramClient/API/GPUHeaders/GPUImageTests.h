#import <SenTestingKit/SenTestingKit.h>

@interface GPUImageTests : SenTestCase

@end
