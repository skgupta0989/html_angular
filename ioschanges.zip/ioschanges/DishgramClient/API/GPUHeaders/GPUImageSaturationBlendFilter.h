#import "GPUImageTwoInputFilter.h"

@interface GPUImageSaturationBlendFilter : GPUImageTwoInputFilter

@end
