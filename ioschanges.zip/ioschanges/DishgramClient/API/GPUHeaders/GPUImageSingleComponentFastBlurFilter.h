#import "GPUImageFastBlurFilter.h"

@interface GPUImageSingleComponentFastBlurFilter : GPUImageFastBlurFilter

@end
