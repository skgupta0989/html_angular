#import "GPUImageTwoInputFilter.h"

@interface GPUImageAddBlendFilter : GPUImageTwoInputFilter

@end
