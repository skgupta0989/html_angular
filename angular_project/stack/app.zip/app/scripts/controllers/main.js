'use strict';

angular.module('stackApp')
  .controller('MainCtrl', function ($scope,$location,$rootScope,sharedService) {
      $scope.validate = function(){

        var msg= document.getElementById('InputEmail').value;

                sharedService.prepForBroadcast(msg);
                
                   $scope.$on('handleBroadcast', function() {
                    $scope.message = sharedService.message;
                    }); 
                
                $location.path('/blog');
//                if(a === "sandeep.gupta0787@gmail.com"){
//                    $location.path('/blog');
//                }
            };
         
             
  });



