'use strict';

angular.module('stackApp')
  .controller('BlogCtrl', function ($scope,$http,$rootScope,sharedService,$location) {
      
    
      $http({method: 'GET', url: 'data/data.json'}).
                    success(function(data, status) {
                           $scope.posts = data;  
//                           alert("Dd"+$scope.posts.length);
                        }).
                        error(function(data, status) {
   
                        });
      
      
      
//      logout button function-------------------------------
     $scope.logout = function(){
//         $location.path('/logout');
     };
     
//     gettin username and displaying-------------------------------
     
      $scope.$on('handleBroadcast', function() {
        $scope.username = sharedService.message;
        });        
    

     $scope.username = sharedService.message;
     
//     post blog bbutton ---------------------------------------
     $scope.postBlog = function(){

               
            var comment = $scope.postText;
            
           $scope.posts.push({"name":"kumar","id":8,"blog":comment,"Like":8,"comments":[]});
        
           $scope.postText='';
        

     };
     
//     like button function ---------------------------------------
             $scope.name = "Like";
        $scope.likePost = function(value){
            var i = 0;
          
            if($scope.name === "Like")
            {
              
               i= (value.Like)+1;
               alert("likes"+i);
//               $scope.posts.push({"name":value.name,"id":value.id,"blog":comment,"Like":8});
              $scope.name = "Unlike";
                
            }
            else {
                i= (value.Like)-1;
               alert("likes"+i);
//                $scope.number = i;
                $scope.name = "Like";
            }
         
        };
        
//        postComment function ------------------------------------
        $scope.postCom1 = sharedService.message;
        $scope.postComment = function(val,value){           
            
            if(sharedService.message ===''){
                
                $scope.postCom1 = "testing";
            }else{
                $scope.postCom1 = sharedService.message;
            }
            if(val ===''){
                   
            }else{
                value.comments.push(val);
//            alert("got :"+value.comments);
                $scope.post = value.comments;
                $scope.commentDiv = '';
            }
            
            
        };
    
  });
       


